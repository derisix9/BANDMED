import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initUiTheme } from './theme/uiTheme';

// Aplica o tema visual escolhido (Padrão ou Laravel) antes do primeiro render,
// para que a página nunca pisque com o tema errado.
initUiTheme();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
