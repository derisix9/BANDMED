import { Student, ClassRoom, Subject } from '../types';
import { StudentMiniPautaItem, StudentPautaGeralItem } from '../types/pauta';

/**
 * Calculates birth year and current age from various birthDate string formats
 */
export function calculateBirthYearAndAge(
  birthDateStr?: string,
  // Ano de referência para o cálculo da idade: por omissão o ano civil corrente, nunca
  // um ano fixo no código (estava 2025, o que envelhecia mal a cada ano letivo novo).
  referenceYear = new Date().getFullYear()
): { birthYear: number | string; age: number | string } {
  if (!birthDateStr) return { birthYear: '-', age: '-' };

  let year: number | null = null;
  const trimmed = birthDateStr.trim();

  // Try DD/MM/YYYY or DD-MM-YYYY
  if (trimmed.includes('/') || trimmed.includes('-')) {
    const delimiter = trimmed.includes('/') ? '/' : '-';
    const parts = trimmed.split(delimiter);
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        year = parseInt(parts[2], 10);
      } else if (parts[0].length === 4) {
        year = parseInt(parts[0], 10);
      }
    }
  }

  // Fallback to match 4 consecutive digits (e.g. 2007)
  if (!year || isNaN(year)) {
    const match = trimmed.match(/(19\d\d|20\d\d)/);
    if (match) {
      year = parseInt(match[1], 10);
    }
  }

  if (year && !isNaN(year) && year > 1920 && year <= referenceYear) {
    return {
      birthYear: year,
      age: Math.max(0, referenceYear - year)
    };
  }

  return { birthYear: '-', age: '-' };
}

/**
 * Normalizes gender to standard 'M' or 'F'
 */
export function normalizeGender(gender?: string, studentName?: string): 'M' | 'F' {
  if (gender) {
    const g = gender.trim().toUpperCase();
    if (g.startsWith('F') || g === 'FEMININO' || g === 'MULHER') return 'F';
    if (g.startsWith('M') || g === 'MASCULINO' || g === 'HOMEM') return 'M';
  }

  // Common Portuguese/Angolan feminine first names heuristic if gender is not specified
  if (studentName) {
    const firstName = studentName.trim().split(' ')[0].toLowerCase();
    const feminineEndings = ['a', 'ia', 'ina', 'da', 'ete', 'ice'];
    const feminineNames = ['maria', 'ana', 'beatriz', 'adelaide', 'albertina', 'amelia', 'anastacia', 'arelinha', 'arminda', 'teresa', 'claudia', 'eunice', 'nair'];
    if (feminineNames.includes(firstName) || feminineEndings.some(e => firstName.endsWith(e))) {
      return 'F';
    }
  }

  return 'M';
}

/**
 * Regras de Notas & Escala configuráveis em Configurações > Regras & Escala de Notas
 * (aba TabRegrasNotas). Isto é o "contrato" entre essa aba e todos os locais do
 * sistema que fazem cálculos de notas (Pautas, Mini-Pautas, Boletim). Antes, os
 * pesos e limiares estavam fixos no código (30/30/40, >=10, >=7, >=14...) e a aba
 * de configurações não tinha qualquer efeito real fora de si própria.
 */
export interface GradeRules {
  /** Peso da Avaliação Contínua (MAC), em percentagem 0-100 */
  macWeight: number;
  /** Peso da Prova Parcelar (NPP/PP), em percentagem 0-100 */
  ppWeight: number;
  /** Peso da Prova Trimestral (NPT/PT), em percentagem 0-100 */
  ptWeight: number;
  /** Nota mínima (0-20) para Transição Direta / Aprovação sem exame */
  passingGrade: number;
  /** Nota mínima (0-20) para ser elegível a Exame de Recurso (abaixo disto é reprovação direta) */
  recursoMinGrade: number;
  /** Classificação Anual Provisória (CAP) mínima para dispensa de Exame Final */
  examWaiverGrade: number;
  /** Aceita apenas notas com 1 casa decimal (ex: 14.5) */
  strictDecimal: boolean;
  /** Arredondamento oficial: médias com centésimas >= 0.50 arredondam para cima */
  roundHalfUp: boolean;
}

export const DEFAULT_GRADE_RULES: GradeRules = {
  macWeight: 30,
  ppWeight: 30,
  ptWeight: 40,
  passingGrade: 10.0,
  recursoMinGrade: 7.0,
  examWaiverGrade: 14.0,
  strictDecimal: true,
  roundHalfUp: true
};

/**
 * Normaliza o objeto `settings.gradeRules` (que pode ter nomes de campos legados,
 * ver o `[key: string]: any` em InstitutionSettings) para o formato de `GradeRules`
 * usado pelas funções de cálculo, preenchendo com a norma oficial MED quando um
 * campo não foi configurado.
 */
export function normalizeGradeRules(raw?: Partial<GradeRules> & Record<string, any> | null): GradeRules {
  if (!raw) return { ...DEFAULT_GRADE_RULES };
  return {
    macWeight: typeof raw.macWeight === 'number' ? raw.macWeight : DEFAULT_GRADE_RULES.macWeight,
    ppWeight: typeof raw.ppWeight === 'number' ? raw.ppWeight : DEFAULT_GRADE_RULES.ppWeight,
    ptWeight: typeof raw.ptWeight === 'number' ? raw.ptWeight : DEFAULT_GRADE_RULES.ptWeight,
    passingGrade: typeof raw.passingGrade === 'number' ? raw.passingGrade : DEFAULT_GRADE_RULES.passingGrade,
    recursoMinGrade: typeof raw.recursoMinGrade === 'number' ? raw.recursoMinGrade : DEFAULT_GRADE_RULES.recursoMinGrade,
    examWaiverGrade: typeof raw.examWaiverGrade === 'number' ? raw.examWaiverGrade : DEFAULT_GRADE_RULES.examWaiverGrade,
    strictDecimal: typeof raw.strictDecimal === 'boolean' ? raw.strictDecimal : (raw.strictDecimals ?? DEFAULT_GRADE_RULES.strictDecimal),
    roundHalfUp: typeof raw.roundHalfUp === 'boolean' ? raw.roundHalfUp : (raw.roundRuleHalfUp ?? DEFAULT_GRADE_RULES.roundHalfUp)
  };
}

function roundGrade(value: number, rules: GradeRules): number {
  // Arredondamento oficial MED: centésimas >= 0.50 sobem ao valor inteiro acima.
  // Quando desligado nas Configurações, simplesmente trunca a parte decimal.
  return rules.roundHalfUp ? Math.round(value) : Math.trunc(value);
}

/**
 * Calculates Trimester Average (MT) from MAC, NPP, NPT
 * Pondera pelos pesos definidos em Configurações > Regras & Escala de Notas
 * (por omissão, a norma oficial MED de Angola: MAC 30% + PP 30% + PT 40%).
 */
export function calculateMT(
  mac: number | '',
  npp: number | '',
  npt: number | '',
  rules: GradeRules = DEFAULT_GRADE_RULES
): number | '' {
  const m = typeof mac === 'number' ? mac : null;
  const p = typeof npp === 'number' ? npp : null;
  const t = typeof npt === 'number' ? npt : null;

  if (m === null && p === null && t === null) return '';

  const mVal = m ?? 0;
  const pVal = p ?? 0;
  const tVal = t ?? 0;

  const calculated = roundGrade(
    (mVal * (rules.macWeight / 100)) + (pVal * (rules.ppWeight / 100)) + (tVal * (rules.ptWeight / 100)),
    rules
  );
  return Math.max(0, Math.min(20, calculated));
}

/**
 * Calculates Final Discipline Average (MFD) from MT1, MT2, MT3 (and optionally PG)
 */
export function calculateMFD(
  mt1: number | '',
  mt2: number | '',
  mt3: number | '',
  pg?: number | '',
  rules: GradeRules = DEFAULT_GRADE_RULES
): number | '' {
  const grades = [mt1, mt2, mt3].filter((g): g is number => typeof g === 'number');
  if (grades.length === 0) return '';

  const avgContinuos = grades.reduce((acc, curr) => acc + curr, 0) / grades.length;

  if (typeof pg === 'number' && pg >= 0) {
    // With Global Exam: 60% continuous + 40% PG
    return Math.max(0, Math.min(20, roundGrade((avgContinuos * 0.6) + (pg * 0.4), rules)));
  }

  return Math.max(0, Math.min(20, roundGrade(avgContinuos, rules)));
}

/**
 * Calculates Annual Classification (CA)
 * Scale typically 1 to 5 or qualitative level matching Angolan technical high school
 */
export function calculateCA(mfd: number | ''): number | '' {
  if (typeof mfd !== 'number') return '';
  if (mfd >= 17) return 5;
  if (mfd >= 14) return 4;
  if (mfd >= 10) return 3;
  if (mfd >= 7) return 2;
  return 1;
}

/**
 * Classes de transição em que o Exame de Recurso é aplicável, conforme o ponto 2
 * do pedido: 6.ª, 9.ª, 12.ª e 13.ª classes do sistema angolano, e 1.º a 4.º ano
 * (equivalência usada noutros subsistemas/ensino superior técnico). Qualquer outra
 * classe não tem direito a Recurso: abaixo da nota de aprovação é reprovação direta.
 */
const TRANSITION_CLASS_PATTERNS: RegExp[] = [
  /\b6\s*[ºªA-Za-z]*\s*classe\b/i,
  /\b9\s*[ºªA-Za-z]*\s*classe\b/i,
  /\b12\s*[ºªA-Za-z]*\s*classe\b/i,
  /\b13\s*[ºªA-Za-z]*\s*classe\b/i,
  /\b1\s*[ºª]\s*(ano|classe)\b/i,
  /\b2\s*[ºª]\s*(ano|classe)\b/i,
  /\b3\s*[ºª]\s*(ano|classe)\b/i,
  /\b4\s*[ºª]\s*(ano|classe)\b/i
];

export function isTransitionClass(gradeOrClassLabel?: string | null): boolean {
  if (!gradeOrClassLabel) return false;
  const normalized = gradeOrClassLabel.toString().trim();
  return TRANSITION_CLASS_PATTERNS.some((re) => re.test(normalized));
}

export type PautaSituation = 'PENDENTE' | 'APROVADO' | 'REPROVADO' | 'DESISTIDO' | 'EXAME DE RECURSO';

/**
 * Situação do aluno com base nas notas reais, seguindo exatamente a regra da
 * imagem REGRAS (Módulo 04 — Regulamento de Avaliação):
 *  - Sem qualquer nota lançada ainda -> PENDENTE (nunca "Apto" por omissão).
 *  - Desistente -> DESISTIDO.
 *  - Nota final >= passingGrade (norma MED: 10.0) -> APROVADO (Transição Direta).
 *  - Nota final entre recursoMinGrade e passingGrade (norma MED: 7.0 a 9.9) ->
 *    EXAME DE RECURSO, mas APENAS nas classes de transição (6ª, 9ª, 12ª, 13ª, 1ª-4ª);
 *    nas restantes classes esse intervalo é reprovação direta.
 *  - Nota final < recursoMinGrade -> REPROVADO (Retenção automática).
 */
export function calculateSituation(params: {
  finalGrade: number | '';
  hasAnyGrade: boolean;
  isDesistente: boolean;
  classGrade?: string | null;
  rules?: GradeRules;
}): PautaSituation {
  const { finalGrade, hasAnyGrade, isDesistente, classGrade, rules = DEFAULT_GRADE_RULES } = params;

  if (isDesistente) return 'DESISTIDO';
  if (!hasAnyGrade || typeof finalGrade !== 'number') return 'PENDENTE';

  if (finalGrade >= rules.passingGrade) return 'APROVADO';

  if (finalGrade >= rules.recursoMinGrade && isTransitionClass(classGrade)) {
    return 'EXAME DE RECURSO';
  }

  return 'REPROVADO';
}

/**
 * Standard authentic student dataset matching Image 2
 */
export const IMAGE_2_STUDENTS_SEED: Array<Partial<StudentMiniPautaItem>> = [
  {
    num: 1,
    name: 'Abel Capusso Vissapa Sabino',
    gender: 'M',
    mac1: 9, npp1: 12, npt1: 10, mt1: 10,
    mac2: 8, npp2: 12, npt2: 9, mt2: 10,
    mac3: 5, npp3: 9, npt3: 12, mt3: 9,
    mfd: 10, pg: '', ca: 4, obs: ''
  },
  {
    num: 2,
    name: 'Adelaide Evalina Cafeca',
    gender: 'F',
    mac1: 5, npp1: 5, npt1: 4, mt1: 5,
    mac2: 10, npp2: 5, npt2: 6, mt2: 7,
    mac3: 8, npp3: 10, npt3: 8, mt3: 9,
    mfd: 7, pg: '', ca: 3, obs: ''
  },
  {
    num: 3,
    name: 'Albertina Nanguelo Syei',
    gender: 'F',
    mac1: 7, npp1: 10, npt1: 3, mt1: 7,
    mac2: 10, npp2: 10, npt2: 9, mt2: 10,
    mac3: 18, npp3: 10, npt3: 9, mt3: 12,
    mfd: 10, pg: '', ca: 4, obs: ''
  },
  {
    num: 4,
    name: 'Amelia Namilitali Furtoso',
    gender: 'F',
    isDesistente: true,
    mac1: '', npp1: '', npt1: '', mt1: '',
    mac2: '', npp2: '', npt2: '', mt2: '',
    mac3: '', npp3: '', npt3: '', mt3: '',
    mfd: '', pg: '', ca: '', obs: 'Desistente'
  },
  {
    num: 5,
    name: 'Anastácia Maria Nachilombo',
    gender: 'F',
    isDesistente: true,
    mac1: '', npp1: '', npt1: '', mt1: '',
    mac2: '', npp2: '', npt2: '', mt2: '',
    mac3: '', npp3: '', npt3: '', mt3: '',
    mfd: '', pg: '', ca: '', obs: 'Desistente'
  },
  {
    num: 6,
    name: 'André Samanjata Nandala',
    gender: 'M',
    mac1: 8, npp1: 11, npt1: 6, mt1: 8,
    mac2: 11, npp2: 12, npt2: 6, mt2: 10,
    mac3: 10, npp3: 12, npt3: 10, mt3: 11,
    mfd: 10, pg: '', ca: 4, obs: ''
  },
  {
    num: 7,
    name: 'Apolo Kassicote Chapopia',
    gender: 'M',
    mac1: 5, npp1: 6, npt1: 3, mt1: 5,
    mac2: 5, npp2: 8, npt2: 5, mt2: 6,
    mac3: 8, npp3: 10, npt3: 8, mt3: 9,
    mfd: 6, pg: '', ca: 3, obs: ''
  },
  {
    num: 8,
    name: 'Arelinha Sitati Baptista Lucas',
    gender: 'F',
    mac1: 5, npp1: 5, npt1: 5, mt1: 5,
    mac2: 5, npp2: 6, npt2: 7, mt2: 6,
    mac3: 5, npp3: 8, npt3: 6, mt3: 6,
    mfd: 6, pg: '', ca: 2, obs: ''
  },
  {
    num: 9,
    name: 'Arminda Ng. C. Siliveli',
    gender: 'F',
    mac1: 7, npp1: 10, npt1: 5, mt1: 7,
    mac2: 10, npp2: 15, npt2: 10, mt2: 12,
    mac3: 5, npp3: 12, npt3: 12, mt3: 10,
    mfd: 10, pg: '', ca: 4, obs: ''
  },
  {
    num: 10,
    name: 'Aurélio Sambulungo Felix',
    gender: 'M',
    mac1: 5, npp1: 5, npt1: 6, mt1: 5,
    mac2: 10, npp2: 6, npt2: 9, mt2: 8,
    mac3: 18, npp3: 13, npt3: 9, mt3: 13,
    mfd: 9, pg: '', ca: 4, obs: ''
  }
];

/**
 * Initializes Mini-Pauta records combining class students with subject-specific grades
 */
export function buildMiniPautaRows(
  classStudents: Student[],
  subjectId: string,
  allStudents: Student[],
  savedGradesMap?: Record<string, StudentMiniPautaItem>,
  rawRules?: Partial<GradeRules> | null
): StudentMiniPautaItem[] {
  const rules = normalizeGradeRules(rawRules);
  // Apenas os alunos REALMENTE matriculados na turma. Nunca "os primeiros 10 da
  // escola": mostrar alunos de outras turmas numa mini-pauta é um erro pedagógico
  // e uma fuga de dados entre turmas.
  void allStudents;
  const sourceList = classStudents;

  return sourceList.map((st, idx) => {
    const { birthYear, age } = calculateBirthYearAndAge(st.birthDate);
    const gender = normalizeGender(st.gender, st.name);
    const isDebtor = st.financialStatus === 'debito' || !st.isTuitionPaidCurrentMonth;
    const isDesistente = st.status === 'suspended' || st.status === 'transferred';
    const name = st.name || '';

    // 1. Notas editadas/guardadas nesta sessão para esta disciplina.
    if (savedGradesMap && savedGradesMap[st.id]) {
      const saved = savedGradesMap[st.id];
      return {
        ...saved,
        num: idx + 1,
        name: st.name || saved.name,
        gender,
        isDebtor,
        isDesistente: isDesistente || saved.isDesistente
      };
    }

    // 2. Notas trimestrais realmente lançadas na base de dados.
    const realTrimester = st.trimesterGrades?.find(
      (tg) => String(tg.subjectId) === String(subjectId)
    );
    if (realTrimester && !isDesistente) {
      // Recalcula MT1/MT2/MT3/MFD a partir do MAC/NPP/NPT gravados em vez de
      // confiar no mt1/mfd tal como está na base de dados. Registos criados
      // antes desta correção (ou gravados por uma versão anterior com bug)
      // tinham mt1/mt2/mt3/mfd fixados em 0 mesmo com MAC/NPP/NPT lançados,
      // e ficavam "presos" nesse valor para sempre, pois o cálculo só corria
      // quando o professor editava manualmente uma célula.
      const mt1 = calculateMT(realTrimester.mac1, realTrimester.npp1, realTrimester.npt1, rules);
      const mt2 = calculateMT(realTrimester.mac2, realTrimester.npp2, realTrimester.npt2, rules);
      const mt3 = calculateMT(realTrimester.mac3, realTrimester.npp3, realTrimester.npt3, rules);
      const pg = realTrimester.pg ?? '';
      const mfd = calculateMFD(mt1, mt2, mt3, pg, rules);
      return {
        id: `${st.id}-${subjectId}`,
        studentId: st.id,
        num: idx + 1,
        name,
        gender,
        birthYear,
        age,
        isDebtor,
        isDesistente: false,
        mac1: realTrimester.mac1,
        npp1: realTrimester.npp1,
        npt1: realTrimester.npt1,
        mt1,
        mac2: realTrimester.mac2,
        npp2: realTrimester.npp2,
        npt2: realTrimester.npt2,
        mt2,
        mac3: realTrimester.mac3,
        npp3: realTrimester.npp3,
        npt3: realTrimester.npt3,
        mt3,
        mfd,
        pg,
        ca: mfd === '' ? '' : calculateCA(mfd),
        obs: realTrimester.situation || ''
      };
    }

    // 3. Sem notas lançadas: a linha fica VAZIA, pronta para o docente preencher.
    //    Nunca se inventam notas — anteriormente era gerado um valor determinístico
    //    a partir de um hash do id do aluno, o que produzia pautas credíveis mas falsas.
    return {
      id: `${st.id}-${subjectId}`,
      studentId: st.id,
      num: idx + 1,
      name,
      gender,
      birthYear,
      age,
      isDebtor,
      isDesistente,
      mac1: '',
      npp1: '',
      npt1: '',
      mt1: '',
      mac2: '',
      npp2: '',
      npt2: '',
      mt2: '',
      mac3: '',
      npp3: '',
      npt3: '',
      mt3: '',
      mfd: '',
      pg: '',
      ca: '',
      obs: isDesistente ? 'Desistente' : ''
    };
  });
}

export function buildPautaGeralRows(
  classStudents: Student[],
  subjects: Subject[],
  allStudents: Student[],
  allDisciplineGradesMap?: Record<string, Record<string, StudentMiniPautaItem>>,
  classGrade?: string | null,
  rawRules?: Partial<GradeRules> | null
): StudentPautaGeralItem[] {
  const rules = normalizeGradeRules(rawRules);
  // Apenas os alunos REALMENTE matriculados na turma — nunca um "top 10" de alunos
  // de outras turmas da instituição (fuga de dados entre turmas).
  void allStudents;
  const sourceList = classStudents;

  return sourceList.map((st, idx) => {
    const { birthYear, age } = calculateBirthYearAndAge(st.birthDate);
    const gender = normalizeGender(st.gender, st.name);
    const isDebtor = st.financialStatus === 'debito' || !st.isTuitionPaidCurrentMonth;
    const isDesistente = st.status === 'suspended' || st.status === 'transferred';
    const name = st.name || `Aluno ${idx + 1}`;

    const subjectGrades: Record<string, { mt1: number | ''; mt2: number | ''; mt3: number | ''; mfd: number | '' }> = {};
    const mfdValues: number[] = [];

    subjects.forEach((subj) => {
      if (isDesistente) {
        subjectGrades[subj.id] = { mt1: '', mt2: '', mt3: '', mfd: '' };
        return;
      }

      // 1. Check if we have saved/edited grades in Mini-Pauta for this subject and student
      const savedRow = allDisciplineGradesMap?.[subj.id]?.[st.id];
      if (savedRow) {
        subjectGrades[subj.id] = {
          mt1: savedRow.mt1,
          mt2: savedRow.mt2,
          mt3: savedRow.mt3,
          mfd: savedRow.mfd
        };
        if (typeof savedRow.mfd === 'number') {
          mfdValues.push(savedRow.mfd);
        }
        return;
      }

      // 2. Check if student has real recorded trimester grades in the database
      const realTrimester = st.trimesterGrades?.find(
        (tg) => String(tg.subjectId) === String(subj.id) || tg.subjectName.toLowerCase() === subj.name.toLowerCase()
      );
      if (realTrimester) {
        // Recalcula MT1/MT2/MT3/MFD a partir do MAC/NPP/NPT gravados em vez de
        // confiar no mt1/mfd tal como está na base de dados (ver mesma correção
        // em buildMiniPautaRows): registos antigos/importados podiam ter ficado
        // com mt1/mt2/mt3/mfd em 0 apesar do MAC/NPP/NPT estarem lançados.
        const mt1 = calculateMT(realTrimester.mac1, realTrimester.npp1, realTrimester.npt1, rules);
        const mt2 = calculateMT(realTrimester.mac2, realTrimester.npp2, realTrimester.npt2, rules);
        const mt3 = calculateMT(realTrimester.mac3, realTrimester.npp3, realTrimester.npt3, rules);
        const mfd = calculateMFD(mt1, mt2, mt3, realTrimester.pg ?? '', rules);
        subjectGrades[subj.id] = { mt1, mt2, mt3, mfd };
        if (typeof mfd === 'number') {
          mfdValues.push(mfd);
        }
        return;
      }

      // 3. Check if student has recorded discipline score in the database
      const realDisc = st.disciplineGrades?.find(
        (dg) => dg.subject.toLowerCase() === subj.name.toLowerCase()
      );
      if (realDisc && typeof realDisc.score === 'number') {
        const sc = Math.round(realDisc.score);
        subjectGrades[subj.id] = { mt1: sc, mt2: sc, mt3: sc, mfd: sc };
        mfdValues.push(sc);
        return;
      }

      // 4. Sem notas lançadas em qualquer fonte real: a célula fica VAZIA.
      //    Nunca se inventam notas — anteriormente era gerado um valor determinístico
      //    a partir de um hash do id do aluno, o que produzia pautas credíveis mas falsas
      //    (uma instituição recém-criada sem provas feitas não pode ter médias).
      subjectGrades[subj.id] = { mt1: '', mt2: '', mt3: '', mfd: '' };
    });

    // Sem notas lançadas em NENHUMA disciplina, a situação nunca deve ser "Apto"
    // por omissão — fica PENDENTE até existir pelo menos uma nota real, tal como
    // já acontecia na Mini-Pauta. O cálculo de Aprovado/Reprovado/Exame de Recurso
    // segue as regras oficiais (imagem REGRAS) e os limiares configurados em
    // Configurações > Regras & Escala de Notas.
    let mf: number | '' = '';
    if (mfdValues.length > 0) {
      mf = roundGrade(mfdValues.reduce((a, b) => a + b, 0) / mfdValues.length, rules);
    }
    const situation = calculateSituation({
      finalGrade: mf,
      hasAnyGrade: mfdValues.length > 0,
      isDesistente,
      classGrade,
      rules
    });

    return {
      id: `pauta-geral-${st.id || idx}`,
      studentId: st.id || `stu-${idx + 1}`,
      num: idx + 1,
      name,
      gender,
      birthYear,
      age,
      isDebtor,
      isDesistente,
      subjectGrades,
      mf,
      situation
    };
  });
}
