/**
 * Tema visual da aplicação.
 *
 * Existem dois temas:
 *  - 'padrao'  : o visual institucional original (azul-marinho, cantos retos).
 *  - 'laravel' : herança visual do Laravel 12 — fundo quase branco, cartões de
 *                borda fina, cantos suaves, tipografia Instrument Sans e o
 *                laranja-avermelhado da marca Laravel nos destaques.
 *
 * O tema é aplicado através do atributo `data-ui-theme` no elemento <html>. As
 * regras que dão o aspeto Laravel vivem todas em src/styles/theme-laravel.css e
 * atuam sobre as próprias classes utilitárias já usadas nos componentes — por
 * isso valem tanto para os ecrãs que já existem como para tudo o que for criado
 * de novo, sem ser preciso tocar em cada ficheiro.
 */

import { useEffect, useState } from 'react';

export type UiThemeId = 'padrao' | 'laravel';

export const UI_THEME_STORAGE_KEY = 'bandmed_ui_theme';

export const UI_THEMES: Array<{ id: UiThemeId; label: string; description: string; icon: string }> = [
  {
    id: 'padrao',
    label: 'Visual Padrão',
    description: 'Identidade institucional BandMed: azul-marinho, cantos retos e alto contraste.',
    icon: 'account_balance'
  },
  {
    id: 'laravel',
    label: 'Moderno (Laravel)',
    description: 'Herança visual do Laravel 12: superfícies claras, bordas finas e cantos suaves.',
    icon: 'auto_awesome'
  }
];

function isValidTheme(value: unknown): value is UiThemeId {
  return value === 'padrao' || value === 'laravel';
}

/** O tema para o qual o botão de alternância deve mudar ao ser clicado. */
export function nextUiTheme(current: UiThemeId): UiThemeId {
  return current === 'laravel' ? 'padrao' : 'laravel';
}

/**
 * Ícone do botão de alternância de tema (Material Symbols), sempre apenas um
 * ícone, sem texto: círculo inteiro quando o Laravel está ativo, meio círculo
 * (ícone "contrast") quando o Visual Padrão está ativo.
 */
export function uiThemeToggleIcon(theme: UiThemeId): string {
  return theme === 'laravel' ? 'circle' : 'contrast';
}

/** Texto de apoio (tooltip/aria-label) para o botão de alternância. */
export function uiThemeToggleLabel(theme: UiThemeId): string {
  return theme === 'laravel'
    ? 'Tema atual: Moderno (Laravel) — clique para voltar ao Visual Padrão'
    : 'Tema atual: Visual Padrão — clique para mudar para o Moderno (Laravel)';
}

/** Lê o tema gravado no navegador; 'padrao' quando nada foi escolhido ainda. */
export function getStoredUiTheme(): UiThemeId {
  if (typeof window === 'undefined') return 'padrao';
  try {
    const stored = localStorage.getItem(UI_THEME_STORAGE_KEY);
    return isValidTheme(stored) ? stored : 'padrao';
  } catch {
    return 'padrao';
  }
}

type Listener = (theme: UiThemeId) => void;
const listeners = new Set<Listener>();

/**
 * Aplica o tema ao documento e grava a escolha. Deve ser chamado o mais cedo
 * possível no arranque (ver main.tsx) para que a página nunca chegue a aparecer
 * com o tema errado.
 */
export function applyUiTheme(theme: UiThemeId, persist = true): void {
  if (typeof document !== 'undefined') {
    document.documentElement.setAttribute('data-ui-theme', theme);
  }
  if (persist) {
    try {
      localStorage.setItem(UI_THEME_STORAGE_KEY, theme);
    } catch {
      // Navegador sem armazenamento disponível: o tema vale só para esta sessão.
    }
  }
  listeners.forEach((listener) => listener(theme));
}

/** Aplica o tema guardado. Usado no arranque da aplicação. */
export function initUiTheme(): UiThemeId {
  const theme = getStoredUiTheme();
  applyUiTheme(theme, false);
  return theme;
}

/**
 * Hook de leitura/escrita do tema. Mantém-se sincronizado entre componentes e
 * entre separadores do navegador.
 */
export function useUiTheme(): [UiThemeId, (theme: UiThemeId) => void] {
  const [theme, setThemeState] = useState<UiThemeId>(() => getStoredUiTheme());

  useEffect(() => {
    const listener: Listener = (next) => setThemeState(next);
    listeners.add(listener);

    const onStorage = (event: StorageEvent) => {
      if (event.key === UI_THEME_STORAGE_KEY && isValidTheme(event.newValue)) {
        applyUiTheme(event.newValue, false);
        setThemeState(event.newValue);
      }
    };
    window.addEventListener('storage', onStorage);

    return () => {
      listeners.delete(listener);
      window.removeEventListener('storage', onStorage);
    };
  }, []);

  return [theme, (next: UiThemeId) => applyUiTheme(next)];
}
