import React, { useMemo, useState } from 'react';
import {
  SchoolDatabase,
  SchoolVehicle,
  TransportRoute,
  TransportRouteStop,
  TransportShift,
  UserRole,
  VehicleStatus
} from '../types';
import { dbService } from '../services/db';
import { useAccessControl } from '../hooks/useAccessControl';
import { SearchableSelect } from '../components/SearchableSelect';
import {
  LogisticsBadge,
  LogisticsDeleteModal,
  LogisticsFormFooter,
  LogisticsIconButton,
  LogisticsKpiGrid,
  LogisticsModal,
  LogisticsPageHeader,
  LogisticsPrimaryButton,
  LogisticsSearchBar,
  LogisticsSectionTitle,
  LogisticsTableCard,
  cleanText,
  formatKz,
  logisticsInputCls as inputCls,
  logisticsLabelCls as labelCls,
  logisticsSelectCls,
  logisticsThCls,
  runGlobalOperation
} from '../components/LogisticsUi';

interface TransporteEscolarViewProps {
  db: SchoolDatabase;
  currentUserRole: UserRole;
}

const RULE = 'patrimonio.transporte.manage';

export const VEHICLE_STATUS_LABELS: Record<VehicleStatus, string> = {
  ativo: 'Ativa',
  manutencao: 'Em manutenção',
  inativo: 'Inativa'
};

export const TRANSPORT_SHIFT_LABELS: Record<TransportShift, string> = {
  manha: 'Manhã',
  tarde: 'Tarde',
  ambos: 'Manhã e Tarde'
};

type VehicleForm = Omit<SchoolVehicle, 'id' | 'code' | 'createdAt' | 'capacity'> & { capacity: string };

const emptyVehicleForm = (): VehicleForm => ({
  plate: '',
  model: '',
  capacity: '',
  driverName: '',
  driverPhone: '',
  driverLicenseNumber: '',
  status: 'ativo',
  notes: ''
});

type RouteForm = {
  name: string;
  vehicleId: string;
  shift: TransportShift;
  monthlyFee: string;
  status: 'ativa' | 'inativa';
  stops: TransportRouteStop[];
  notes: string;
};

const emptyRouteForm = (): RouteForm => ({
  name: '',
  vehicleId: '',
  shift: 'ambos',
  monthlyFee: '',
  status: 'ativa',
  stops: [{ name: '', time: '' }],
  notes: ''
});

export const TransporteEscolarView: React.FC<TransporteEscolarViewProps> = ({ db, currentUserRole }) => {
  const acl = useAccessControl(currentUserRole);

  const [tab, setTab] = useState<'rotas' | 'viaturas'>('rotas');
  const [searchTerm, setSearchTerm] = useState('');

  const [vehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<SchoolVehicle | null>(null);
  const [vehicleForm, setVehicleForm] = useState<VehicleForm>(emptyVehicleForm());
  const [vehicleError, setVehicleError] = useState('');
  const [deletingVehicle, setDeletingVehicle] = useState<SchoolVehicle | null>(null);
  const [deleteVehicleError, setDeleteVehicleError] = useState('');

  const [routeModalOpen, setRouteModalOpen] = useState(false);
  const [editingRoute, setEditingRoute] = useState<TransportRoute | null>(null);
  const [routeForm, setRouteForm] = useState<RouteForm>(emptyRouteForm());
  const [routeError, setRouteError] = useState('');
  const [deletingRoute, setDeletingRoute] = useState<TransportRoute | null>(null);

  const [rosterRouteId, setRosterRouteId] = useState<string | null>(null);
  const [studentToAdd, setStudentToAdd] = useState('');
  const [rosterError, setRosterError] = useState('');

  const vehicles = db.vehicles || [];
  const routes = db.transportRoutes || [];
  const students = db.students || [];

  const vehicleById = useMemo(() => new Map(vehicles.map((v) => [v.id, v])), [vehicles]);
  const studentById = useMemo(() => new Map(students.map((s) => [s.id, s])), [students]);
  const rosterRoute = rosterRouteId ? routes.find((r) => r.id === rosterRouteId) || null : null;

  const totalRiders = useMemo(() => new Set(routes.flatMap((r) => r.studentIds)).size, [routes]);
  const totalSeats = vehicles.filter((v) => v.status === 'ativo').reduce((sum, v) => sum + v.capacity, 0);

  const q = searchTerm.trim().toLowerCase();
  const filteredRoutes = useMemo(
    () =>
      routes
        .filter(
          (r) =>
            !q ||
            r.name.toLowerCase().includes(q) ||
            r.code.toLowerCase().includes(q) ||
            (r.vehicleName || '').toLowerCase().includes(q) ||
            r.stops.some((s) => s.name.toLowerCase().includes(q))
        )
        .sort((a, b) => a.name.localeCompare(b.name, 'pt')),
    [routes, q]
  );
  const filteredVehicles = useMemo(
    () =>
      vehicles
        .filter(
          (v) =>
            !q ||
            v.plate.toLowerCase().includes(q) ||
            v.model.toLowerCase().includes(q) ||
            v.code.toLowerCase().includes(q) ||
            (v.driverName || '').toLowerCase().includes(q)
        )
        .sort((a, b) => a.plate.localeCompare(b.plate, 'pt')),
    [vehicles, q]
  );

  const run = async (action: () => void, loadingMessage: string): Promise<{ ok: boolean; error?: string }> => {
    try {
      await runGlobalOperation(action, { loadingMessage, requiredRule: RULE, userRole: currentUserRole });
      return { ok: true };
    } catch (err: any) {
      return { ok: false, error: err?.message };
    }
  };

  // ---------- Viaturas ----------
  const openAddVehicle = () => {
    setEditingVehicle(null);
    setVehicleForm(emptyVehicleForm());
    setVehicleError('');
    setVehicleModalOpen(true);
  };

  const openEditVehicle = (v: SchoolVehicle) => {
    setEditingVehicle(v);
    setVehicleForm({
      plate: v.plate,
      model: v.model,
      capacity: String(v.capacity),
      driverName: v.driverName || '',
      driverPhone: v.driverPhone || '',
      driverLicenseNumber: v.driverLicenseNumber || '',
      status: v.status,
      notes: v.notes || ''
    });
    setVehicleError('');
    setVehicleModalOpen(true);
  };

  const handleVehicleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!acl.can(RULE)) {
      acl.guard(RULE, () => undefined);
      return;
    }
    if (!vehicleForm.plate.trim()) return setVehicleError('Indique a matrícula da viatura.');
    if (!vehicleForm.model.trim()) return setVehicleError('Indique o modelo da viatura.');
    const capacity = Number(vehicleForm.capacity);
    if (!Number.isInteger(capacity) || capacity < 1) {
      return setVehicleError('A capacidade tem de ser um número inteiro de lugares (mínimo 1).');
    }
    const payload = {
      plate: vehicleForm.plate.trim().toUpperCase(),
      model: vehicleForm.model.trim(),
      capacity,
      driverName: cleanText(vehicleForm.driverName),
      driverPhone: cleanText(vehicleForm.driverPhone),
      driverLicenseNumber: cleanText(vehicleForm.driverLicenseNumber),
      status: vehicleForm.status,
      notes: cleanText(vehicleForm.notes)
    };
    let failure = '';
    const result = await run(
      () => {
        const r = editingVehicle ? dbService.updateVehicle(editingVehicle.id, payload) : dbService.addVehicle(payload);
        if (!r.success) {
          failure = r.error || '';
          throw new Error(r.error);
        }
      },
      editingVehicle ? 'A guardar alterações da viatura...' : 'A registar viatura...'
    );
    if (result.ok) setVehicleModalOpen(false);
    else setVehicleError(failure || result.error || 'Não foi possível guardar a viatura.');
  };

  const handleDeleteVehicle = async () => {
    if (!deletingVehicle) return;
    const target = deletingVehicle;
    let failure = '';
    const result = await run(() => {
      const r = dbService.deleteVehicle(target.id);
      if (!r.success) {
        failure = r.error || '';
        throw new Error(r.error);
      }
    }, `A eliminar viatura ${target.plate}...`);
    if (result.ok) {
      setDeletingVehicle(null);
      setDeleteVehicleError('');
    } else {
      setDeleteVehicleError(failure || result.error || 'Não foi possível eliminar a viatura.');
    }
  };

  // ---------- Rotas ----------
  const openAddRoute = () => {
    setEditingRoute(null);
    setRouteForm(emptyRouteForm());
    setRouteError('');
    setRouteModalOpen(true);
  };

  const openEditRoute = (r: TransportRoute) => {
    setEditingRoute(r);
    setRouteForm({
      name: r.name,
      vehicleId: r.vehicleId || '',
      shift: r.shift,
      monthlyFee: r.monthlyFeeKz !== undefined ? String(r.monthlyFeeKz) : '',
      status: r.status,
      stops: r.stops.length ? r.stops.map((s) => ({ name: s.name, time: s.time || '' })) : [{ name: '', time: '' }],
      notes: r.notes || ''
    });
    setRouteError('');
    setRouteModalOpen(true);
  };

  const updateStop = (idx: number, patch: Partial<TransportRouteStop>) =>
    setRouteForm({ ...routeForm, stops: routeForm.stops.map((s, i) => (i === idx ? { ...s, ...patch } : s)) });

  const handleRouteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!acl.can(RULE)) {
      acl.guard(RULE, () => undefined);
      return;
    }
    if (!routeForm.name.trim()) return setRouteError('Indique o nome da rota.');
    const stops = routeForm.stops
      .filter((s) => s.name.trim())
      .map((s) => ({ name: s.name.trim(), time: cleanText(s.time) }));
    if (stops.length === 0) return setRouteError('Adicione pelo menos uma paragem à rota.');
    const fee = routeForm.monthlyFee.trim() === '' ? undefined : Number(routeForm.monthlyFee.replace(',', '.'));
    if (fee !== undefined && (!Number.isFinite(fee) || fee < 0)) {
      return setRouteError('A mensalidade tem de ser um número igual ou superior a zero.');
    }
    const payload = {
      name: routeForm.name.trim(),
      vehicleId: cleanText(routeForm.vehicleId),
      shift: routeForm.shift,
      monthlyFeeKz: fee,
      status: routeForm.status,
      stops,
      notes: cleanText(routeForm.notes)
    };
    let failure = '';
    const result = await run(
      () => {
        const r = editingRoute ? dbService.updateTransportRoute(editingRoute.id, payload) : dbService.addTransportRoute(payload);
        if (!r.success) {
          failure = r.error || '';
          throw new Error(r.error);
        }
      },
      editingRoute ? 'A guardar alterações da rota...' : 'A registar rota...'
    );
    if (result.ok) setRouteModalOpen(false);
    else setRouteError(failure || result.error || 'Não foi possível guardar a rota.');
  };

  const handleDeleteRoute = async () => {
    if (!deletingRoute) return;
    const target = deletingRoute;
    setDeletingRoute(null);
    await run(() => {
      dbService.deleteTransportRoute(target.id);
    }, `A eliminar rota ${target.name}...`);
  };

  // ---------- Alunos da rota ----------
  const openRoster = (r: TransportRoute) => {
    setRosterRouteId(r.id);
    setStudentToAdd('');
    setRosterError('');
  };

  const studentOptions = useMemo(() => {
    if (!rosterRoute) return [];
    return students
      .filter((s) => s.status === 'active' && !rosterRoute.studentIds.includes(s.id))
      .sort((a, b) => a.name.localeCompare(b.name, 'pt'))
      .map((s) => ({ value: s.id, label: `${s.name} — ${s.className || s.grade} (${s.procNumber})` }));
  }, [students, rosterRoute]);

  const handleAddStudent = async () => {
    if (!rosterRoute || !studentToAdd) return;
    if (!acl.can(RULE)) {
      acl.guard(RULE, () => undefined);
      return;
    }
    let failure = '';
    const result = await run(() => {
      const r = dbService.assignStudentToRoute(rosterRoute.id, studentToAdd);
      if (!r.success) {
        failure = r.error || '';
        throw new Error(r.error);
      }
    }, 'A inscrever aluno na rota...');
    if (result.ok) {
      setStudentToAdd('');
      setRosterError('');
    } else {
      setRosterError(failure || result.error || 'Não foi possível inscrever o aluno.');
    }
  };

  const handleRemoveStudent = async (studentId: string) => {
    if (!rosterRoute) return;
    setRosterError('');
    await run(() => {
      dbService.removeStudentFromRoute(rosterRoute.id, studentId);
    }, 'A remover aluno da rota...');
  };

  const vehicleTone = (s: VehicleStatus): 'green' | 'amber' | 'slate' =>
    s === 'ativo' ? 'green' : s === 'manutencao' ? 'amber' : 'slate';

  const vehicleOptionsForRoute = vehicles
    .filter((v) => v.status === 'ativo' || v.id === routeForm.vehicleId)
    .sort((a, b) => a.plate.localeCompare(b.plate, 'pt'));

  const tabBtn = (key: 'rotas' | 'viaturas', label: string, icon: string, count: number) => (
    <button
      type="button"
      onClick={() => {
        setTab(key);
        setSearchTerm('');
      }}
      className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
        tab === key ? 'border-[#0b1f3a] text-[#0b1f3a]' : 'border-transparent text-slate-500 hover:text-[#0b1f3a]'
      }`}
    >
      <span className="material-symbols-outlined text-[18px]">{icon}</span>
      <span>{label}</span>
      <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">{count}</span>
    </button>
  );

  return (
    <div className="flex flex-col w-full gap-6 pb-12">
      <LogisticsPageHeader
        subsection="Transporte Escolar"
        title="Transporte Escolar"
        description="Viaturas e motoristas, rotas com paragens e horários, e os alunos inscritos em cada percurso."
        actions={
          acl.can(RULE) ? (
            <>
              <LogisticsPrimaryButton icon="directions_bus" label="NOVA VIATURA" onClick={openAddVehicle} variant="secondary" />
              <LogisticsPrimaryButton icon="add_road" label="NOVA ROTA" onClick={openAddRoute} />
            </>
          ) : undefined
        }
      />

      <LogisticsKpiGrid
        items={[
          { label: 'Viaturas', value: vehicles.length, icon: 'directions_bus' },
          { label: 'Rotas ativas', value: routes.filter((r) => r.status === 'ativa').length, icon: 'route' },
          { label: 'Alunos transportados', value: totalRiders, icon: 'groups' },
          { label: 'Lugares (viaturas ativas)', value: totalSeats, icon: 'airline_seat_recline_normal' }
        ]}
      />

      <div className="flex border-b border-slate-200">
        {tabBtn('rotas', 'Rotas', 'route', routes.length)}
        {tabBtn('viaturas', 'Viaturas', 'directions_bus', vehicles.length)}
      </div>

      <LogisticsSearchBar
        value={searchTerm}
        onChange={setSearchTerm}
        placeholder={tab === 'rotas' ? 'Pesquisar por rota, código, paragem ou viatura...' : 'Pesquisar por matrícula, modelo, código ou motorista...'}
      >
        <span className="text-xs text-slate-400 font-mono">
          {tab === 'rotas' ? filteredRoutes.length : filteredVehicles.length} registos
        </span>
      </LogisticsSearchBar>

      {tab === 'rotas' ? (
        <LogisticsTableCard>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#0b1f3a] text-white font-bold uppercase text-[10px] tracking-wider border-b border-slate-800">
                <th className="py-3.5 px-4 text-white">Rota & Código</th>
                <th className={logisticsThCls}>Viatura</th>
                <th className={logisticsThCls}>Turno</th>
                <th className={logisticsThCls}>Paragens</th>
                <th className={logisticsThCls}>Lotação</th>
                <th className={logisticsThCls}>Mensalidade</th>
                <th className={logisticsThCls}>Estado</th>
                <th className="py-3.5 px-4 text-right text-white">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRoutes.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                    Nenhuma rota registada ou encontrada. Clique em "NOVA ROTA" para criar a primeira.
                  </td>
                </tr>
              ) : (
                filteredRoutes.map((r) => {
                  const vehicle = r.vehicleId ? vehicleById.get(r.vehicleId) : undefined;
                  const cap = vehicle?.capacity;
                  const full = cap !== undefined && r.studentIds.length >= cap;
                  return (
                    <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#0b1f3a]">{r.name}</div>
                        <div className="mt-0.5 text-[11px] text-slate-500 font-mono">{r.code}</div>
                      </td>
                      <td className="py-3.5 px-3 text-slate-700">
                        {vehicle ? `${vehicle.plate} · ${vehicle.model}` : <span className="text-slate-400">Sem viatura</span>}
                      </td>
                      <td className="py-3.5 px-3 text-slate-600">{TRANSPORT_SHIFT_LABELS[r.shift]}</td>
                      <td className="py-3.5 px-3 text-slate-600 max-w-[220px]">
                        <div className="truncate" title={r.stops.map((s) => s.name).join(' → ')}>
                          {r.stops.map((s) => s.name).join(' → ')}
                        </div>
                        <span className="text-[11px] text-slate-400">
                          {r.stops.length} {r.stops.length === 1 ? 'paragem' : 'paragens'}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className={`font-mono font-bold ${full ? 'text-red-700' : 'text-slate-800'}`}>
                          {r.studentIds.length}
                          {cap !== undefined ? ` / ${cap}` : ''}
                        </span>
                        {full && <span className="ml-1.5"><LogisticsBadge tone="red">Lotada</LogisticsBadge></span>}
                      </td>
                      <td className="py-3.5 px-3 font-mono text-slate-700 whitespace-nowrap">{formatKz(r.monthlyFeeKz)}</td>
                      <td className="py-3.5 px-3">
                        <LogisticsBadge tone={r.status === 'ativa' ? 'green' : 'slate'}>
                          {r.status === 'ativa' ? 'Ativa' : 'Inativa'}
                        </LogisticsBadge>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <LogisticsIconButton icon="groups" title="Ver / gerir alunos da rota" onClick={() => openRoster(r)} />
                          {acl.can(RULE) && (
                            <>
                              <LogisticsIconButton icon="edit" title="Editar rota" hover="blue" onClick={() => openEditRoute(r)} />
                              <LogisticsIconButton icon="delete" title="Eliminar rota" hover="red" onClick={() => setDeletingRoute(r)} />
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </LogisticsTableCard>
      ) : (
        <LogisticsTableCard>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#0b1f3a] text-white font-bold uppercase text-[10px] tracking-wider border-b border-slate-800">
                <th className="py-3.5 px-4 text-white">Viatura & Código</th>
                <th className={logisticsThCls}>Capacidade</th>
                <th className={logisticsThCls}>Motorista</th>
                <th className={logisticsThCls}>Rotas</th>
                <th className={logisticsThCls}>Estado</th>
                <th className="py-3.5 px-4 text-right text-white">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredVehicles.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 text-xs">
                    Nenhuma viatura registada ou encontrada. Clique em "NOVA VIATURA" para adicionar a primeira.
                  </td>
                </tr>
              ) : (
                filteredVehicles.map((v) => {
                  const vRoutes = routes.filter((r) => r.vehicleId === v.id);
                  return (
                    <tr key={v.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#0b1f3a] font-mono">{v.plate}</div>
                        <div className="mt-0.5 text-[11px] text-slate-500">
                          {v.model} · <span className="font-mono">{v.code}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-3 font-mono text-slate-700">{v.capacity} lugares</td>
                      <td className="py-3.5 px-3">
                        {v.driverName ? (
                          <>
                            <div className="text-slate-800 font-semibold">{v.driverName}</div>
                            {v.driverPhone && (
                              <a href={`tel:${v.driverPhone}`} className="text-[11px] font-mono text-slate-600 hover:text-[#0b1f3a]">
                                {v.driverPhone}
                              </a>
                            )}
                          </>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-slate-600">
                        {vRoutes.length ? vRoutes.map((r) => r.name).join(', ') : <span className="text-slate-400">Nenhuma</span>}
                      </td>
                      <td className="py-3.5 px-3">
                        <LogisticsBadge tone={vehicleTone(v.status)}>{VEHICLE_STATUS_LABELS[v.status]}</LogisticsBadge>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {acl.can(RULE) && (
                            <>
                              <LogisticsIconButton icon="edit" title="Editar viatura" hover="blue" onClick={() => openEditVehicle(v)} />
                              <LogisticsIconButton
                                icon="delete"
                                title="Eliminar viatura"
                                hover="red"
                                onClick={() => {
                                  setDeleteVehicleError('');
                                  setDeletingVehicle(v);
                                }}
                              />
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </LogisticsTableCard>
      )}

      {/* Modal: Viatura */}
      {vehicleModalOpen && (
        <LogisticsModal
          title={editingVehicle ? 'Editar Viatura' : 'Nova Viatura'}
          subtitle={editingVehicle ? editingVehicle.code : 'Logística · Transporte Escolar'}
          icon="directions_bus"
          onClose={() => setVehicleModalOpen(false)}
        >
          <form onSubmit={handleVehicleSubmit} className="flex-1 overflow-y-auto p-6 text-xs space-y-5">
            <div className="space-y-3">
              <LogisticsSectionTitle icon="directions_bus">Viatura</LogisticsSectionTitle>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className={labelCls}>Matrícula *</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    value={vehicleForm.plate}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, plate: e.target.value })}
                    placeholder="LD-00-00-AA"
                    className={`${inputCls} font-mono uppercase`}
                  />
                </div>
                <div>
                  <label className={labelCls}>Modelo *</label>
                  <input
                    type="text"
                    value={vehicleForm.model}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, model: e.target.value })}
                    placeholder="Ex.: Toyota Coaster"
                    className={inputCls}
                  />
                </div>
                <div>
                  <label className={labelCls}>Capacidade (lugares) *</label>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    value={vehicleForm.capacity}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, capacity: e.target.value })}
                    className={`${inputCls} font-mono`}
                  />
                </div>
                <div>
                  <label className={labelCls}>Estado</label>
                  <select
                    value={vehicleForm.status}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, status: e.target.value as VehicleStatus })}
                    className={inputCls}
                  >
                    {Object.entries(VEHICLE_STATUS_LABELS).map(([k, l]) => (
                      <option key={k} value={k}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <LogisticsSectionTitle icon="badge">Motorista</LogisticsSectionTitle>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className={labelCls}>Nome</label>
                  <input
                    type="text"
                    value={vehicleForm.driverName || ''}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, driverName: e.target.value })}
                    className={inputCls}
                  />
                </div>
                <div>
                  <label className={labelCls}>Telefone</label>
                  <input
                    type="text"
                    value={vehicleForm.driverPhone || ''}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, driverPhone: e.target.value })}
                    placeholder="+244 9XX XXX XXX"
                    className={`${inputCls} font-mono`}
                  />
                </div>
                <div>
                  <label className={labelCls}>Nº da Carta de Condução</label>
                  <input
                    type="text"
                    value={vehicleForm.driverLicenseNumber || ''}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, driverLicenseNumber: e.target.value })}
                    className={`${inputCls} font-mono`}
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className={labelCls}>Observações</label>
                  <textarea
                    rows={2}
                    value={vehicleForm.notes || ''}
                    onChange={(e) => setVehicleForm({ ...vehicleForm, notes: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 text-slate-800 focus:border-[#0b1f3a] focus:outline-none text-xs"
                  />
                </div>
              </div>
            </div>

            <LogisticsFormFooter
              error={vehicleError}
              onCancel={() => setVehicleModalOpen(false)}
              submitLabel={editingVehicle ? 'Guardar Alterações' : 'Registar Viatura'}
            />
          </form>
        </LogisticsModal>
      )}

      {/* Modal: Rota */}
      {routeModalOpen && (
        <LogisticsModal
          title={editingRoute ? 'Editar Rota' : 'Nova Rota'}
          subtitle={editingRoute ? editingRoute.code : 'Logística · Transporte Escolar'}
          icon="add_road"
          onClose={() => setRouteModalOpen(false)}
        >
          <form onSubmit={handleRouteSubmit} className="flex-1 overflow-y-auto p-6 text-xs space-y-5">
            <div className="space-y-3">
              <LogisticsSectionTitle icon="route">Rota</LogisticsSectionTitle>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className={labelCls}>Nome da Rota *</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    value={routeForm.name}
                    onChange={(e) => setRouteForm({ ...routeForm, name: e.target.value })}
                    placeholder="Ex.: Viana — Escola (Manhã)"
                    className={inputCls}
                  />
                </div>
                <div>
                  <label className={labelCls}>Viatura</label>
                  <select
                    value={routeForm.vehicleId}
                    onChange={(e) => setRouteForm({ ...routeForm, vehicleId: e.target.value })}
                    className={inputCls}
                  >
                    <option value="">Sem viatura atribuída</option>
                    {vehicleOptionsForRoute.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.plate} · {v.model} ({v.capacity} lugares)
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Turno</label>
                  <select
                    value={routeForm.shift}
                    onChange={(e) => setRouteForm({ ...routeForm, shift: e.target.value as TransportShift })}
                    className={inputCls}
                  >
                    {Object.entries(TRANSPORT_SHIFT_LABELS).map(([k, l]) => (
                      <option key={k} value={k}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Mensalidade do Transporte (Kz)</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={routeForm.monthlyFee}
                    onChange={(e) => setRouteForm({ ...routeForm, monthlyFee: e.target.value })}
                    className={`${inputCls} font-mono`}
                  />
                </div>
                <div>
                  <label className={labelCls}>Estado</label>
                  <select
                    value={routeForm.status}
                    onChange={(e) => setRouteForm({ ...routeForm, status: e.target.value as 'ativa' | 'inativa' })}
                    className={inputCls}
                  >
                    <option value="ativa">Ativa</option>
                    <option value="inativa">Inativa</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <LogisticsSectionTitle icon="pin_drop">Paragens (por ordem de percurso)</LogisticsSectionTitle>
              <div className="space-y-2">
                {routeForm.stops.map((s, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-center font-mono text-[11px] text-slate-400 shrink-0">{idx + 1}</span>
                    <input
                      type="text"
                      value={s.name}
                      onChange={(e) => updateStop(idx, { name: e.target.value })}
                      placeholder="Local da paragem"
                      className={inputCls}
                    />
                    <input
                      type="time"
                      value={s.time || ''}
                      onChange={(e) => updateStop(idx, { time: e.target.value })}
                      className={`${inputCls} !w-28 shrink-0 font-mono`}
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setRouteForm({
                          ...routeForm,
                          stops: routeForm.stops.length > 1 ? routeForm.stops.filter((_, i) => i !== idx) : [{ name: '', time: '' }]
                        })
                      }
                      title="Remover paragem"
                      className="p-1.5 text-slate-400 hover:text-red-700 cursor-pointer shrink-0"
                    >
                      <span className="material-symbols-outlined text-[18px]">close</span>
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setRouteForm({ ...routeForm, stops: [...routeForm.stops, { name: '', time: '' }] })}
                  className="flex items-center gap-1.5 text-xs font-bold text-[#0b1f3a] hover:text-[#7a0c0c] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">add</span>
                  Adicionar paragem
                </button>
              </div>
              <div>
                <label className={labelCls}>Observações</label>
                <textarea
                  rows={2}
                  value={routeForm.notes}
                  onChange={(e) => setRouteForm({ ...routeForm, notes: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 text-slate-800 focus:border-[#0b1f3a] focus:outline-none text-xs"
                />
              </div>
            </div>

            <LogisticsFormFooter
              error={routeError}
              onCancel={() => setRouteModalOpen(false)}
              submitLabel={editingRoute ? 'Guardar Alterações' : 'Criar Rota'}
            />
          </form>
        </LogisticsModal>
      )}

      {/* Modal: Alunos da rota */}
      {rosterRoute && (
        <LogisticsModal
          title={rosterRoute.name}
          subtitle={`${rosterRoute.code} · ${TRANSPORT_SHIFT_LABELS[rosterRoute.shift]}`}
          icon="groups"
          badge={`${rosterRoute.studentIds.length}${
            rosterRoute.vehicleId && vehicleById.get(rosterRoute.vehicleId)
              ? ` / ${vehicleById.get(rosterRoute.vehicleId)!.capacity}`
              : ''
          } alunos`}
          onClose={() => setRosterRouteId(null)}
          widthCls="max-w-xl"
        >
          <div className="flex-1 overflow-y-auto p-6 text-xs space-y-5">
            <div>
              <LogisticsSectionTitle icon="pin_drop">Percurso</LogisticsSectionTitle>
              <ol className="mt-3 space-y-1.5">
                {rosterRoute.stops.map((s, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-700">
                    <span className="font-mono text-[11px] text-slate-400 w-5 text-right">{i + 1}</span>
                    <span className="flex-1">{s.name}</span>
                    {s.time && <span className="font-mono text-slate-500">{s.time}</span>}
                  </li>
                ))}
              </ol>
            </div>

            {acl.can(RULE) && rosterRoute.status === 'ativa' && (
              <div className="space-y-2">
                <LogisticsSectionTitle icon="person_add">Inscrever aluno</LogisticsSectionTitle>
                <div className="flex items-end gap-2">
                  <div className="flex-1">
                    <SearchableSelect
                      options={studentOptions}
                      value={studentToAdd}
                      onChange={setStudentToAdd}
                      placeholder="Pesquise por nome ou nº de processo..."
                      emptyMessage="Nenhum aluno ativo disponível"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddStudent}
                    disabled={!studentToAdd}
                    className="h-9 px-4 bg-[#0b1f3a] hover:bg-[#7a0c0c] disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-xs cursor-pointer transition-colors shrink-0"
                  >
                    Inscrever
                  </button>
                </div>
                {rosterError && (
                  <div className="bg-red-50 border border-red-200 text-red-800 px-3 py-2 text-xs font-semibold">{rosterError}</div>
                )}
              </div>
            )}

            <div className="space-y-2">
              <LogisticsSectionTitle icon="groups">Alunos inscritos</LogisticsSectionTitle>
              {rosterRoute.studentIds.length === 0 ? (
                <p className="text-slate-400 py-4 text-center">Ainda não há alunos inscritos nesta rota.</p>
              ) : (
                <ul className="divide-y divide-slate-100 border border-slate-200">
                  {rosterRoute.studentIds.map((sid) => {
                    const s = studentById.get(sid);
                    return (
                      <li key={sid} className="flex items-center gap-3 px-3 py-2">
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-[#0b1f3a] truncate">{s ? s.name : 'Aluno removido'}</div>
                          {s && (
                            <div className="text-[11px] text-slate-500">
                              {s.className || s.grade} · <span className="font-mono">{s.procNumber}</span>
                              {s.guardianPhone ? ` · Enc.: ${s.guardianPhone}` : ''}
                            </div>
                          )}
                        </div>
                        {acl.can(RULE) && (
                          <LogisticsIconButton icon="person_remove" title="Remover da rota" hover="red" onClick={() => handleRemoveStudent(sid)} />
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </LogisticsModal>
      )}

      {deletingRoute && (
        <LogisticsDeleteModal
          title="Eliminar Rota"
          name={deletingRoute.name}
          code={deletingRoute.code}
          extra={
            deletingRoute.studentIds.length
              ? `Os ${deletingRoute.studentIds.length} alunos inscritos deixarão de ter transporte atribuído.`
              : undefined
          }
          onCancel={() => setDeletingRoute(null)}
          onConfirm={handleDeleteRoute}
        />
      )}

      {deletingVehicle && (
        <div>
          <LogisticsDeleteModal
            title="Eliminar Viatura"
            name={`${deletingVehicle.plate} · ${deletingVehicle.model}`}
            code={deletingVehicle.code}
            extra={deleteVehicleError ? `⚠ ${deleteVehicleError}` : undefined}
            onCancel={() => setDeletingVehicle(null)}
            onConfirm={handleDeleteVehicle}
          />
        </div>
      )}
    </div>
  );
};
