import React, { useState, useEffect } from 'react';
import { dbService } from './services/db';
import { watchAuthState } from './services/auth';
import { SchoolDatabase, User, Student, UserRole } from './types';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { SqlExportModal } from './components/SqlExportModal';
import { ReportCardModal } from './components/ReportCardModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { OperationProvider, runGlobalOperation } from './context/OperationContext';
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { AlunosView } from './views/AlunosView';
import { ProfessoresView } from './views/ProfessoresView';
import { FuncionariosView } from './views/FuncionariosView';
import { DepartamentosView } from './views/DepartamentosView';
import { FornecedoresView } from './views/FornecedoresView';
import { InventarioAtivosView } from './views/InventarioAtivosView';
import { ControloEstoqueView } from './views/ControloEstoqueView';
import { TransporteEscolarView } from './views/TransporteEscolarView';
import { SaudeSegurancaView } from './views/SaudeSegurancaView';
import { TurmasView } from './views/TurmasView';
import { AssiduidadeView } from './views/AssiduidadeView';
import { PautasView } from './views/PautasView';
import { PropinasView } from './views/PropinasView';
import { RelatoriosView } from './views/RelatoriosView';
import { AvisosEBibliotecaView } from './views/AvisosEBibliotecaView';
import { ComunicacaoView } from './views/ComunicacaoView';
import { FolhaChamadaProvaView } from './views/FolhaChamadaProvaView';
import { VinculoFilhosView } from './views/VinculoFilhosView';
import { AdmissoesView } from './views/AdmissoesView';
import { BancoQuestoesView } from './views/BancoQuestoesView';
import { PlanoCurricularView } from './views/PlanoCurricularView';
import { ExtracurricularesView } from './views/ExtracurricularesView';
import { RefeitorioView } from './views/RefeitorioView';
import { FolhaPagamentoView } from './views/FolhaPagamentoView';
import { AvaliacaoDesempenhoDocenteView } from './views/AvaliacaoDesempenhoDocenteView';
import { FeriasLicencasView } from './views/FeriasLicencasView';
import { ConfiguracoesView } from './views/ConfiguracoesView';
import { AlunoPortalView } from './views/AlunoPortalView';
import { ImportarPautaExcelView } from './views/ImportarPautaExcelView';
import { HomologacaoPautaView } from './views/HomologacaoPautaView';
import { getFallbackAcademicYear } from './utils/academicYear';
import { useSessionPolicy } from './hooks/useSessionPolicy';
import { getPasswordStatus, enforceIpPolicy, requiresTwoFactor } from './services/securityPolicy';
import { SecurityPolicyBanner } from './components/SecurityPolicyBanner';

const getDefaultViewForRole = (role: UserRole): string => {
  if (role === 'aluno') return 'aluno_notas';
  if (role === 'encarregado') return 'encarregado_financeiro';
  if (role === 'professor') return 'pautas';
  // O Funcionário (pessoal não-docente) não tem acesso ao Dashboard de gestão;
  // a sua área inicial é o Mural de Avisos & Biblioteca.
  if (role === 'funcionario') return 'mural_biblioteca';
  return 'dashboard';
};

export default function App() {
  const [db, setDb] = useState<SchoolDatabase>(dbService.getDatabase());

  // The values restored from localStorage below are only an OPTIMISTIC first paint
  // (so a returning user doesn't flash the login screen). They are provisional until
  // the Firebase Auth listener below confirms a real, still-valid session — see
  // isAuthResolving / handleAuthStateResolved. A stale localStorage entry with no
  // matching Firebase token is never enough, by itself, to open the app.
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('bandmed_session_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Erro ao restaurar sessão:', e);
    }
    return null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const explicitLogout = sessionStorage.getItem('bandmed_explicit_logout');
      if (explicitLogout === 'true') return false;
      try {
        const savedSession = localStorage.getItem('bandmed_session_user');
        return !!savedSession;
      } catch {
        return false;
      }
    }
    return false;
  });
  // True until Firebase Auth has reported whether this browser actually holds a
  // valid session token. While true, the optimistic state above is not trusted yet.
  const [isAuthResolving, setIsAuthResolving] = useState<boolean>(true);
  const [currentView, setCurrentView] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('bandmed_session_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        return getDefaultViewForRole(parsed.role);
      }
    } catch {
      // ignore
    }
    return getDefaultViewForRole(currentUser?.role || 'admin');
  });
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);
  const [isDesktopSidebarOpen, setIsDesktopSidebarOpen] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('bandmed_sidebar_desktop_open');
      if (saved !== null) return saved === 'true';
    } catch {
      // ignore
    }
    return true;
  });

  const handleToggleSidebar = () => {
    if (typeof window !== 'undefined' && window.innerWidth < 1024) {
      setIsMobileNavOpen((prev) => !prev);
    } else {
      setIsDesktopSidebarOpen((prev) => {
        const next = !prev;
        try {
          localStorage.setItem('bandmed_sidebar_desktop_open', String(next));
        } catch {
          // ignore
        }
        return next;
      });
    }
  };

  // Modals state
  const [isSqlModalOpen, setIsSqlModalOpen] = useState<boolean>(false);
  const [reportCardStudent, setReportCardStudent] = useState<Student | null>(null);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState<boolean>(false);
  const [attendanceClassId, setAttendanceClassId] = useState<any>(undefined);
  // Aluno pré-seleccionado ao navegar de "Alunos" (Cadastro/Histórico) para a
  // secção "Matrículas", através do botão "Matricular" / "Nova Matrícula".
  const [matriculaStudentId, setMatriculaStudentId] = useState<string | undefined>(undefined);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState<boolean>(false);

  // Subscribe to reactive database changes
  useEffect(() => {
    const unsubscribe = dbService.subscribe((updated) => {
      setDb(updated);
    });
    return () => unsubscribe();
  }, []);

  // Calendário académico automático: o Trimestre em curso e a abertura de um novo
  // Ano Letivo passam a depender apenas das datas configuradas (ver
  // dbService.syncAcademicCalendar). Corre no arranque e de hora a hora, para que
  // a viragem aconteça mesmo com a aplicação aberta de um dia para o outro.
  useEffect(() => {
    dbService.syncAcademicCalendar();
    const timer = setInterval(() => dbService.syncAcademicCalendar(), 60 * 60 * 1000);
    return () => clearInterval(timer);
  }, []);

  // Backup Automático Agendado (Configurações > 9.): verifica no arranque e de
  // hora a hora se a rotina configurada já devia ter corrido; se sim, gera o
  // instantâneo e regista-o em backupHistory (ver dbService.runScheduledBackupIfDue).
  useEffect(() => {
    dbService.runScheduledBackupIfDue();
    const timer = setInterval(() => dbService.runScheduledBackupIfDue(), 60 * 60 * 1000);
    return () => clearInterval(timer);
  }, []);

  // Source of truth for session validity: Firebase Auth itself, not localStorage.
  // Runs once on boot and again whenever the token is refreshed, expires, or the
  // user signs out from another tab.
  useEffect(() => {
    const unsubscribe = watchAuthState(async (firebaseUser) => {
      const explicitLogout =
        typeof window !== 'undefined' && sessionStorage.getItem('bandmed_explicit_logout') === 'true';

      const profile = await dbService.restoreSession(explicitLogout ? null : firebaseUser?.uid || null);

      if (profile) {
        setCurrentUser(profile);
        setIsAuthenticated(true);
        setCurrentView((prev) => prev || getDefaultViewForRole(profile.role));
      } else {
        setCurrentUser(null);
        setIsAuthenticated(false);
      }
      setIsAuthResolving(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLoginSuccess = (user: User) => {
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('bandmed_explicit_logout');
    }
    setCurrentUser(user);
    setIsAuthenticated(true);
    setCurrentView(getDefaultViewForRole(user.role));
  };

  // ---------------------------------------------------------------------
  // POLÍTICAS DE SEGURANÇA (Configurações → 7. Segurança & Backups)
  // ---------------------------------------------------------------------

  // Termina a sessão automaticamente ao fim do tempo de inatividade
  // configurado, registando o encerramento na trilha de auditoria.
  const { warningSecondsLeft, keepAlive } = useSessionPolicy({
    active: isAuthenticated && !!currentUser,
    userName: currentUser?.name,
    onTimeout: () => {
      void dbService.logout();
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('bandmed_explicit_logout', 'true');
      }
      setCurrentUser(null);
      setIsAuthenticated(false);
    }
  });

  // Validade da palavra-passe: avisa com antecedência e assinala a expiração.
  const passwordStatus = React.useMemo(
    () => getPasswordStatus(currentUser),
    [currentUser, db.settings?.securityPolicies]
  );

  // Sub-redes autorizadas: só é verificado quando existem intervalos de IP
  // configurados; fora deles, a sessão é encerrada e o evento auditado.
  const [ipBlocked, setIpBlocked] = useState<{ ip: string | null; ranges: string[] } | null>(null);
  useEffect(() => {
    if (!isAuthenticated || !currentUser) return;
    let cancelled = false;
    void enforceIpPolicy().then((result) => {
      if (cancelled || result.allowed) return;
      setIpBlocked({ ip: result.ip, ranges: result.ranges });
      void dbService.logout();
      setCurrentUser(null);
      setIsAuthenticated(false);
    });
    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, currentUser?.id, db.settings?.allowedIpRanges]);

  const twoFactorPending = requiresTwoFactor(currentUser?.role);

  const handleLogoutClick = () => {
    setIsLogoutModalOpen(true);
  };

  const handleConfirmLogout = async () => {
    setIsLogoutModalOpen(false);
    await runGlobalOperation(
      async () => {
        await dbService.logout();
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('bandmed_explicit_logout', 'true');
        }
      },
      {
        loadingMessage: 'A terminar sessão no sistema com segurança...',
        successMessage: 'Sessão terminada com sucesso!'
      }
    );
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  const handleResetData = () => {
    if (confirm('Tem a certeza que deseja repor os registos padrão da instituição?')) {
      dbService.resetToDefaults();
      alert('Registos institucionais repostos com sucesso!');
    }
  };

  if (isAuthResolving) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-400">
          <span className="material-symbols-outlined text-4xl animate-spin">progress_activity</span>
          <span className="text-xs font-semibold uppercase tracking-wider">A verificar sessão...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !currentUser) {
    return (
      <OperationProvider>
        {ipBlocked && (
          <div className="fixed top-0 left-0 right-0 z-50 bg-[#b91c1c] text-white px-4 py-3 flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">gpp_bad</span>
            <span className="text-[11px] font-semibold">
              Acesso recusado: o posto de trabalho{ipBlocked.ip ? ` (${ipBlocked.ip})` : ''} não pertence às sub-redes
              autorizadas da instituição ({ipBlocked.ranges.join(', ')}). Contacte a Secretaria ou o Administrador Geral.
            </span>
          </div>
        )}
        <LoginView onLoginSuccess={handleLoginSuccess} />
      </OperationProvider>
    );
  }

  return (
    <OperationProvider>
      <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col font-body antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        currentView={currentView}
        onNavigate={setCurrentView}
        currentUserRole={currentUser.role}
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
        isDesktopOpen={isDesktopSidebarOpen}
        onToggleDesktop={(open) => {
          const next = typeof open === 'boolean' ? open : !isDesktopSidebarOpen;
          setIsDesktopSidebarOpen(next);
          try {
            localStorage.setItem('bandmed_sidebar_desktop_open', String(next));
          } catch {
            // ignore
          }
        }}
        onAutoCollapse={() => {
          // Recolhe o menu quando o rato sai da sua área. Deliberadamente NÃO grava a
          // preferência: só um clique explícito no botão de menu define o estado
          // guardado, para que o sidebar não passe a abrir sempre minimizado.
          setIsDesktopSidebarOpen(false);
        }}
        onLogout={handleLogoutClick}
      />

      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        currentAcademicYear={db.settings?.currentAcademicYear || getFallbackAcademicYear()}
        availableAcademicYears={
          db.settings?.availableAcademicYears || ['2024/2025', '2023/2024', '2022/2023', '2025/2026']
        }
        onAcademicYearChange={(year) => {
          dbService.setAcademicYear(year);
        }}
        onOpenMobileMenu={() => setIsMobileNavOpen(true)}
        isDesktopSidebarOpen={isDesktopSidebarOpen}
        onToggleSidebar={handleToggleSidebar}
        onOpenSqlExport={() => setIsSqlModalOpen(true)}
        onResetData={handleResetData}
        onLogout={handleLogoutClick}
        onNavigate={(view, targetId) => {
          if (view === 'assiduidade' && targetId) {
            setAttendanceClassId(targetId);
          }
          setCurrentView(view);
        }}
        db={db}
      />

      {/* Main Content Area */}
      <main className={`${isDesktopSidebarOpen ? 'lg:ml-64' : 'lg:ml-0'} pt-20 px-4 lg:px-8 flex-1 transition-all duration-300 min-w-0`}>
        <div className="max-w-7xl mx-auto">
          {/* Avisos das políticas de segurança em vigor */}
          <SecurityPolicyBanner
            inactivitySecondsLeft={warningSecondsLeft}
            onKeepAlive={keepAlive}
            passwordStatus={passwordStatus}
            twoFactorPending={twoFactorPending}
            onOpenSecuritySettings={() => setCurrentView('configuracoes')}
          />

          <ErrorBoundary onReset={() => setCurrentView(getDefaultViewForRole(currentUser.role))}>
            {/* Student & Guardian Portal Views */}
            {(currentView === 'aluno_notas' || (currentUser.role === 'aluno' && currentView === 'dashboard')) && (
              <AlunoPortalView
                db={db}
                currentUser={currentUser}
                currentUserRole={currentUser.role}
                initialTab="notas"
              />
            )}

            {currentView === 'aluno_financeiro' && (
              <AlunoPortalView
                db={db}
                currentUser={currentUser}
                currentUserRole={currentUser.role}
                initialTab="financeiro"
              />
            )}

            {(currentView === 'encarregado_financeiro' || (currentUser.role === 'encarregado' && currentView === 'dashboard')) && (
              <AlunoPortalView
                db={db}
                currentUser={currentUser}
                currentUserRole={currentUser.role}
                initialTab="financeiro"
              />
            )}

            {/* Dashboard: strictly restricted from Professor, Student, Guardian and Staff */}
            {currentView === 'dashboard' && currentUser.role !== 'professor' && currentUser.role !== 'aluno' && currentUser.role !== 'encarregado' && currentUser.role !== 'funcionario' && (
              <DashboardView
                db={db}
                onNavigate={setCurrentView}
                currentUserRole={currentUser.role}
                onOpenNewStudentModal={() => setCurrentView('alunos')}
                onOpenNoticeModal={() => {
                  setCurrentView('mural_biblioteca');
                  setIsNoticeModalOpen(true);
                }}
                onOpenReportCard={(student) => setReportCardStudent(student)}
              />
            )}

            {/* If a Professor lands on dashboard, show PautasView instead */}
            {currentView === 'dashboard' && currentUser.role === 'professor' && (
              <PautasView
                db={db}
                currentUserRole={currentUser.role}
                currentUser={currentUser}
              />
            )}

            {/* Se um Funcionário chegar à rota 'dashboard', mostra-se o Mural de Avisos */}
            {currentView === 'dashboard' && currentUser.role === 'funcionario' && (
              <AvisosEBibliotecaView
                db={db}
                currentUserRole={currentUser.role}
                isNoticeModalOpen={isNoticeModalOpen}
                setIsNoticeModalOpen={setIsNoticeModalOpen}
              />
            )}

            {currentView === 'alunos' && (
              <AlunosView
                db={db}
                currentUserRole={currentUser.role}
                onOpenReportCard={(student) => setReportCardStudent(student)}
                mode="cadastro"
                onNavigateToMatriculas={(studentId) => {
                  setMatriculaStudentId(studentId);
                  setCurrentView('matriculas');
                }}
              />
            )}

            {currentView === 'matriculas' && (
              <AlunosView
                db={db}
                currentUserRole={currentUser.role}
                onOpenReportCard={(student) => setReportCardStudent(student)}
                mode="matriculas"
                initialStudentId={matriculaStudentId}
                onNavigateToMatriculas={(studentId) => setMatriculaStudentId(studentId)}
              />
            )}

            {currentView === 'professores' && (
              <ProfessoresView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'funcionarios' && (
              <FuncionariosView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'departamentos' &&
              ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
                <DepartamentosView db={db} currentUserRole={currentUser.role} />
              )}

            {currentView === 'fornecedores' && ['admin', 'director'].includes(currentUser.role) && (
              <FornecedoresView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'inventario_ativos' && ['admin', 'director'].includes(currentUser.role) && (
              <InventarioAtivosView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'controlo_estoque' && ['admin', 'director'].includes(currentUser.role) && (
              <ControloEstoqueView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'transporte_escolar' && ['admin', 'director'].includes(currentUser.role) && (
              <TransporteEscolarView db={db} currentUserRole={currentUser.role} />
            )}

            {(currentView === 'saude_ficha_medica' ||
              currentView === 'saude_incidentes' ||
              currentView === 'saude_recolha') &&
              ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
                <SaudeSegurancaView
                  db={db}
                  currentUserRole={currentUser.role}
                  section={currentView as 'saude_ficha_medica' | 'saude_incidentes' | 'saude_recolha'}
                />
              )}

            {(currentView === 'turmas' ||
              currentView === 'disciplinas' ||
              currentView === 'horarios' ||
              currentView === 'cursos' ||
              currentView === 'mapa_salas') &&
              currentUser.role !== 'professor' && (
                <TurmasView
                  db={db}
                  currentUserRole={currentUser.role}
                  currentUser={currentUser}
                  section={currentView as 'turmas' | 'disciplinas' | 'horarios' | 'cursos' | 'mapa_salas'}
                  onNavigateToAttendance={(classId) => {
                    setAttendanceClassId(classId);
                    setCurrentView('assiduidade');
                  }}
                  onNavigateToStudents={() => setCurrentView('alunos')}
                  onNavigateToPautas={() => setCurrentView('pautas')}
                />
              )}

            {currentView === 'assiduidade' && (
              <AssiduidadeView
                db={db}
                currentUserRole={currentUser.role}
                currentUser={currentUser}
                initialClassId={attendanceClassId}
              />
            )}

            {currentView === 'pautas' && (
              <PautasView
                db={db}
                currentUserRole={currentUser.role}
                currentUser={currentUser}
                onNavigateToImport={() => setCurrentView('importar_pauta')}
              />
            )}

            {currentView === 'importar_pauta' && (
              <ImportarPautaExcelView
                db={db}
                currentUserRole={currentUser.role}
                currentUser={currentUser}
                onBackToPautas={() => setCurrentView('pautas')}
                onNavigateToHomologacao={() => setCurrentView('homologacao_pauta')}
              />
            )}

            {currentView === 'homologacao_pauta' && (
              <HomologacaoPautaView
                db={db}
                currentUserRole={currentUser.role}
                onBackToPautas={() => setCurrentView('pautas')}
                onNavigateToImport={() => setCurrentView('importar_pauta')}
              />
            )}

            {currentView === 'propinas' && (
              <PropinasView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'mural_biblioteca' && (
              <AvisosEBibliotecaView
                db={db}
                currentUserRole={currentUser.role}
                isNoticeModalOpen={isNoticeModalOpen}
                setIsNoticeModalOpen={setIsNoticeModalOpen}
              />
            )}

            {(currentView === 'comunicacao_notificacoes' ||
              currentView === 'comunicacao_reunioes' ||
              currentView === 'comunicacao_chat') &&
              ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
                <ComunicacaoView
                  db={db}
                  currentUserRole={currentUser.role}
                  section={currentView as 'comunicacao_notificacoes' | 'comunicacao_reunioes' | 'comunicacao_chat'}
                />
              )}

            {currentView === 'folha_chamada_prova' && (
              <FolhaChamadaProvaView db={db} currentUserRole={currentUser.role} currentUser={currentUser} />
            )}

            {currentView === 'vinculo_filhos' && ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
              <VinculoFilhosView db={db} currentUserRole={currentUser.role} currentUser={currentUser} />
            )}

            {currentView === 'admissoes' && ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
              <AdmissoesView
                db={db}
                currentUserRole={currentUser.role}
                currentUser={currentUser}
                onNavigateToMatriculas={(studentId) => {
                  setMatriculaStudentId(studentId);
                  setCurrentView('matriculas');
                }}
              />
            )}

            {currentView === 'banco_questoes' && ['admin', 'director', 'professor'].includes(currentUser.role) && (
              <BancoQuestoesView db={db} currentUserRole={currentUser.role} currentUser={currentUser} />
            )}

            {currentView === 'plano_curricular' && ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
              <PlanoCurricularView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'atividades_extracurriculares' && ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
              <ExtracurricularesView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'refeitorio' && ['admin', 'director', 'secretaria'].includes(currentUser.role) && (
              <RefeitorioView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'folha_pagamento' && ['admin', 'director'].includes(currentUser.role) && (
              <FolhaPagamentoView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'avaliacao_desempenho_docente' && ['admin', 'director'].includes(currentUser.role) && (
              <AvaliacaoDesempenhoDocenteView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'ferias_licencas' && ['admin', 'director'].includes(currentUser.role) && (
              <FeriasLicencasView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView === 'relatorios' && (
              <RelatoriosView db={db} currentUserRole={currentUser.role} />
            )}

            {currentView.startsWith('configuracoes') && (
              <ConfiguracoesView
                db={db}
                currentUserRole={currentUser.role}
                onOpenSqlExport={() => setIsSqlModalOpen(true)}
                onResetData={handleResetData}
                initialTab={
                  currentView.includes('/')
                    ? (currentView.split('/')[1] as any)
                    : undefined
                }
              />
            )}
          </ErrorBoundary>
        </div>
      </main>

      {/* SQL Export Modal */}
      <SqlExportModal
        db={db}
        isOpen={isSqlModalOpen}
        onClose={() => setIsSqlModalOpen(false)}
      />

      {/* Official Report Card Modal */}
      {reportCardStudent && (
        <ErrorBoundary onReset={() => setReportCardStudent(null)}>
          <ReportCardModal
            student={reportCardStudent}
            db={db}
            onClose={() => setReportCardStudent(null)}
          />
        </ErrorBoundary>
      )}

      {/* Modal: Confirmação ao Terminar Sessão */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-none max-w-md w-full shadow-2xl overflow-hidden border border-slate-300">
            <div className="px-6 py-4 bg-[#0b1f3a] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[20px] text-red-400">warning</span>
                <h3 className="font-bold text-base">Terminar Sessão</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsLogoutModalOpen(false)}
                className="text-slate-300 hover:text-white p-1 hover:bg-white/10 transition-colors cursor-pointer"
                title="Fechar"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="p-6">
              <div className="w-12 h-12 rounded-none bg-red-100 text-[#ac332b] flex items-center justify-center mx-auto mb-4 border border-red-200">
                <span className="material-symbols-outlined text-[28px]">logout</span>
              </div>
              <h3 className="font-headline text-lg font-bold text-slate-900 text-center">
                Terminar Sessão no Sistema?
              </h3>
              <p className="text-xs text-slate-600 text-center mt-2 leading-relaxed">
                Pretende encerrar a sessão de trabalho do utilizador <strong className="text-slate-900">{currentUser.name}</strong> ({currentUser.roleTitle})? Para aceder novamente à plataforma do Complexo Escolar Privado BandMed será necessário introduzir as suas credenciais de autenticação.
              </p>
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-300 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsLogoutModalOpen(false)}
                className="px-4 py-2.5 rounded-none bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs cursor-pointer border border-slate-300"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmLogout}
                className="px-5 py-2.5 rounded-none bg-[#b91c1c] hover:bg-[#7a0c0c] text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors shadow-none border-none"
              >
                <span className="material-symbols-outlined text-[16px]">logout</span>
                <span>Confirmar</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
    </OperationProvider>
  );
}
