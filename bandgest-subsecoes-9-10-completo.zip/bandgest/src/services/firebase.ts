import { initializeApp, getApps, getApp, deleteApp, type FirebaseApp } from 'firebase/app';
import { getDatabase, type Database } from 'firebase/database';
import { getAuth, setPersistence, browserLocalPersistence, type Auth } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Safely intercept benign offline/connection warnings so they do not trigger runtime error overlays
if (typeof window !== 'undefined') {
  const originalConsoleError = console.error;
  console.error = (...args: any[]) => {
    const firstArg = typeof args[0] === 'string' ? args[0] : '';
    if (
      firstArg.includes('Could not reach Cloud Firestore backend') ||
      firstArg.includes("Backend didn't respond within 10 seconds")
    ) {
      console.warn('[Realtime Database Offline Warning Suppressed]:', ...args);
      return;
    }
    originalConsoleError.apply(console, args);
  };
}

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// --- Firebase Realtime Database ---------------------------------------------
// databaseURL must be present in firebase-applet-config.json (e.g.
// "https://<project-id>-default-rtdb.firebaseio.com"), otherwise getDatabase()
// throws immediately.
export const database: Database = getDatabase(app);
export { app };

// --- Firebase Authentication -------------------------------------------------
export const auth: Auth = getAuth(app);

// Persist the session locally (survives tab/browser restarts) instead of the
// SDK default, so a refresh doesn't drop the user back to the login screen.
setPersistence(auth, browserLocalPersistence).catch((e) => {
  console.warn('Erro ao configurar persistência de sessão Firebase Auth:', e);
});

/**
 * Runs `action` against a throwaway secondary Firebase App instance that shares
 * the same project/config but has its OWN Auth instance. This lets an admin
 * create another user's Firebase Auth account (e.g. a new teacher or student)
 * WITHOUT signing themselves out — `createUserWithEmailAndPassword` normally
 * signs in as the newly created user on whichever Auth instance it is called on,
 * which would otherwise hijack the admin's own session.
 */
export async function withSecondaryAuth<T>(action: (secondaryAuth: Auth) => Promise<T>): Promise<T> {
  const name = `secondary-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const secondaryApp: FirebaseApp = initializeApp(firebaseConfig, name);
  try {
    const secondaryAuth = getAuth(secondaryApp);
    return await action(secondaryAuth);
  } finally {
    try {
      await deleteApp(secondaryApp);
    } catch {
      // ignore cleanup errors
    }
  }
}
