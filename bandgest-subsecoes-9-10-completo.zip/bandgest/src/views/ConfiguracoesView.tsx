import React, { useState } from 'react';
import { SchoolDatabase, SystemSettings, UserRole } from '../types';
import { dbService } from '../services/db';
import { SettingsCommitFn } from './configuracoes/settingsCommit';
import { runGlobalOperation } from '../context/OperationContext';
import { TabDadosInstituicao } from './configuracoes/TabDadosInstituicao';
import { TabAnoLetivo } from './configuracoes/TabAnoLetivo';
import { TabFinanceiro } from './configuracoes/TabFinanceiro';
import { TabRegrasNotas } from './configuracoes/TabRegrasNotas';
import { TabPerfisPermissoes } from './configuracoes/TabPerfisPermissoes';
import { TabIntegracoes } from './configuracoes/TabIntegracoes';
import { TabSegurancaBackups } from './configuracoes/TabSegurancaBackups';
import { TabUsuarios } from './configuracoes/TabUsuarios';
import { TabBackupAutomatico } from './configuracoes/TabBackupAutomatico';
import { TabProtecaoDados } from './configuracoes/TabProtecaoDados';

interface ConfiguracoesViewProps {
  db: SchoolDatabase;
  currentUserRole: UserRole;
  onOpenSqlExport?: () => void;
  onResetData: () => void;
  /** Aba a abrir de imediato (vinda do submenu "Configurações" do sidebar). */
  initialTab?: SettingsTabId;
}

export type SettingsTabId =
  | 'instituicao'
  | 'ano-letivo'
  | 'financeiro'
  | 'notas'
  | 'perfis'
  | 'integracoes'
  | 'seguranca-backups'
  | 'utilizadores'
  | 'backup-automatico'
  | 'protecao-dados';

interface NavModule {
  id: SettingsTabId;
  index: number;
  label: string;
  shortLabel: string;
  icon: string;
  badge?: string;
  subtitle: string;
}

const navModules: NavModule[] = [
  {
    id: 'instituicao',
    index: 1,
    label: '1. Dados da Instituição',
    shortLabel: 'Instituição',
    icon: 'apartment',
    badge: 'Ativo',
    subtitle: 'Sede, NIF, Alvará MED'
  },
  {
    id: 'ano-letivo',
    index: 2,
    label: '2. Ano Letivo & Calendário',
    shortLabel: 'Ano Letivo',
    icon: 'date_range',
    badge: '3 Trim.',
    subtitle: 'Trimestres, Pausas & Feriados'
  },
  {
    id: 'financeiro',
    index: 3,
    label: '3. Tabela Financeira & Emolumentos',
    shortLabel: 'Financeiro',
    icon: 'payments',
    badge: 'Kz AOA',
    subtitle: 'Propinas, Prazos & Multas'
  },
  {
    id: 'notas',
    index: 4,
    label: '4. Regras & Escala de Notas',
    shortLabel: 'Regras de Notas',
    icon: 'rule',
    badge: '0-20',
    subtitle: 'Ponderações & Escala Oficial'
  },
  {
    id: 'perfis',
    index: 5,
    label: '5. Perfis & Permissões (ACL / RBAC)',
    shortLabel: 'Perfis & ACL',
    icon: 'admin_panel_settings',
    badge: '5 Perfis',
    subtitle: 'Matriz de Acessos & Auditoria'
  },
  {
    id: 'integracoes',
    index: 6,
    label: '6. Integrações & AGT',
    shortLabel: 'Integrações',
    icon: 'hub',
    badge: 'EMIS / AGT',
    subtitle: 'Multicaixa Express, SAF-T & SMS'
  },
  {
    id: 'seguranca-backups',
    index: 7,
    label: '7. Segurança & Backups',
    shortLabel: 'Segurança & BD',
    icon: 'security',
    badge: 'AES-256',
    subtitle: '2FA, Auditoria & Cópias Seguras'
  },
  {
    id: 'utilizadores',
    index: 8,
    label: '8. Criação de Utilizadores',
    shortLabel: 'Utilizadores',
    icon: 'group_add',
    badge: 'RBAC',
    subtitle: 'Contas de Acesso & Atribuição de Perfis'
  },
  {
    id: 'backup-automatico',
    index: 9,
    label: '9. Backup Automático Agendado',
    shortLabel: 'Backup Automático',
    icon: 'backup',
    badge: 'Agendado',
    subtitle: 'Frequência, Horário & Retenção'
  },
  {
    id: 'protecao-dados',
    index: 10,
    label: '10. Política de Proteção de Dados',
    shortLabel: 'Proteção de Dados',
    icon: 'policy',
    badge: 'Lei 22/11',
    subtitle: 'Retenção, EPD & Pedidos de Titulares'
  }
];

export const ConfiguracoesView: React.FC<ConfiguracoesViewProps> = ({
  db,
  currentUserRole,
  onOpenSqlExport,
  onResetData,
  initialTab
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTabId>(initialTab || 'instituicao');
  const [settings, setSettings] = useState<SystemSettings>(db.settings);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // O submenu "Configurações" do sidebar navega diretamente para uma aba
  // específica (ex: clicar em "Segurança & Backups"). Se o utilizador já
  // estiver nesta view e escolher outra aba no submenu, sincronizamos aqui.
  React.useEffect(() => {
    if (initialTab && initialTab !== activeTab) {
      setActiveTab(initialTab);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialTab]);

  const currentIndex = navModules.findIndex((m) => m.id === activeTab);
  const currentModule = navModules[currentIndex] || navModules[0];

  const handleUpdateSettings = (newPartial: Partial<SystemSettings>) => {
    setSettings((prev) => ({ ...prev, ...newPartial }));
  };

  // ---------------------------------------------------------------------------------
  // Gravação única: o separador activo regista aqui a função que devolve as alterações
  // que tem em mão. Já não há botões "Guardar" por aba, sub-aba ou painel — só o botão
  // principal no topo. Ao mudar de aba, as alterações pendentes são recolhidas para o
  // estado do módulo, para que nada se perca antes da gravação final.
  // ---------------------------------------------------------------------------------
  const commitRef = React.useRef<SettingsCommitFn | null>(null);
  const registerCommit = React.useCallback((commit: SettingsCommitFn | null) => {
    commitRef.current = commit;
  }, []);

  const collectPendingChanges = (): SystemSettings => {
    let merged = settings;
    if (commitRef.current) {
      try {
        const partial = commitRef.current();
        if (partial && typeof partial === 'object') {
          merged = { ...settings, ...partial };
          setSettings(merged);
        }
      } catch (e) {
        console.warn('Não foi possível recolher as alterações do separador activo:', e);
      }
    }
    return merged;
  };

  // Mapeia cada separador para a regra REAL definida na Matriz de Perfis &
  // Permissões (ver `defaultPermissionsList` em `utils/permissions.ts`).
  // ATENÇÃO: 'config.edit' NÃO existe nessa matriz — nenhum interruptor a
  // controla. Antes desta correção, o botão "Guardar Alterações" verificava
  // sempre essa regra inexistente e, por não ser encontrada, `hasPermission`
  // recusava automaticamente qualquer perfil que não fosse 'admin'. Ou seja:
  // ativar 'config.institution', 'config.permissions' ou 'config.backups' para
  // a Direção, Secretaria, etc. na Matriz NUNCA tinha efeito nenhum ao gravar,
  // porque o botão principal não perguntava por essas regras — perguntava por
  // uma regra fantasma. Agora perguntamos pela regra certa consoante a aba ativa.
  const ruleForTab = (tabId: SettingsTabId): string => {
    switch (tabId) {
      case 'perfis':
        return 'config.permissions';
      case 'utilizadores':
        return 'config.permissions';
      case 'seguranca-backups':
      case 'backup-automatico':
        return 'config.backups';
      default:
        return 'config.institution';
    }
  };

  const handleSaveAll = async (options?: { loadingMessage?: string; successMessage?: string; requiredRule?: string }) => {
    const merged = collectPendingChanges();
    return await runGlobalOperation(
      async () => {
        dbService.updateSettings(merged);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 4000);
      },
      {
        requiredRule: options?.requiredRule || ruleForTab(activeTab),
        userRole: currentUserRole,
        loadingMessage: options?.loadingMessage || 'A gravar alterações nas configurações do sistema...',
        successMessage: options?.successMessage || 'Operação feita com sucesso!'
      }
    );
  };

  const handleSwitchTab = (tabId: SettingsTabId) => {
    // Recolhe o que estiver pendente no separador que está a ser abandonado.
    collectPendingChanges();
    commitRef.current = null;
    setActiveTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col w-full gap-5 pb-16">
      {/* Top Header Card */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1 text-xs">
            <span className="font-bold uppercase tracking-wider text-slate-500">
              Governação Institucional
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#0b1f3a]" />
            <span className="font-bold text-[#0b1f3a]">{settings.currentAcademicYear || '2024 / 2025'}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
            <span className="font-bold text-[#ac332b]">Módulo {currentModule.index} de 10: {currentModule.shortLabel}</span>
          </div>
          <h1 className="font-headline text-2xl lg:text-3xl font-extrabold text-[#0b1f3a] tracking-tight">
            {currentModule.label}
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-3xl">
            {currentModule.subtitle} — utilize o submenu "Configurações" no menu lateral para mudar de módulo.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => handleSaveAll()}
            className="px-5 py-2 rounded-xl bg-[#0b1f3a] hover:bg-[#7a0c0c] text-white font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[17px]">save</span>
            <span>Guardar Alterações</span>
          </button>
        </div>
      </div>

      {/* Save Success Alert */}
      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in shadow-xs">
          <span className="material-symbols-outlined text-[20px] text-emerald-600">check_circle</span>
          <span>Todas as configurações institucionais foram sincronizadas e gravadas com sucesso no banco de dados!</span>
        </div>
      )}

      {/* A navegação entre os 10 módulos passou a viver exclusivamente no submenu
          "Configurações" do menu lateral (Sidebar.tsx) — a barra de abas e o
          rodapé de paginação que existiam aqui foram removidos para não haver
          duas navegações a fazer a mesma coisa. */}

      {/* ACTIVE TAB CONTENT CONTAINER - Directly below the tabs, full width, with pristine responsive layout */}
      <div className="w-full">
        {activeTab === 'instituicao' && (
          <TabDadosInstituicao
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'ano-letivo' && (
          <TabAnoLetivo
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'financeiro' && (
          <TabFinanceiro
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'notas' && (
          <TabRegrasNotas
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'perfis' && (
          <TabPerfisPermissoes
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'integracoes' && (
          <TabIntegracoes
            settings={settings}
            currentUserRole={currentUserRole}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'seguranca-backups' && (
          <TabSegurancaBackups
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
            onOpenSqlExport={onOpenSqlExport}
            onResetData={onResetData}
          />
        )}

        {activeTab === 'utilizadores' && (
          <TabUsuarios
            db={db}
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'backup-automatico' && (
          <TabBackupAutomatico
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}

        {activeTab === 'protecao-dados' && (
          <TabProtecaoDados
            settings={settings}
            currentUserRole={currentUserRole}
            onUpdateSettings={handleUpdateSettings}
            onSaveAll={handleSaveAll}
            registerCommit={registerCommit}
          />
        )}
      </div>

      {/* Pagination Footer to jump between tabs easily */}
      <div className="flex items-center justify-center p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center justify-center gap-1">
          {navModules.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => handleSwitchTab(m.id)}
              className={`w-7 h-7 rounded-lg text-xs font-bold transition-all flex items-center justify-center cursor-pointer ${
                activeTab === m.id
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
              title={m.label}
            >
              {m.index}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
