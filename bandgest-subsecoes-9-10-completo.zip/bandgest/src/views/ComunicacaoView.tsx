import React, { useMemo, useState } from 'react';
import {
  ChatThreadStatus,
  CommunicationChannel,
  MeetingParticipantStatus,
  MeetingStatus,
  MeetingType,
  NotificationAudienceType,
  NotificationStatus,
  SchoolDatabase,
  UserRole
} from '../types';
import { dbService } from '../services/db';
import { runGlobalOperation } from '../context/OperationContext';
import { useAccessControl } from '../hooks/useAccessControl';
import { FormModalHeader } from '../components/FormModalHeader';
import { SearchableSelect } from '../components/SearchableSelect';
import { AppConfirmModal } from '../components/AppConfirmModal';
import {
  AUDIENCE_TYPE_LABELS,
  CHANNEL_LABELS,
  CHAT_STATUS_META,
  MEETING_STATUS_META,
  MEETING_TYPE_LABELS,
  NOTIFICATION_STATUS_META,
  PARTICIPANT_STATUS_META
} from '../utils/comunicacao';

export type ComunicacaoSection = 'comunicacao_notificacoes' | 'comunicacao_reunioes' | 'comunicacao_chat';

interface ComunicacaoViewProps {
  db: SchoolDatabase;
  currentUserRole: UserRole;
  section?: ComunicacaoSection;
}

const inputCls =
  'w-full h-9 px-3 bg-white border border-slate-300 text-slate-800 focus:border-[#0b1f3a] focus:outline-none text-xs';
const textareaCls =
  'w-full px-3 py-2 bg-white border border-slate-300 text-slate-800 focus:border-[#0b1f3a] focus:outline-none text-xs';
const labelCls = 'block uppercase font-bold text-slate-700 mb-1 text-[11px]';

const fmtDateTime = (iso?: string) => (iso ? new Date(iso).toLocaleString('pt-PT') : '—');
const fmtDate = (iso?: string) => (iso ? new Date(`${iso}T00:00:00`).toLocaleDateString('pt-PT') : '—');

function Badge({ tone, children }: { tone: string; children: React.ReactNode }) {
  return <span className={`px-2 py-0.5 rounded text-[10px] font-bold whitespace-nowrap ${tone}`}>{children}</span>;
}

function SectionHeader({
  subsection,
  title,
  description,
  actions
}: {
  subsection: string;
  title: string;
  description: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500">COMUNICAÇÃO</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#0b1f3a]" />
          <span className="text-xs font-semibold text-[#0b1f3a]">{subsection}</span>
        </div>
        <h1 className="font-headline text-2xl lg:text-3xl font-extrabold text-[#0b1f3a] tracking-tight">{title}</h1>
        <p className="text-xs text-slate-500 mt-0.5 max-w-3xl">{description}</p>
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0 flex-wrap">{actions}</div>}
    </div>
  );
}

function KpiGrid({ items }: { items: Array<{ label: string; value: React.ReactNode; icon: string; tone?: 'default' | 'warn' | 'danger' }> }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {items.map((k) => {
        const tone =
          k.tone === 'danger' ? 'bg-red-50 text-red-700' : k.tone === 'warn' ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-[#0b1f3a]';
        return (
          <div key={k.label} className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <div className={`w-10 h-10 flex items-center justify-center rounded-lg shrink-0 ${tone}`}>
              <span className="material-symbols-outlined text-[22px]">{k.icon}</span>
            </div>
            <div className="min-w-0">
              <div className="font-mono text-xl font-extrabold text-[#0b1f3a] leading-none truncate">{k.value}</div>
              <div className="text-[11px] text-slate-500 font-semibold mt-1">{k.label}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="relative">
      <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-[18px]">search</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-10 pl-9 pr-3 bg-white border border-slate-300 text-slate-800 focus:border-[#0b1f3a] focus:outline-none text-xs rounded-lg"
      />
    </div>
  );
}

function EmptyState({ icon, text }: { icon: string; text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-slate-400 gap-2">
      <span className="material-symbols-outlined text-[40px]">{icon}</span>
      <p className="text-xs font-semibold">{text}</p>
    </div>
  );
}

export const ComunicacaoView: React.FC<ComunicacaoViewProps> = ({ db, currentUserRole, section = 'comunicacao_notificacoes' }) => {
  const acl = useAccessControl(currentUserRole);

  const run = async (
    action: () => void,
    loadingMessage: string,
    rule: string
  ): Promise<{ ok: boolean; error?: string }> => {
    try {
      await runGlobalOperation(action, { loadingMessage, requiredRule: rule, userRole: currentUserRole });
      return { ok: true };
    } catch (err: any) {
      return { ok: false, error: err?.message };
    }
  };

  if (section === 'comunicacao_reunioes') return <ReunioesTab db={db} currentUserRole={currentUserRole} acl={acl} run={run} />;
  if (section === 'comunicacao_chat') return <ChatTab db={db} currentUserRole={currentUserRole} acl={acl} run={run} />;
  return <NotificacoesTab db={db} currentUserRole={currentUserRole} acl={acl} run={run} />;
};

type RunFn = (action: () => void, loadingMessage: string, rule: string) => Promise<{ ok: boolean; error?: string }>;
interface TabProps {
  db: SchoolDatabase;
  currentUserRole: UserRole;
  acl: ReturnType<typeof useAccessControl>;
  run: RunFn;
}

// =============================================================
// 2. Notificações SMS/WhatsApp
// =============================================================

const RULE_NOTIF = 'comunicacao.notificacoes.manage';

function NotificacoesTab({ db, currentUserRole, acl, run }: TabProps) {
  const canManage = acl.can(RULE_NOTIF);
  const notifications = db.smsWhatsappNotifications || [];
  const students = db.students || [];
  const classes = db.classes || [];

  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewing, setViewing] = useState<(typeof notifications)[number] | null>(null);
  const [deleting, setDeleting] = useState<(typeof notifications)[number] | null>(null);
  const [formError, setFormError] = useState('');

  const [channel, setChannel] = useState<CommunicationChannel>('sms');
  const [audienceType, setAudienceType] = useState<NotificationAudienceType>('toda_escola');
  const [classId, setClassId] = useState('');
  const [studentIds, setStudentIds] = useState<string[]>([]);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [scheduledFor, setScheduledFor] = useState('');

  const classOptions = useMemo(() => classes.map((c) => ({ value: c.id, label: c.name })), [classes]);
  const studentOptions = useMemo(
    () =>
      students
        .filter((s) => s.status === 'active')
        .sort((a, b) => a.name.localeCompare(b.name, 'pt'))
        .map((s) => ({ value: s.id, label: s.name, sublabel: `Nº ${s.procNumber}${s.className ? ' · ' + s.className : ''}` })),
    [students]
  );

  const q = searchTerm.trim().toLowerCase();
  const filtered = useMemo(
    () =>
      notifications.filter(
        (n) => !q || n.title.toLowerCase().includes(q) || n.code.toLowerCase().includes(q) || n.message.toLowerCase().includes(q)
      ),
    [notifications, q]
  );

  const sentCount = notifications.filter((n) => n.status === 'enviada').length;
  const scheduledCount = notifications.filter((n) => n.status === 'agendada').length;
  const totalRecipients = notifications.reduce((sum, n) => sum + n.sentCount, 0);

  const resetForm = () => {
    setChannel('sms');
    setAudienceType('toda_escola');
    setClassId('');
    setStudentIds([]);
    setTitle('');
    setMessage('');
    setScheduledFor('');
    setFormError('');
  };

  const openNew = () => {
    setEditingId(null);
    resetForm();
    setIsFormOpen(true);
  };

  const openEdit = (n: (typeof notifications)[number]) => {
    setEditingId(n.id);
    setChannel(n.channel);
    setAudienceType(n.audienceType);
    setClassId(n.classId || '');
    setStudentIds(n.studentIds || []);
    setTitle(n.title);
    setMessage(n.message);
    setScheduledFor(n.scheduledFor || '');
    setFormError('');
    setIsFormOpen(true);
  };

  const handleSubmit = async () => {
    const { ok, error } = await run(
      () => {
        const result = dbService.saveNotificationDraft({
          id: editingId || undefined,
          channel,
          audienceType,
          classId: audienceType === 'turma' ? classId : undefined,
          studentIds: audienceType === 'aluno' ? studentIds : undefined,
          title,
          message,
          scheduledFor: scheduledFor || undefined
        });
        if (!result.success) throw new Error(result.error || 'Não foi possível guardar a notificação.');
      },
      editingId ? 'A atualizar notificação...' : 'A criar notificação...',
      RULE_NOTIF
    );
    if (ok) {
      setIsFormOpen(false);
      resetForm();
    } else {
      setFormError(error || 'Ocorreu um erro.');
    }
  };

  const handleSend = (id: string) =>
    run(
      () => {
        const result = dbService.sendNotification(id);
        if (!result.success) throw new Error(result.error);
      },
      'A enviar notificação...',
      RULE_NOTIF
    );

  const handleDelete = async () => {
    if (!deleting) return;
    await run(
      () => {
        const result = dbService.deleteSmsWhatsappNotification(deleting.id);
        if (!result.success) throw new Error(result.error);
      },
      'A eliminar notificação...',
      RULE_NOTIF
    );
    setDeleting(null);
  };

  return (
    <div className="space-y-5">
      <SectionHeader
        subsection="2. Notificações SMS/WhatsApp"
        title="Notificações em Massa"
        description="Envio simulado de mensagens SMS/WhatsApp a encarregados de educação, professores ou funcionários, com registo de destinatários e estado de entrega."
        actions={
          canManage && (
            <button
              onClick={openNew}
              className="h-10 px-4 bg-[#0b1f3a] text-white text-xs font-bold uppercase tracking-wide rounded-lg flex items-center gap-2 hover:bg-[#132a4d]"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              Nova Notificação
            </button>
          )
        }
      />

      <KpiGrid
        items={[
          { label: 'Total de Notificações', value: notifications.length, icon: 'sms' },
          { label: 'Enviadas', value: sentCount, icon: 'mark_email_read' },
          { label: 'Agendadas', value: scheduledCount, icon: 'schedule_send', tone: 'warn' },
          { label: 'Destinatários Alcançados', value: totalRecipients, icon: 'groups' }
        ]}
      />

      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Pesquisar por título, código ou mensagem..." />
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon="sms" text="Nenhuma notificação encontrada." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold">
                <tr>
                  <th className="text-left px-4 py-3">Código</th>
                  <th className="text-left px-4 py-3">Título</th>
                  <th className="text-left px-4 py-3">Canal</th>
                  <th className="text-left px-4 py-3">Público-Alvo</th>
                  <th className="text-left px-4 py-3">Estado</th>
                  <th className="text-left px-4 py-3">Destinatários</th>
                  <th className="text-right px-4 py-3">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((n) => (
                  <tr key={n.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-mono text-slate-500">{n.code}</td>
                    <td className="px-4 py-3 font-semibold text-slate-800">{n.title}</td>
                    <td className="px-4 py-3 text-slate-600">{CHANNEL_LABELS[n.channel]}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {AUDIENCE_TYPE_LABELS[n.audienceType]}
                      {n.className ? ` · ${n.className}` : ''}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={NOTIFICATION_STATUS_META[n.status].badge}>{NOTIFICATION_STATUS_META[n.status].label}</Badge>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{n.status === 'enviada' ? n.sentCount : '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setViewing(n)} title="Ver detalhes" className="p-1.5 text-slate-500 hover:text-[#0b1f3a]">
                          <span className="material-symbols-outlined text-[18px]">visibility</span>
                        </button>
                        {canManage && (n.status === 'rascunho' || n.status === 'agendada') && (
                          <>
                            <button onClick={() => openEdit(n)} title="Editar" className="p-1.5 text-slate-500 hover:text-[#0b1f3a]">
                              <span className="material-symbols-outlined text-[18px]">edit</span>
                            </button>
                            <button onClick={() => handleSend(n.id)} title="Enviar agora" className="p-1.5 text-emerald-600 hover:text-emerald-800">
                              <span className="material-symbols-outlined text-[18px]">send</span>
                            </button>
                          </>
                        )}
                        {canManage && (
                          <button onClick={() => setDeleting(n)} title="Eliminar" className="p-1.5 text-red-500 hover:text-red-700">
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto flex flex-col">
            <FormModalHeader
              title={editingId ? 'Editar Notificação' : 'Nova Notificação'}
              subtitle="SMS / WhatsApp em massa"
              icon="sms"
              onClose={() => setIsFormOpen(false)}
            />
            <div className="p-6 space-y-4">
              {formError && <div className="bg-red-50 text-red-700 text-xs font-semibold p-3 rounded-lg">{formError}</div>}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Canal</label>
                  <select value={channel} onChange={(e) => setChannel(e.target.value as CommunicationChannel)} className={inputCls}>
                    {Object.entries(CHANNEL_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Público-Alvo</label>
                  <select
                    value={audienceType}
                    onChange={(e) => setAudienceType(e.target.value as NotificationAudienceType)}
                    className={inputCls}
                  >
                    {Object.entries(AUDIENCE_TYPE_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              {audienceType === 'turma' && (
                <SearchableSelect label="Turma" options={classOptions} value={classId} onChange={setClassId} placeholder="Selecione a turma" />
              )}
              {audienceType === 'aluno' && (
                <div>
                  <label className={labelCls}>Alunos ({studentIds.length} selecionado(s))</label>
                  <div className="border border-slate-300 rounded-lg max-h-40 overflow-y-auto divide-y divide-slate-100">
                    {studentOptions.map((opt) => (
                      <label key={opt.value} className="flex items-center gap-2 px-3 py-2 text-xs hover:bg-slate-50 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={studentIds.includes(opt.value)}
                          onChange={(e) =>
                            setStudentIds((prev) => (e.target.checked ? [...prev, opt.value] : prev.filter((id) => id !== opt.value)))
                          }
                        />
                        <span className="font-semibold text-slate-700">{opt.label}</span>
                        <span className="text-slate-400">{opt.sublabel}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
              <div>
                <label className={labelCls}>Título/Assunto</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} className={inputCls} placeholder="Ex.: Suspensão de aulas" />
              </div>
              <div>
                <label className={labelCls}>Mensagem ({message.length}/480)</label>
                <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} maxLength={480} className={textareaCls} />
              </div>
              <div>
                <label className={labelCls}>Agendar Envio Para (opcional)</label>
                <input
                  type="datetime-local"
                  value={scheduledFor}
                  onChange={(e) => setScheduledFor(e.target.value)}
                  className={inputCls}
                />
              </div>
            </div>
            <div className="p-4 border-t border-slate-100 flex justify-end gap-2">
              <button onClick={() => setIsFormOpen(false)} className="h-9 px-4 text-xs font-bold text-slate-600">
                Cancelar
              </button>
              <button onClick={handleSubmit} className="h-9 px-5 bg-[#0b1f3a] text-white text-xs font-bold rounded-lg">
                Guardar
              </button>
            </div>
          </div>
        </div>
      )}

      {viewing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto flex flex-col">
            <FormModalHeader title={viewing.title} subtitle={viewing.code} icon="sms" onClose={() => setViewing(null)} />
            <div className="p-6 space-y-3 text-xs">
              <p className="text-slate-700 whitespace-pre-wrap bg-slate-50 p-3 rounded-lg">{viewing.message}</p>
              <div className="grid grid-cols-2 gap-3 text-slate-600">
                <div>
                  <span className="font-bold text-slate-800">Canal:</span> {CHANNEL_LABELS[viewing.channel]}
                </div>
                <div>
                  <span className="font-bold text-slate-800">Estado:</span> {NOTIFICATION_STATUS_META[viewing.status].label}
                </div>
                <div>
                  <span className="font-bold text-slate-800">Criada por:</span> {viewing.createdBy}
                </div>
                <div>
                  <span className="font-bold text-slate-800">Em:</span> {fmtDateTime(viewing.createdAt)}
                </div>
              </div>
              {viewing.recipients.length > 0 && (
                <div>
                  <p className="font-bold text-slate-800 mb-1">Destinatários ({viewing.recipients.length})</p>
                  <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-lg">
                    {viewing.recipients.map((r) => (
                      <div key={r.id} className="flex items-center justify-between px-3 py-1.5">
                        <span className="text-slate-700">{r.name} — {r.phone}</span>
                        <Badge tone={r.deliveryStatus === 'entregue' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}>
                          {r.deliveryStatus}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <AppConfirmModal
        isOpen={!!deleting}
        title="Eliminar Notificação"
        message={`Tem a certeza que pretende eliminar a notificação "${deleting?.title}"? Esta ação não pode ser revertida.`}
        variant="error"
        confirmLabel="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

// =============================================================
// 3. Reuniões Pais-Professores
// =============================================================

const RULE_MEETING = 'comunicacao.reunioes.manage';

function ReunioesTab({ db, currentUserRole, acl, run }: TabProps) {
  const canManage = acl.can(RULE_MEETING);
  const meetings = db.parentTeacherMeetings || [];
  const students = db.students || [];
  const classes = db.classes || [];
  const teachers = db.teachers || [];

  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewing, setViewing] = useState<(typeof meetings)[number] | null>(null);
  const [deleting, setDeleting] = useState<(typeof meetings)[number] | null>(null);
  const [completing, setCompleting] = useState<(typeof meetings)[number] | null>(null);
  const [summaryText, setSummaryText] = useState('');
  const [formError, setFormError] = useState('');

  const [type, setType] = useState<MeetingType>('individual');
  const [title, setTitle] = useState('');
  const [teacherId, setTeacherId] = useState('');
  const [classId, setClassId] = useState('');
  const [studentIds, setStudentIds] = useState<string[]>([]);
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [agenda, setAgenda] = useState('');

  const teacherOptions = useMemo(() => teachers.map((t) => ({ value: t.id, label: t.name, sublabel: t.department })), [teachers]);
  const classOptions = useMemo(() => classes.map((c) => ({ value: c.id, label: c.name })), [classes]);
  const studentOptions = useMemo(
    () =>
      students
        .filter((s) => s.status === 'active' && s.guardianName?.trim())
        .sort((a, b) => a.name.localeCompare(b.name, 'pt'))
        .map((s) => ({ value: s.id, label: s.name, sublabel: `Enc.: ${s.guardianName}` })),
    [students]
  );

  const q = searchTerm.trim().toLowerCase();
  const filtered = useMemo(
    () =>
      meetings.filter(
        (m) => !q || m.title.toLowerCase().includes(q) || m.code.toLowerCase().includes(q) || m.teacherName.toLowerCase().includes(q)
      ),
    [meetings, q]
  );

  const scheduledCount = meetings.filter((m) => m.status === 'agendada').length;
  const doneCount = meetings.filter((m) => m.status === 'realizada').length;

  const resetForm = () => {
    setType('individual');
    setTitle('');
    setTeacherId('');
    setClassId('');
    setStudentIds([]);
    setDate('');
    setStartTime('');
    setEndTime('');
    setLocation('');
    setAgenda('');
    setFormError('');
  };

  const openNew = () => {
    setEditingId(null);
    resetForm();
    setIsFormOpen(true);
  };

  const openEdit = (m: (typeof meetings)[number]) => {
    setEditingId(m.id);
    setType(m.type);
    setTitle(m.title);
    setTeacherId(m.teacherId);
    setClassId(m.classId || '');
    setStudentIds(m.participants.map((p) => p.studentId));
    setDate(m.date);
    setStartTime(m.startTime);
    setEndTime(m.endTime);
    setLocation(m.location || '');
    setAgenda(m.agenda || '');
    setFormError('');
    setIsFormOpen(true);
  };

  const handleSubmit = async () => {
    const { ok, error } = await run(
      () => {
        const result = dbService.saveMeeting({
          id: editingId || undefined,
          type,
          title,
          teacherId,
          classId: type === 'coletiva' ? classId : undefined,
          studentIds: type === 'individual' ? studentIds : undefined,
          date,
          startTime,
          endTime,
          location: location || undefined,
          agenda: agenda || undefined
        });
        if (!result.success) throw new Error(result.error || 'Não foi possível guardar a reunião.');
      },
      editingId ? 'A atualizar reunião...' : 'A agendar reunião...',
      RULE_MEETING
    );
    if (ok) {
      setIsFormOpen(false);
      resetForm();
    } else {
      setFormError(error || 'Ocorreu um erro.');
    }
  };

  const handleParticipantStatus = (meetingId: string, studentId: string, status: MeetingParticipantStatus) =>
    run(
      () => {
        const result = dbService.updateMeetingParticipantStatus(meetingId, studentId, status);
        if (!result.success) throw new Error(result.error);
      },
      'A atualizar participante...',
      RULE_MEETING
    );

  const handleComplete = async () => {
    if (!completing) return;
    const { ok } = await run(
      () => {
        const result = dbService.completeMeeting(completing.id, summaryText);
        if (!result.success) throw new Error(result.error);
      },
      'A concluir reunião...',
      RULE_MEETING
    );
    if (ok) {
      setCompleting(null);
      setSummaryText('');
    }
  };

  const handleCancel = (id: string) =>
    run(
      () => {
        const result = dbService.cancelMeeting(id);
        if (!result.success) throw new Error(result.error);
      },
      'A cancelar reunião...',
      RULE_MEETING
    );

  const handleDelete = async () => {
    if (!deleting) return;
    await run(
      () => {
        const result = dbService.deleteMeeting(deleting.id);
        if (!result.success) throw new Error(result.error);
      },
      'A eliminar reunião...',
      RULE_MEETING
    );
    setDeleting(null);
  };

  return (
    <div className="space-y-5">
      <SectionHeader
        subsection="3. Reuniões Pais-Professores"
        title="Reuniões Pais-Professores"
        description="Agendamento de reuniões individuais ou coletivas (turma inteira), com lista de participantes, confirmação/comparência e resumo final."
        actions={
          canManage && (
            <button
              onClick={openNew}
              className="h-10 px-4 bg-[#0b1f3a] text-white text-xs font-bold uppercase tracking-wide rounded-lg flex items-center gap-2 hover:bg-[#132a4d]"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              Nova Reunião
            </button>
          )
        }
      />

      <KpiGrid
        items={[
          { label: 'Total de Reuniões', value: meetings.length, icon: 'groups_2' },
          { label: 'Agendadas', value: scheduledCount, icon: 'event_upcoming', tone: 'warn' },
          { label: 'Realizadas', value: doneCount, icon: 'task_alt' },
          { label: 'Participantes Convocados', value: meetings.reduce((s, m) => s + m.participants.length, 0), icon: 'diversity_3' }
        ]}
      />

      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Pesquisar por título, código ou professor..." />
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon="groups_2" text="Nenhuma reunião encontrada." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold">
                <tr>
                  <th className="text-left px-4 py-3">Código</th>
                  <th className="text-left px-4 py-3">Título</th>
                  <th className="text-left px-4 py-3">Tipo</th>
                  <th className="text-left px-4 py-3">Professor</th>
                  <th className="text-left px-4 py-3">Data/Hora</th>
                  <th className="text-left px-4 py-3">Estado</th>
                  <th className="text-right px-4 py-3">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-mono text-slate-500">{m.code}</td>
                    <td className="px-4 py-3 font-semibold text-slate-800">{m.title}</td>
                    <td className="px-4 py-3 text-slate-600">{MEETING_TYPE_LABELS[m.type]}</td>
                    <td className="px-4 py-3 text-slate-600">{m.teacherName}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {fmtDate(m.date)} · {m.startTime}–{m.endTime}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={MEETING_STATUS_META[m.status].badge}>{MEETING_STATUS_META[m.status].label}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setViewing(m)} title="Ver participantes" className="p-1.5 text-slate-500 hover:text-[#0b1f3a]">
                          <span className="material-symbols-outlined text-[18px]">visibility</span>
                        </button>
                        {canManage && m.status === 'agendada' && (
                          <>
                            <button onClick={() => openEdit(m)} title="Editar" className="p-1.5 text-slate-500 hover:text-[#0b1f3a]">
                              <span className="material-symbols-outlined text-[18px]">edit</span>
                            </button>
                            <button
                              onClick={() => {
                                setCompleting(m);
                                setSummaryText(m.summary || '');
                              }}
                              title="Marcar como realizada"
                              className="p-1.5 text-emerald-600 hover:text-emerald-800"
                            >
                              <span className="material-symbols-outlined text-[18px]">task_alt</span>
                            </button>
                            <button onClick={() => handleCancel(m.id)} title="Cancelar" className="p-1.5 text-amber-600 hover:text-amber-800">
                              <span className="material-symbols-outlined text-[18px]">event_busy</span>
                            </button>
                          </>
                        )}
                        {canManage && (
                          <button onClick={() => setDeleting(m)} title="Eliminar" className="p-1.5 text-red-500 hover:text-red-700">
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto flex flex-col">
            <FormModalHeader
              title={editingId ? 'Editar Reunião' : 'Nova Reunião'}
              subtitle="Pais / Encarregados de Educação"
              icon="groups_2"
              onClose={() => setIsFormOpen(false)}
            />
            <div className="p-6 space-y-4">
              {formError && <div className="bg-red-50 text-red-700 text-xs font-semibold p-3 rounded-lg">{formError}</div>}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Tipo de Reunião</label>
                  <select value={type} onChange={(e) => setType(e.target.value as MeetingType)} className={inputCls}>
                    {Object.entries(MEETING_TYPE_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
                <SearchableSelect label="Professor Responsável" options={teacherOptions} value={teacherId} onChange={setTeacherId} placeholder="Selecione o professor" />
              </div>
              <div>
                <label className={labelCls}>Título/Motivo</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} className={inputCls} placeholder="Ex.: Ponto de situação do trimestre" />
              </div>
              {type === 'coletiva' ? (
                <SearchableSelect label="Turma" options={classOptions} value={classId} onChange={setClassId} placeholder="Selecione a turma" />
              ) : (
                <div>
                  <label className={labelCls}>Alunos/Encarregados ({studentIds.length} selecionado(s))</label>
                  <div className="border border-slate-300 rounded-lg max-h-40 overflow-y-auto divide-y divide-slate-100">
                    {studentOptions.map((opt) => (
                      <label key={opt.value} className="flex items-center gap-2 px-3 py-2 text-xs hover:bg-slate-50 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={studentIds.includes(opt.value)}
                          onChange={(e) =>
                            setStudentIds((prev) => (e.target.checked ? [...prev, opt.value] : prev.filter((id) => id !== opt.value)))
                          }
                        />
                        <span className="font-semibold text-slate-700">{opt.label}</span>
                        <span className="text-slate-400">{opt.sublabel}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className={labelCls}>Data</label>
                  <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Hora Início</label>
                  <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Hora Fim</label>
                  <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className={inputCls} />
                </div>
              </div>
              <div>
                <label className={labelCls}>Local (opcional)</label>
                <input value={location} onChange={(e) => setLocation(e.target.value)} className={inputCls} placeholder="Ex.: Sala de Reuniões" />
              </div>
              <div>
                <label className={labelCls}>Agenda (opcional)</label>
                <textarea value={agenda} onChange={(e) => setAgenda(e.target.value)} rows={3} className={textareaCls} />
              </div>
            </div>
            <div className="p-4 border-t border-slate-100 flex justify-end gap-2">
              <button onClick={() => setIsFormOpen(false)} className="h-9 px-4 text-xs font-bold text-slate-600">
                Cancelar
              </button>
              <button onClick={handleSubmit} className="h-9 px-5 bg-[#0b1f3a] text-white text-xs font-bold rounded-lg">
                Guardar
              </button>
            </div>
          </div>
        </div>
      )}

      {viewing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto flex flex-col">
            <FormModalHeader title={viewing.title} subtitle={viewing.code} icon="groups_2" onClose={() => setViewing(null)} />
            <div className="p-6 space-y-3 text-xs">
              {viewing.summary && (
                <div>
                  <p className="font-bold text-slate-800 mb-1">Resumo Final</p>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded-lg whitespace-pre-wrap">{viewing.summary}</p>
                </div>
              )}
              <p className="font-bold text-slate-800">Participantes ({viewing.participants.length})</p>
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-lg">
                {viewing.participants.map((p) => (
                  <div key={p.studentId} className="flex items-center justify-between px-3 py-2 gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-700 truncate">{p.studentName}</p>
                      <p className="text-slate-400 truncate">{p.guardianName}</p>
                    </div>
                    {canManage && viewing.status === 'agendada' ? (
                      <select
                        value={p.status}
                        onChange={(e) => handleParticipantStatus(viewing.id, p.studentId, e.target.value as MeetingParticipantStatus)}
                        className="h-8 px-2 text-[11px] border border-slate-300 rounded"
                      >
                        {Object.entries(PARTICIPANT_STATUS_META).map(([k, v]) => (
                          <option key={k} value={k}>
                            {v.label}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <Badge tone={PARTICIPANT_STATUS_META[p.status].badge}>{PARTICIPANT_STATUS_META[p.status].label}</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {completing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md flex flex-col">
            <FormModalHeader title="Concluir Reunião" subtitle={completing.title} icon="task_alt" onClose={() => setCompleting(null)} />
            <div className="p-6 space-y-3">
              <label className={labelCls}>Resumo da Reunião</label>
              <textarea value={summaryText} onChange={(e) => setSummaryText(e.target.value)} rows={5} className={textareaCls} />
            </div>
            <div className="p-4 border-t border-slate-100 flex justify-end gap-2">
              <button onClick={() => setCompleting(null)} className="h-9 px-4 text-xs font-bold text-slate-600">
                Cancelar
              </button>
              <button onClick={handleComplete} className="h-9 px-5 bg-[#0b1f3a] text-white text-xs font-bold rounded-lg">
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}

      <AppConfirmModal
        isOpen={!!deleting}
        title="Eliminar Reunião"
        message={`Tem a certeza que pretende eliminar a reunião "${deleting?.title}"? Esta ação não pode ser revertida.`}
        variant="error"
        confirmLabel="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}

// =============================================================
// 4. Chat Encarregado ↔ Escola
// =============================================================

const RULE_CHAT = 'comunicacao.chat.manage';

function ChatTab({ db, currentUserRole, acl, run }: TabProps) {
  const canManage = acl.can(RULE_CHAT);
  const threads = db.guardianChatThreads || [];
  const students = db.students || [];

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(threads[0]?.id || null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [deleting, setDeleting] = useState<(typeof threads)[number] | null>(null);
  const [formError, setFormError] = useState('');
  const [newStudentId, setNewStudentId] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [reply, setReply] = useState('');

  const studentOptions = useMemo(
    () =>
      students
        .filter((s) => s.status === 'active' && s.guardianName?.trim())
        .sort((a, b) => a.name.localeCompare(b.name, 'pt'))
        .map((s) => ({ value: s.id, label: s.name, sublabel: `Enc.: ${s.guardianName}` })),
    [students]
  );

  const q = searchTerm.trim().toLowerCase();
  const filtered = useMemo(
    () =>
      threads
        .filter((t) => !q || t.subject.toLowerCase().includes(q) || t.studentName.toLowerCase().includes(q) || t.guardianName.toLowerCase().includes(q))
        .sort((a, b) => (a.lastMessageAt < b.lastMessageAt ? 1 : -1)),
    [threads, q]
  );

  const selected = threads.find((t) => t.id === selectedId) || filtered[0] || null;

  const openCount = threads.filter((t) => t.status !== 'resolvida').length;
  const waitingCount = threads.filter((t) => t.status === 'aguarda_resposta').length;

  const handleCreate = async () => {
    const { ok, error } = await run(
      () => {
        const result = dbService.createChatThread(newStudentId, newSubject, newMessage);
        if (!result.success) throw new Error(result.error || 'Não foi possível abrir a conversa.');
        setSelectedId(result.thread!.id);
      },
      'A abrir conversa...',
      RULE_CHAT
    );
    if (ok) {
      setIsFormOpen(false);
      setNewStudentId('');
      setNewSubject('');
      setNewMessage('');
      setFormError('');
    } else {
      setFormError(error || 'Ocorreu um erro.');
    }
  };

  const handleSendReply = (sender: 'escola' | 'encarregado') => {
    if (!selected || !reply.trim()) return;
    run(
      () => {
        const result = dbService.addChatMessage(selected.id, reply, sender);
        if (!result.success) throw new Error(result.error);
      },
      'A enviar mensagem...',
      RULE_CHAT
    ).then(({ ok }) => {
      if (ok) setReply('');
    });
  };

  const handleStatus = (status: ChatThreadStatus) => {
    if (!selected) return;
    run(
      () => {
        const result = dbService.setChatThreadStatus(selected.id, status);
        if (!result.success) throw new Error(result.error);
      },
      'A atualizar estado...',
      RULE_CHAT
    );
  };

  const handleDelete = async () => {
    if (!deleting) return;
    await run(
      () => {
        const result = dbService.deleteChatThread(deleting.id);
        if (!result.success) throw new Error(result.error);
      },
      'A eliminar conversa...',
      RULE_CHAT
    );
    if (selectedId === deleting.id) setSelectedId(null);
    setDeleting(null);
  };

  return (
    <div className="space-y-5">
      <SectionHeader
        subsection="4. Chat Encarregado ↔ Escola"
        title="Conversas com Encarregados"
        description="Conversas por aluno entre a Escola e o Encarregado de Educação, com histórico de mensagens e estado."
        actions={
          canManage && (
            <button
              onClick={() => setIsFormOpen(true)}
              className="h-10 px-4 bg-[#0b1f3a] text-white text-xs font-bold uppercase tracking-wide rounded-lg flex items-center gap-2 hover:bg-[#132a4d]"
            >
              <span className="material-symbols-outlined text-[18px]">add_comment</span>
              Nova Conversa
            </button>
          )
        }
      />

      <KpiGrid
        items={[
          { label: 'Conversas Totais', value: threads.length, icon: 'forum' },
          { label: 'Em Aberto', value: openCount, icon: 'mark_chat_unread', tone: 'warn' },
          { label: 'Aguardam Encarregado', value: waitingCount, icon: 'hourglass_top' },
          { label: 'Resolvidas', value: threads.filter((t) => t.status === 'resolvida').length, icon: 'mark_chat_read' }
        ]}
      />

      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-[320px_1fr] min-h-[480px]">
        <div className="border-b lg:border-b-0 lg:border-r border-slate-100 flex flex-col">
          <div className="p-3 border-b border-slate-100">
            <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Pesquisar conversa..." />
          </div>
          <div className="overflow-y-auto max-h-[460px]">
            {filtered.length === 0 && <EmptyState icon="forum" text="Nenhuma conversa encontrada." />}
            {filtered.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedId(t.id)}
                className={`w-full text-left px-4 py-3 border-b border-slate-50 hover:bg-slate-50 ${selected?.id === t.id ? 'bg-slate-100' : ''}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-slate-800 text-xs truncate">{t.subject}</span>
                  <Badge tone={CHAT_STATUS_META[t.status].badge}>{CHAT_STATUS_META[t.status].label}</Badge>
                </div>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">{t.studentName} · {t.guardianName}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">{fmtDateTime(t.lastMessageAt)}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col">
          {!selected ? (
            <EmptyState icon="chat" text="Selecione uma conversa para ver o histórico." />
          ) : (
            <>
              <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-bold text-[#0b1f3a] text-sm truncate">{selected.subject}</p>
                  <p className="text-[11px] text-slate-500 truncate">
                    {selected.studentName} ({selected.studentProcNumber}) · Enc.: {selected.guardianName}
                  </p>
                </div>
                {canManage && (
                  <div className="flex items-center gap-1 shrink-0">
                    <select
                      value={selected.status}
                      onChange={(e) => handleStatus(e.target.value as ChatThreadStatus)}
                      className="h-8 px-2 text-[11px] border border-slate-300 rounded"
                    >
                      {Object.entries(CHAT_STATUS_META).map(([k, v]) => (
                        <option key={k} value={k}>
                          {v.label}
                        </option>
                      ))}
                    </select>
                    <button onClick={() => setDeleting(selected)} title="Eliminar conversa" className="p-1.5 text-red-500 hover:text-red-700">
                      <span className="material-symbols-outlined text-[18px]">delete</span>
                    </button>
                  </div>
                )}
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[340px]">
                {selected.messages.map((m) => (
                  <div key={m.id} className={`flex ${m.sender === 'escola' ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[75%] rounded-2xl px-3 py-2 text-xs ${
                        m.sender === 'escola' ? 'bg-[#0b1f3a] text-white' : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      <p className="font-bold text-[10px] uppercase tracking-wide opacity-80 mb-0.5">{m.senderName}</p>
                      <p className="whitespace-pre-wrap">{m.content}</p>
                      <p className="text-[9px] opacity-60 mt-1">{fmtDateTime(m.timestamp)}</p>
                    </div>
                  </div>
                ))}
              </div>
              {canManage && (
                <div className="p-3 border-t border-slate-100 flex items-end gap-2">
                  <textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    rows={2}
                    placeholder="Escreva uma mensagem..."
                    className={`${textareaCls} flex-1`}
                  />
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => handleSendReply('escola')}
                      title="Enviar como Escola"
                      className="h-9 px-3 bg-[#0b1f3a] text-white text-[11px] font-bold rounded-lg flex items-center gap-1"
                    >
                      <span className="material-symbols-outlined text-[16px]">send</span>
                      Escola
                    </button>
                    <button
                      onClick={() => handleSendReply('encarregado')}
                      title="Simular resposta do Encarregado"
                      className="h-9 px-3 bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg"
                    >
                      Simular Resposta
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md flex flex-col">
            <FormModalHeader title="Nova Conversa" subtitle="Escola ↔ Encarregado de Educação" icon="forum" onClose={() => setIsFormOpen(false)} />
            <div className="p-6 space-y-4">
              {formError && <div className="bg-red-50 text-red-700 text-xs font-semibold p-3 rounded-lg">{formError}</div>}
              <SearchableSelect label="Aluno" options={studentOptions} value={newStudentId} onChange={setNewStudentId} placeholder="Selecione o aluno" />
              <div>
                <label className={labelCls}>Assunto</label>
                <input value={newSubject} onChange={(e) => setNewSubject(e.target.value)} className={inputCls} placeholder="Ex.: Atraso recorrente" />
              </div>
              <div>
                <label className={labelCls}>Primeira Mensagem</label>
                <textarea value={newMessage} onChange={(e) => setNewMessage(e.target.value)} rows={4} className={textareaCls} />
              </div>
            </div>
            <div className="p-4 border-t border-slate-100 flex justify-end gap-2">
              <button onClick={() => setIsFormOpen(false)} className="h-9 px-4 text-xs font-bold text-slate-600">
                Cancelar
              </button>
              <button onClick={handleCreate} className="h-9 px-5 bg-[#0b1f3a] text-white text-xs font-bold rounded-lg">
                Abrir Conversa
              </button>
            </div>
          </div>
        </div>
      )}

      <AppConfirmModal
        isOpen={!!deleting}
        title="Eliminar Conversa"
        message={`Tem a certeza que pretende eliminar a conversa "${deleting?.subject}"? Esta ação não pode ser revertida.`}
        variant="error"
        confirmLabel="Eliminar"
        onConfirm={handleDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}
