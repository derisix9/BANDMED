import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AutomaticBackupSchedule, BackupFrequency, InstitutionSettings, UserRole } from '../../types';
import { dbService } from '../../services/db';
import {
  BACKUP_FREQUENCY_LABELS,
  WEEKDAY_LABELS,
  computeNextRunIso,
  defaultAutomaticBackupSchedule,
  describeSchedule
} from '../../utils/backupSchedule';

interface TabBackupAutomaticoProps {
  settings: InstitutionSettings;
  currentUserRole?: UserRole;
  onUpdateSettings?: (newSettings: Partial<InstitutionSettings>) => void;
  onSaveAll: (options?: { loadingMessage?: string; successMessage?: string; requiredRule?: string }) => void;
  registerCommit?: (commit: (() => Partial<InstitutionSettings>) | null) => void;
}

/**
 * Configurações > 9. Backup Automático Agendado.
 *
 * Distinta da secção "7. Segurança & Backups": lá o administrador clica em
 * "Gerar Backup Agora" para um backup MANUAL, imediato. Aqui apenas se
 * configura QUANDO uma rotina deve correr sozinha (frequência, hora, dia). A
 * rotina em si (ver `dbService.runScheduledBackupIfDue`, chamada no arranque
 * da app e de hora a hora) escreve no mesmo histórico da secção 7
 * (`settings.backupHistory`), apenas com o estado marcado como "Automático",
 * para nunca haver duas tabelas de backups a fazer a mesma coisa.
 */
export const TabBackupAutomatico: React.FC<TabBackupAutomaticoProps> = ({
  settings,
  currentUserRole,
  onUpdateSettings,
  onSaveAll,
  registerCommit
}) => {
  const initial = settings.automaticBackupSchedule || defaultAutomaticBackupSchedule();

  const [enabled, setEnabled] = useState(initial.enabled);
  const [frequency, setFrequency] = useState<BackupFrequency>(initial.frequency);
  const [time, setTime] = useState(initial.time);
  const [weekday, setWeekday] = useState(initial.weekday ?? 0);
  const [dayOfMonth, setDayOfMonth] = useState(initial.dayOfMonth ?? 1);
  const [retentionCount, setRetentionCount] = useState(String(initial.retentionCount ?? 14));
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const currentDraft: AutomaticBackupSchedule = useMemo(
    () => ({
      enabled,
      frequency,
      time,
      weekday,
      dayOfMonth,
      retentionCount: Number(retentionCount) || 14,
      lastRunIso: initial.lastRunIso
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [enabled, frequency, time, weekday, dayOfMonth, retentionCount]
  );

  const nextRunPreview = useMemo(() => {
    if (!enabled) return null;
    try {
      return computeNextRunIso(currentDraft, initial.lastRunIso);
    } catch {
      return null;
    }
  }, [enabled, currentDraft, initial.lastRunIso]);

  const backupHistory = settings.backupHistory || [];
  const automaticRuns = backupHistory.filter((b) => (b.status || '').toLowerCase().includes('automático'));

  const buildPendingSettings = useCallback(
    (): Partial<InstitutionSettings> => ({
      automaticBackupSchedule: {
        ...initial,
        enabled,
        frequency,
        time,
        weekday,
        dayOfMonth,
        retentionCount: Math.max(1, Number(retentionCount) || 14),
        nextRunIso: enabled ? computeNextRunIso(currentDraft, initial.lastRunIso) : undefined
      }
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [initial, enabled, frequency, time, weekday, dayOfMonth, retentionCount, currentDraft]
  );

  useEffect(() => {
    const commit = () => {
      dbService.addAuditLog({
        userName: '',
        userRole: 'Administrador Geral',
        action: 'Atualização do Agendamento de Backup Automático',
        details: `Agendamento ${enabled ? 'ativado' : 'desativado'}: ${describeSchedule({
          ...initial,
          enabled,
          frequency,
          time,
          weekday,
          dayOfMonth,
          retentionCount: Number(retentionCount) || 14
        })}.`,
        module: 'sistema',
        timestamp: '',
        badgeColor: '#0b1f3a'
      });
      return buildPendingSettings();
    };
    registerCommit?.(commit);
    return () => registerCommit?.(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registerCommit, buildPendingSettings]);

  const handleTestNow = async () => {
    setTesting(true);
    // Grava primeiro o agendamento pendente (para a retenção configurada ser
    // respeitada), depois força uma execução imediata de teste.
    await onSaveAll({
      loadingMessage: 'A gravar agendamento antes do teste...',
      successMessage: 'Agendamento gravado. A gerar backup de teste...',
      requiredRule: 'config.backups'
    });
    dbService.runScheduledBackupIfDue(true);
    triggerToast('Backup automático de teste gerado e adicionado ao histórico da secção 7.');
    setTesting(false);
  };

  return (
    <div className="flex flex-col gap-6">
      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 shadow-xs">
          <span className="material-symbols-outlined text-[20px] text-emerald-600">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-slate-100 flex items-center justify-center text-[#0b1f3a] shrink-0">
            <span className="material-symbols-outlined text-[26px]">backup</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider text-[#ac332b] font-bold">Módulo 09</span>
              <span className="w-1 h-1 rounded-full bg-slate-300" />
              <span className="text-[11px] text-slate-500 font-medium">Rotina de Backup Automático</span>
            </div>
            <h2 className="font-headline text-lg lg:text-xl font-bold text-slate-900">
              Backup Automático Agendado
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-2.5 py-1 rounded-lg border font-mono text-[11px] font-bold ${
              enabled
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-slate-100 text-slate-500 border-slate-200'
            }`}
          >
            {enabled ? 'AGENDAMENTO ATIVO' : 'AGENDAMENTO DESATIVADO'}
          </span>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs flex items-start gap-2">
        <span className="material-symbols-outlined text-[18px] shrink-0">info</span>
        <span>
          Este agendamento não substitui o botão <strong>"Gerar Backup Agora"</strong> da secção{' '}
          <strong>7. Segurança & Backups</strong> — esse continua a servir para uma cópia manual imediata. Aqui
          define-se apenas quando a rotina deve correr sozinha; o resultado é escrito na mesma tabela de
          histórico da secção 7, identificado como "Automático".
        </span>
      </div>

      {/* Bloco 1: Configuração da rotina */}
      <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-headline text-base lg:text-lg font-bold text-slate-900">
              1. Frequência & Horário da Rotina
            </h3>
            <p className="text-xs text-slate-500">Escolha quando o sistema deve gerar sozinho uma cópia de segurança.</p>
          </div>
          <button
            type="button"
            onClick={() => setEnabled(!enabled)}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
              enabled ? 'bg-[#0b1f3a]' : 'bg-slate-300'
            }`}
          >
            <div
              className={`w-4.5 h-4.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                enabled ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 text-xs ${!enabled ? 'opacity-50 pointer-events-none' : ''}`}>
          <div className="flex flex-col gap-1.5">
            <label className="font-bold text-slate-900">Frequência</label>
            <select
              value={frequency}
              onChange={(e) => setFrequency(e.target.value as BackupFrequency)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800"
            >
              {(Object.keys(BACKUP_FREQUENCY_LABELS) as BackupFrequency[]).map((f) => (
                <option key={f} value={f}>
                  {BACKUP_FREQUENCY_LABELS[f]}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="font-bold text-slate-900">Hora do Dia (WAT)</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800"
            />
          </div>

          {frequency === 'semanal' && (
            <div className="flex flex-col gap-1.5">
              <label className="font-bold text-slate-900">Dia da Semana</label>
              <select
                value={weekday}
                onChange={(e) => setWeekday(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800"
              >
                {WEEKDAY_LABELS.map((label, idx) => (
                  <option key={label} value={idx}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
          )}

          {frequency === 'mensal' && (
            <div className="flex flex-col gap-1.5">
              <label className="font-bold text-slate-900">Dia do Mês</label>
              <input
                type="number"
                min={1}
                max={28}
                value={dayOfMonth}
                onChange={(e) => setDayOfMonth(Math.min(28, Math.max(1, Number(e.target.value) || 1)))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800"
              />
              <span className="text-[10px] text-slate-400">Máximo 28, para funcionar em todos os meses.</span>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <label className="font-bold text-slate-900">Retenção (nº de cópias)</label>
            <input
              type="number"
              min={1}
              max={365}
              value={retentionCount}
              onChange={(e) => setRetentionCount(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800"
            />
            <span className="text-[10px] text-slate-400">Cópias automáticas mais antigas são descartadas além deste número.</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-500 text-[11px] uppercase font-bold">Estado Atual</span>
            <div className="font-headline text-base font-bold text-slate-900 mt-1">
              {describeSchedule(currentDraft)}
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-500 text-[11px] uppercase font-bold">Próxima Execução Prevista</span>
            <div className="font-headline text-base font-bold text-slate-900 mt-1">
              {nextRunPreview ? new Date(nextRunPreview).toLocaleString('pt-PT') : '—'}
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-slate-500 text-[11px] uppercase font-bold">Última Execução Automática</span>
            <div className="font-headline text-base font-bold text-slate-900 mt-1">
              {initial.lastRunIso ? new Date(initial.lastRunIso).toLocaleString('pt-PT') : 'Ainda não correu'}
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            disabled={testing}
            onClick={handleTestNow}
            className="px-4 py-2 rounded-xl bg-[#0b1f3a] hover:bg-[#7a0c0c] text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer disabled:opacity-60"
          >
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span>Gravar & Testar Agora</span>
          </button>
        </div>
      </section>

      {/* Bloco 2: Histórico gerado automaticamente */}
      <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-4">
        <div className="pb-3 border-b border-slate-100">
          <h3 className="font-headline text-base lg:text-lg font-bold text-slate-900">
            2. Cópias Geradas por Esta Rotina
          </h3>
          <p className="text-xs text-slate-500">
            Mesmo histórico da secção 7 (Segurança & Backups), filtrado apenas às execuções automáticas.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <th className="py-2.5 px-3 rounded-l-lg">Arquivo</th>
                <th className="py-2.5 px-3">Tamanho</th>
                <th className="py-2.5 px-3">Data e Hora (WAT)</th>
                <th className="py-2.5 px-3 rounded-r-lg">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {automaticRuns.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-6 text-center text-slate-400">
                    Ainda nenhum backup automático foi executado.
                  </td>
                </tr>
              ) : (
                automaticRuns.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-semibold text-slate-900">{b.arquivo}</td>
                    <td className="py-3 px-3 font-mono text-slate-600">{b.tamanho}</td>
                    <td className="py-3 px-3 text-slate-600">{b.data}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 text-[10px] font-bold">
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
