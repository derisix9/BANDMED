import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  currentUserRole: UserRole;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  isDesktopOpen?: boolean;
  onToggleDesktop?: (open?: boolean) => void;
  /** Recolhe o menu quando o rato sai da área do sidebar (sem gravar a preferência). */
  onAutoCollapse?: () => void;
  onLogout?: () => void;
}

// ---------------------------------------------------------------------------------
// Estrutura de navegação por categoria.
//
// Cada grupo pode expandir/recolher (clique no cabeçalho) e mostra os seus itens.
// Um item marcado com `implemented: false` aparece esbatido, com o rótulo
// "Em Desenvolvimento" e não é clicável — é um lugar reservado para uma
// funcionalidade futura, para já se ver a organização final do menu.
//
// `roles`, quando indicado num item, restringe ainda mais esse item dentro de um
// grupo já visível para um conjunto maior de perfis (ex: em "Gestão Académica",
// o grupo é visível para Secretaria e Professor, mas "Professores" só aparece
// para Admin/Direção).
// ---------------------------------------------------------------------------------

interface NavLeaf {
  /** Identificador de view usado em onNavigate. Vazio/omitido para itens "Em Desenvolvimento". */
  view?: string;
  label: string;
  icon: string;
  implemented: boolean;
  roles?: UserRole[];
}

interface NavGroup {
  key: string;
  label: string;
  icon: string;
  roles: UserRole[];
  items: NavLeaf[];
  /** Cor do rótulo do grupo (por defeito cinza institucional). */
  accent?: 'default' | 'amber';
}

const ALL_ROLES: UserRole[] = [
  'admin',
  'director',
  'secretaria',
  'professor',
  'financeiro',
  'aluno',
  'encarregado',
  'funcionario'
];

const NAV_GROUPS: NavGroup[] = [
  {
    key: 'geral',
    label: 'Geral',
    icon: 'space_dashboard',
    roles: ['admin', 'director', 'secretaria'],
    items: [{ view: 'dashboard', label: '1. Dashboard', icon: 'dashboard', implemented: true }]
  },
  
    {
    key: 'turmas_disciplinas',
    label: 'Cadastro',
    icon: 'meeting_room',
    roles: ['admin', 'director', 'secretaria'],
    items: [
	  { view: 'matriculas', label: '1. Matrículas', icon: 'assignment_turned_in',implemented: true},
      { view: 'turmas', label: '2. Turmas', icon: 'groups', implemented: true },
      { view: 'disciplinas', label: '3. Disciplinas', icon: 'table_rows', implemented: true },
      { view: 'cursos', label: '4. Cursos', icon: 'school', implemented: true },
	  { view: 'horarios', label: '5. Horários', icon: 'calendar_month', implemented: true },
      { view: 'mapa_salas', label: '6. Mapa de Salas', icon: 'apartment', implemented: true },
      { view: 'departamentos', label: '7. Departamentos', icon: 'account_tree', implemented: true }
    ]
  },
 
  {
    key: 'area_estudante',
    label: 'Portal Académico',
    icon: 'school',
    roles: ['aluno'],
    accent: 'amber',
    items: [
      { view: 'aluno_notas', label: '1. Consultar', icon: 'assignment', implemented: true },
      { view: 'aluno_financeiro', label: '2. Finanças', icon: 'account_balance_wallet', implemented: true }
    ]
  },
  
  {
    key: 'portal_encarregado',
    label: 'Portal Online',
    icon: 'family_restroom',
    roles: ['encarregado'],
    accent: 'amber',
    items: [
      { view: 'encarregado_financeiro', label: '1. Finanças', icon: 'payments', implemented: true }
    ]
  },
  
  {
    key: 'academico',
    label: 'Registro',
    icon: 'menu_book',
    roles: ['admin', 'director', 'secretaria', 'professor'],
    items: [
      { view: 'alunos', label: '1. Alunos', icon: 'person_add', implemented: true },
      { view: 'professores', label: '2. Professores', icon: 'badge', implemented: true, roles: ['admin', 'director'] },
      { view: 'funcionarios', label: '3. Funcionários', icon: 'groups', implemented: true, roles: ['admin', 'director'] }
    ]
  },

  {
    key: 'encarregados_gestao',
    label: 'Serviços',
    icon: 'diversity_3',
    // O docente entra no grupo para chegar a "Lançar Notas", "Assiduidade", "Folha de
    // Chamada" e "Banco de Questões". Os itens sem `roles` abaixo ficam só para a gestão.
    roles: ['admin', 'director', 'secretaria', 'professor'],
    items: [
	  { view: 'pautas', label: '1. Lançar Notas', icon: 'assignment', implemented: true,roles: ['admin', 'director', 'secretaria', 'professor']},
      { view: 'assiduidade', label: '2. Assiduidade Diária', icon: 'event_available', implemented: true, roles: ['admin', 'director', 'secretaria', 'professor']},
       // "Importar Pauta (Excel)" e "Homologação de Pauta" passaram a estar
      // dentro de "Lançamento de Notas" (âmbito por disciplina do professor,
      // ou geral para Admin/Pedagógico) — não repetir aqui no menu.
	  { view: 'folha_chamada_prova', label: '3. Folha de Chamada (Provas)', icon: 'fact_check', implemented: true,  roles: ['admin', 'director', 'secretaria', 'professor']},
	  { view: 'vinculo_filhos', label: '4. Vínculo/Desvínculo de Filhos', icon: 'link', implemented: true, roles: ['admin', 'director', 'secretaria'] },
      { view: 'admissoes', label: '5. Pré-Matrícula / Admissões', icon: 'how_to_reg', implemented: true, roles: ['admin', 'director', 'secretaria'] },
	  { view: 'banco_questoes', label: '6. Banco de Questões / Exames', icon: 'quiz', implemented: true, roles: ['admin', 'director', 'professor'] },
      { view: 'plano_curricular', label: '7. Plano Curricular & Conteúdos', icon: 'auto_stories', implemented: true, roles: ['admin', 'director', 'secretaria'] },
      { view: 'atividades_extracurriculares', label: '8. Atividades Extracurriculares', icon: 'sports_soccer', implemented: true, roles: ['admin', 'director', 'secretaria'] },
	  { view: 'refeitorio', label: '9. Refeitório', icon: 'restaurant', implemented: true, roles: ['admin', 'director', 'secretaria'] }
    ]
  },
  {
    key: 'pessoas',
    label: 'RECURSOS HUMANOS',
    icon: 'groups',
    roles: ['admin', 'director'],
    items: [
      { view: 'folha_pagamento', label: '1. Folha de Pagamento', icon: 'request_quote', implemented: true, roles: ['admin', 'director'] },
      { view: 'avaliacao_desempenho_docente', label: '2. Avaliação de Desempenho Docente', icon: 'insights', implemented: true, roles: ['admin', 'director'] },
      { view: 'ferias_licencas', label: '3. Férias & Licenças', icon: 'beach_access', implemented: true, roles: ['admin', 'director'] }
    ]
  },
  {
    key: 'financeiro',
    label: 'FINANÇAS',
    icon: 'payments',
    roles: ['admin', 'secretaria', 'financeiro'],
    items: [
      { view: 'propinas', label: '1. Pagamentos', icon: 'payments', implemented: true },
    ]
  },
  
    {
    key: 'relatorios',
    label: 'RELATÓRIOS',
    icon: 'bar_chart',
    roles: ['admin', 'director', 'secretaria', 'professor'],
    items: [
      { view: 'relatorios', label: '1. Relatórios', icon: 'bar_chart', implemented: true },
      { label: '2. Dashboard Preditivo', icon: 'trending_up', implemented: false },
      { label: '3. Exportação para o MED', icon: 'flag', implemented: false }
    ]
  },
  
    {
    key: 'patrimonio',
    label: 'LOGÍSTICA',
    icon: 'inventory_2',
    roles: ['admin', 'director'],
    items: [
      { view: 'fornecedores', label: '1. Fornecedores', icon: 'local_shipping', implemented: true },
      { view: 'inventario_ativos', label: '2. Inventário de Ativos', icon: 'inventory_2', implemented: true },
      { view: 'controlo_estoque', label: '3. Controlo de Estoque', icon: 'warehouse', implemented: true },
      { view: 'transporte_escolar', label: '4. Transporte Escolar', icon: 'directions_bus', implemented: true }
    ]
  },
  
  {
    key: 'saude_seguranca',
    label: 'SAÚDE & SEGURANÇA',
    icon: 'health_and_safety',
    roles: ['admin', 'director', 'secretaria'],
    items: [
      { view: 'saude_ficha_medica', label: '1. Ficha Médica do Aluno', icon: 'medical_information', implemented: true },
      { view: 'saude_incidentes', label: '2. Incidentes Disciplinares', icon: 'report', implemented: true },
      { view: 'saude_recolha', label: '3. Autorizações de Recolha', icon: 'badge', implemented: true }
    ]
  },

  {
    key: 'mural',
    label: 'COMUNICAÇÃO',
    icon: 'campaign',
    roles: ALL_ROLES,
    items: [
      { view: 'mural_biblioteca', label: '1. Informações', icon: 'campaign', implemented: true },
      { view: 'comunicacao_notificacoes', label: '2. Notificações SMS/WhatsApp', icon: 'sms', implemented: true, roles: ['admin', 'director', 'secretaria'] },
      { view: 'comunicacao_reunioes', label: '3. Reuniões Pais-Professores', icon: 'groups_2', implemented: true, roles: ['admin', 'director', 'secretaria'] },
      { view: 'comunicacao_chat', label: '4. Chat Encarregado ↔ Escola', icon: 'forum', implemented: true, roles: ['admin', 'director', 'secretaria'] }
    ]
  },
  
  {
    key: 'configuracoes',
    label: 'CONFIGURAÇÕES',
    icon: 'settings',
    roles: ['admin', 'director'],
    items: [
      { view: 'configuracoes/instituicao', label: '1. Dados da Instituição', icon: 'apartment', implemented: true },
      { view: 'configuracoes/ano-letivo', label: '2. Ano Letivo & Calendário', icon: 'date_range', implemented: true },
      { view: 'configuracoes/financeiro', label: '3. Tabela Financeira', icon: 'request_quote', implemented: true },
      { view: 'configuracoes/notas', label: '4. Regras & Escala de Notas', icon: 'rule', implemented: true },
      { view: 'configuracoes/perfis', label: '5. Perfis & Permissões', icon: 'admin_panel_settings', implemented: true },
      { view: 'configuracoes/integracoes', label: '6. Integrações & AGT', icon: 'hub', implemented: true },
      { view: 'configuracoes/seguranca-backups', label: '7. Segurança & Backups', icon: 'security', implemented: true },
      { view: 'configuracoes/utilizadores', label: '8. Criação de Utilizadores', icon: 'group_add', implemented: true },
      { view: 'configuracoes/backup-automatico', label: '9. Backup Automático Agendado', icon: 'backup', implemented: true },
      { view: 'configuracoes/protecao-dados', label: '10. Política de Proteção de Dados', icon: 'policy', implemented: true }
    ]
  }
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  currentUserRole,
  isMobileOpen,
  onCloseMobile,
  isDesktopOpen = true,
  onToggleDesktop,
  onAutoCollapse,
  onLogout
}) => {
  const isAllowed = (roles: UserRole[]) => roles.includes(currentUserRole);

  // Um grupo "contém" a view atual se algum dos seus itens apontar exatamente
  // para ela, ou (caso de Configurações) se a view atual começar por
  // "configuracoes" — assim o grupo certo já nasce aberto.
  const groupContainsCurrentView = (group: NavGroup) =>
    group.items.some((item) => item.view && (item.view === currentView || currentView.startsWith(item.view + '/')));

  const [openGroups, setOpenGroups] = React.useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    NAV_GROUPS.forEach((g) => {
      initial[g.key] =
        g.key === 'geral' ||
        g.key === 'area_estudante' ||
        g.key === 'portal_encarregado' ||
        currentView.startsWith('configuracoes')
          ? true
          : groupContainsCurrentView(g) || g.key === 'academico' || g.key === 'operacional' || g.key === 'mural';
    });
    return initial;
  });

  const toggleGroup = (key: string) => {
    setOpenGroups((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // ---------------------------------------------------------------------------------
  // Auto-minimizar: o menu só é maximizado com um clique no botão de menu. Assim que o
  // rato sai da área do sidebar, este volta a recolher sozinho. Só arranca depois de o
  // rato ter entrado pelo menos uma vez, para que o menu não feche logo a seguir a ser
  // aberto se o ponteiro estiver noutro sítio do ecrã.
  // ---------------------------------------------------------------------------------
  const pointerHasEnteredRef = React.useRef(false);
  const collapseTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  React.useEffect(() => {
    if (!isDesktopOpen) {
      pointerHasEnteredRef.current = false;
    }
    return () => {
      if (collapseTimerRef.current) clearTimeout(collapseTimerRef.current);
    };
  }, [isDesktopOpen]);

  const isDesktopViewport = () =>
    typeof window !== 'undefined' && window.innerWidth >= 1024;

  const handleSidebarMouseEnter = () => {
    if (collapseTimerRef.current) {
      clearTimeout(collapseTimerRef.current);
      collapseTimerRef.current = null;
    }
    if (isDesktopViewport()) {
      pointerHasEnteredRef.current = true;
    }
  };

  const handleSidebarMouseLeave = () => {
    if (!onAutoCollapse) return;
    if (!isDesktopOpen || !isDesktopViewport()) return;
    if (!pointerHasEnteredRef.current) return;
    // Pequena tolerância para que um desvio momentâneo do rato não feche o menu.
    if (collapseTimerRef.current) clearTimeout(collapseTimerRef.current);
    collapseTimerRef.current = setTimeout(() => {
      pointerHasEnteredRef.current = false;
      onAutoCollapse();
    }, 220);
  };

  const navItemClass = (viewId: string) => {
    const active = currentView === viewId;
    return active
      ? 'flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-white text-[#0b1f3a] font-bold shadow-md transition-all'
      : 'flex items-center gap-3 px-3.5 py-2 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white transition-all text-sm font-medium';
  };

  const navItemIconClass = (viewId: string) => {
    return currentView === viewId ? 'text-[#0b1f3a]' : 'text-slate-400 group-hover:text-white';
  };

  const roleBadgeLabel: Record<UserRole, string> = {
    admin: 'Admin',
    director: 'Direção',
    secretaria: 'Secretaria',
    professor: 'Docente',
    financeiro: 'Tesouraria',
    aluno: 'Aluno',
    encarregado: 'Encarregado',
    funcionario: 'Funcionário'
  };

  const renderGroup = (group: NavGroup) => {
    if (!isAllowed(group.roles)) return null;

    const visibleItems = group.items.filter((item) => !item.roles || isAllowed(item.roles));
    if (visibleItems.length === 0) return null;

    const isOpen = openGroups[group.key] ?? true;
    const labelColorClass = group.accent === 'amber' ? 'text-amber-400' : 'text-slate-400';

    return (
      <div key={group.key}>
        <button
          type="button"
          onClick={() => toggleGroup(group.key)}
          className="w-full flex items-center justify-between px-3 mb-1 cursor-pointer group/header"
          aria-expanded={isOpen}
        >
          <span className={`text-[10px] uppercase font-bold tracking-widest ${labelColorClass} group-hover/header:text-white transition-colors`}>
            {group.label}
          </span>
          <span
            className={`material-symbols-outlined text-[16px] text-slate-500 group-hover/header:text-white transition-transform duration-200 ${
              isOpen ? 'rotate-0' : '-rotate-90'
            }`}
          >
            expand_more
          </span>
        </button>

        {isOpen && (
          <div className="space-y-1 mb-3">
            {visibleItems.map((item) => {
              if (!item.implemented || !item.view) {
                return (
                  <div
                    key={item.label}
                    title="Funcionalidade em desenvolvimento"
                    className="flex items-center gap-3 px-3.5 py-2 rounded-xl text-slate-500 text-sm font-medium opacity-50 cursor-not-allowed select-none"
                  >
                    <span className="material-symbols-outlined text-[20px] text-slate-600">{item.icon}</span>
                    <span className="flex-1 truncate">{item.label}</span>
                    <span className="text-[8px] uppercase font-bold tracking-wide bg-slate-700/60 text-slate-300 px-1.5 py-0.5 rounded shrink-0">
                      Em Desenv.
                    </span>
                  </div>
                );
              }

              const viewId = item.view;
              return (
                <button
                  key={viewId}
                  onClick={() => {
                    onNavigate(viewId);
                    onCloseMobile();
                  }}
                  className={`w-full text-left cursor-pointer ${navItemClass(viewId)}`}
                >
                  <span className={`material-symbols-outlined text-[20px] ${navItemIconClass(viewId)}`}>
                    {item.icon}
                  </span>
                  <span className="flex-1 truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      {/* Main Aside - Supports desktop & fullscreen toggle with smooth transition */}
      <aside
        onMouseEnter={handleSidebarMouseEnter}
        onMouseLeave={handleSidebarMouseLeave}
        className={`fixed top-0 bottom-0 left-0 w-64 bg-[#0b1f3a] text-white z-50 flex flex-col justify-between shadow-2xl transition-transform duration-300 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        } ${
          isDesktopOpen ? 'lg:translate-x-0' : 'lg:-translate-x-full'
        }`}
      >
        <div className="flex flex-col flex-1 overflow-y-auto">
          {/* Brand Header */}
          <div className="h-16 px-4 flex items-center justify-between bg-black/20 border-b border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center p-1 shadow-sm shrink-0 overflow-hidden">
                <img
                  src="/school_emblem.png"
                  alt="BandMed Emblema"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-base tracking-tight text-white font-headline">BANDMED</span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] uppercase font-bold tracking-wider bg-[#7a0c0c] text-white">
                    {roleBadgeLabel[currentUserRole] || 'Utilizador'}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 tracking-wider uppercase font-medium">Plataforma Académica</span>
              </div>
            </div>
            <button
              onClick={() => {
                if (onToggleDesktop) onToggleDesktop(false);
                onCloseMobile();
              }}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/15 bg-white/5 cursor-pointer flex items-center justify-center transition-colors"
              title="Fechar menu lateral"
              aria-label="Fechar menu lateral"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>

          {/* Navigation Items — organizados por categoria, cada uma expansível */}
          <nav className="p-3 flex-1">
            {NAV_GROUPS.map((group) => renderGroup(group))}
          </nav>
        </div>

        {/* Footer Brand Info */}
        <div className="p-3 bg-black/30 border-t border-slate-700/40">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#7a0c0c] text-[16px]">verified_user</span>
              <span className="font-semibold text-slate-200">BandMed</span>
            </div>
            <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-white">v3.4.2 Enterprise</span>
          </div>
        </div>
      </aside>
    </>
  );
};
