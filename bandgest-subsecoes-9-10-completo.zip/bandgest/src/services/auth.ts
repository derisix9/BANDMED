import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updatePassword,
  onAuthStateChanged,
  reauthenticateWithCredential,
  EmailAuthProvider,
  type User as FirebaseUser
} from 'firebase/auth';
import { auth, withSecondaryAuth } from './firebase';

/**
 * This module is the ONLY place in the app that talks to Firebase Authentication.
 * No password is ever read from or written to Firestore/IndexedDB/localStorage —
 * `db.ts` calls into these functions and only ever keeps the resulting UID.
 */

/**
 * Firebase esconde a causa real de muitas falhas de configuração dentro de
 * `auth/internal-error`. O motivo verdadeiro vem no corpo HTTP da resposta do
 * Identity Toolkit (`customData.serverResponse.error.message`), por exemplo:
 *   CONFIGURATION_NOT_FOUND | PROJECT_NOT_FOUND | OPERATION_NOT_ALLOWED |
 *   PERMISSION_DENIED | "Identity Toolkit API has not been used in project ..."
 * Esta função extrai esse motivo para podermos dar uma mensagem útil.
 */
function extractServerReason(raw: any): string {
  try {
    const sr =
      raw?.customData?.serverResponse ||
      raw?.serverResponse ||
      (typeof raw?.customData?._serverResponse === 'object' ? raw.customData._serverResponse : null);
    const msg = sr?.error?.message || sr?.message;
    if (typeof msg === 'string') return msg.toUpperCase();
  } catch {
    // ignore
  }
  const fallback = typeof raw?.message === 'string' ? raw.message : '';
  return fallback.toUpperCase();
}

/** Mensagem única e acionável para "o Firebase Authentication não está pronto". */
export const AUTH_NOT_CONFIGURED_MESSAGE =
  'O fornecedor "E-mail/Palavra-passe" não está ativo neste projeto Firebase. ' +
  'Abra a Firebase Console → Authentication → Sign-in method, ative "Email/Password" e guarde. ' +
  'Sem isso, nem o login nem o registo conseguem funcionar — o pedido é recusado antes de a conta ser verificada.';

/** Códigos/motivos que significam "problema de configuração do projeto", não do utilizador. */
const CONFIG_REASONS = [
  'CONFIGURATION_NOT_FOUND',
  'PASSWORD_LOGIN_DISABLED',
  'EMAIL_PASSWORD_LOGIN_DISABLED',
  'PROJECT_NOT_FOUND',
  'OPERATION_NOT_ALLOWED',
  'IDENTITY TOOLKIT API HAS NOT BEEN USED',
  'IDENTITYTOOLKIT.GOOGLEAPIS.COM',
  'SERVICE_DISABLED',
  'ADMIN_ONLY_OPERATION'
];

export function isConfigurationProblem(codeOrReason: string | undefined, raw?: any): boolean {
  const code = (codeOrReason || '').toLowerCase();
  if (
    code === 'auth/configuration-not-found' ||
    code === 'auth/operation-not-allowed' ||
    code === 'auth/project-not-found' ||
    code === 'auth/admin-restricted-operation' ||
    code === 'auth/invalid-api-key' ||
    code === 'auth/api-key-not-valid.-please-pass-a-valid-api-key.'
  ) {
    return true;
  }
  const reason = extractServerReason(raw);
  return CONFIG_REASONS.some((r) => reason.includes(r));
}

function translateAuthError(code: string | undefined, raw?: any): string {
  // 1) Problemas de configuração do projeto vêm primeiro: produzem exatamente o
  //    mesmo sintoma no login E no registo, e nenhuma mensagem sobre
  //    "credenciais" faria sentido, porque a conta nem chega a ser verificada.
  if (isConfigurationProblem(code, raw)) {
    return AUTH_NOT_CONFIGURED_MESSAGE;
  }

  switch (code) {
    case 'auth/invalid-email':
      return 'O endereço de e-mail introduzido não é válido.';
    case 'auth/user-disabled':
      return 'Esta conta foi desativada. Contacte o administrador.';
    case 'auth/user-not-found':
      return 'Não existe nenhuma conta registada com este e-mail. Se ainda não se registou, use a opção "Registar".';
    case 'auth/wrong-password':
      return 'Palavra-passe incorreta.';
    case 'auth/invalid-credential':
    case 'auth/invalid-login-credentials':
      // O Firebase moderno devolve este código tanto para "conta inexistente"
      // como para "palavra-passe errada" (proteção contra enumeração de contas).
      return 'E-mail ou palavra-passe incorretos. Se ainda não criou a conta nesta plataforma, use "Registar".';
    case 'auth/too-many-requests':
      return 'Demasiadas tentativas falhadas. Tente novamente dentro de alguns minutos.';
    case 'auth/email-already-in-use':
      return 'Já existe uma conta registada com este e-mail. Use "Iniciar sessão" ou recupere a palavra-passe.';
    case 'auth/weak-password':
      return 'A palavra-passe é demasiado fraca (mínimo 6 caracteres).';
    case 'auth/network-request-failed':
      return 'Falha de ligação à rede. Verifique a ligação à Internet e se o domínio está autorizado no Firebase.';
    case 'auth/requires-recent-login':
      return 'Por segurança, volte a iniciar sessão antes de alterar a palavra-passe.';
    case 'auth/app-not-authorized':
    case 'auth/unauthorized-domain':
      return 'Este domínio não está autorizado a usar o login. Adicione-o em Firebase Console → Authentication → Settings → Authorized domains.';
    case 'auth/internal-error':
      return (
        'O serviço de autenticação devolveu um erro interno. Normalmente significa que a ' +
        'Identity Toolkit API não está ativada no projeto Google Cloud, ou que a chave de API ' +
        'tem restrições que bloqueiam este domínio. (código: auth/internal-error)'
      );
    default: {
      if (typeof console !== 'undefined') {
        console.error('[Firebase Auth] Código de erro não mapeado:', code, raw);
      }
      const suffix = code ? ` (código: ${code})` : '';
      return `Ocorreu um erro de autenticação. Tente novamente.${suffix}`;
    }
  }
}

export async function signIn(
  email: string,
  password: string
): Promise<{ success: boolean; uid?: string; error?: string; code?: string; configIssue?: boolean }> {
  try {
    const credential = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, uid: credential.user.uid };
  } catch (e: any) {
    return {
      success: false,
      error: translateAuthError(e?.code, e),
      code: e?.code,
      configIssue: isConfigurationProblem(e?.code, e)
    };
  }
}

/**
 * Creates a new Firebase Auth account for someone OTHER than the currently
 * signed-in user (e.g. an admin registering a teacher or student), without
 * disturbing the admin's own session. Uses a disposable secondary Auth
 * instance internally.
 */
export async function createAccount(
  email: string,
  password: string
): Promise<{ success: boolean; uid?: string; error?: string; code?: string; configIssue?: boolean }> {
  try {
    const uid = await withSecondaryAuth(async (secondaryAuth) => {
      const credential = await createUserWithEmailAndPassword(secondaryAuth, email, password);
      return credential.user.uid;
    });
    return { success: true, uid };
  } catch (e: any) {
    return {
      success: false,
      error: translateAuthError(e?.code, e),
      code: e?.code,
      configIssue: isConfigurationProblem(e?.code, e)
    };
  }
}

export async function signOutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (e) {
    console.warn('Erro ao terminar sessão Firebase Auth:', e);
  }
}

export async function sendPasswordReset(
  email: string
): Promise<{ success: boolean; error?: string }> {
  try {
    await sendPasswordResetEmail(auth, email.trim().toLowerCase());
    return { success: true };
  } catch (e: any) {
    return { success: false, error: translateAuthError(e?.code, e) };
  }
}

/**
 * Changes the password of the CURRENTLY signed-in user. Firebase requires a
 * recent login for this; if it fails with `auth/requires-recent-login`, the
 * caller should ask the user to sign in again first.
 */
export async function updateOwnPassword(
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const user = auth.currentUser;
  if (!user) {
    return { success: false, error: 'Não existe nenhuma sessão ativa.' };
  }
  try {
    await updatePassword(user, newPassword);
    return { success: true };
  } catch (e: any) {
    return { success: false, error: translateAuthError(e?.code, e) };
  }
}

export function getCurrentAuthUid(): string | null {
  return auth.currentUser?.uid || null;
}

/**
 * Subscribes to Firebase Auth's own session state — the single source of
 * truth for whether the current browser holds a valid token. This is what
 * `App.tsx` uses to bootstrap/close sessions instead of trusting localStorage
 * blindly.
 */
export function watchAuthState(callback: (user: FirebaseUser | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

// -----------------------------------------------------------------------------
// Diagnóstico de configuração
// -----------------------------------------------------------------------------

export type AuthDiagnosis =
  | { status: 'ok'; message: string }
  | { status: 'not-enabled'; message: string; howToFix: string[] }
  | { status: 'bad-key'; message: string; howToFix: string[] }
  | { status: 'network'; message: string; howToFix: string[] }
  | { status: 'unknown'; message: string; howToFix: string[] };

/**
 * Pergunta diretamente ao Identity Toolkit se o fornecedor "E-mail/Palavra-passe"
 * está operacional neste projeto, sem precisar de credenciais válidas.
 *
 * Usa `accounts:signInWithPassword` com um e-mail que garantidamente não existe:
 * - se o Auth ESTIVER ativo, a resposta é 400 INVALID_LOGIN_CREDENTIALS/EMAIL_NOT_FOUND
 *   (ou seja, o serviço está de pé — apenas a conta não existe) → 'ok';
 * - se NÃO estiver, a resposta é CONFIGURATION_NOT_FOUND / OPERATION_NOT_ALLOWED /
 *   "Identity Toolkit API has not been used..." → causa exata identificada.
 *
 * É isto que permite ao ecrã de login dizer ao utilizador o que realmente falhou,
 * em vez do genérico "Ocorreu um erro de autenticação".
 */
export async function diagnoseAuthConfig(): Promise<AuthDiagnosis> {
  const apiKey = (auth.app.options as any)?.apiKey as string | undefined;
  const projectId = (auth.app.options as any)?.projectId as string | undefined;

  if (!apiKey) {
    return {
      status: 'bad-key',
      message: 'Não existe nenhuma apiKey na configuração do Firebase.',
      howToFix: ['Preencha o campo "apiKey" em firebase-applet-config.json.']
    };
  }

  const probeEmail = `diagnostico-${Date.now()}@bandmed-check.invalid`;

  try {
    const res = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: probeEmail, password: 'sonda-diagnostico', returnSecureToken: true })
      }
    );

    const body = await res.json().catch(() => ({} as any));
    const reason = String(body?.error?.message || '').toUpperCase();

    if (reason.includes('PASSWORD_LOGIN_DISABLED') || reason.includes('EMAIL_PASSWORD_LOGIN_DISABLED')) {
      return {
        status: 'not-enabled',
        message:
          `O projeto "${projectId}" está a funcionar, mas o fornecedor "E-mail/Palavra-passe" ` +
          'está explicitamente DESATIVADO. É por isso que tanto o login como o registo falham.',
        howToFix: [
          `Abra https://console.firebase.google.com/project/${projectId}/authentication/providers`,
          'Na lista de "Sign-in providers", clique em "Email/Password".',
          'Ligue o interruptor "Enable" (o primeiro, não o de "Email link") e clique em "Save".',
          `Se o projeto usa o Identity Platform, faça o mesmo em https://console.cloud.google.com/customer-identity/providers?project=${projectId}`,
          'Aguarde cerca de 1 minuto, recarregue esta página e volte a tentar.'
        ]
      };
    }

    if (reason.includes('CONFIGURATION_NOT_FOUND') || reason.includes('OPERATION_NOT_ALLOWED')) {
      return {
        status: 'not-enabled',
        message: `O projeto "${projectId}" existe, mas o login por e-mail/palavra-passe não está ativado.`,
        howToFix: [
          `Abra https://console.firebase.google.com/project/${projectId}/authentication/providers`,
          'Clique em "Get started" / "Começar" se o Authentication ainda nunca foi usado.',
          'Ative o fornecedor "Email/Password" (E-mail/Palavra-passe) e guarde.',
          'Recarregue esta página e tente de novo.'
        ]
      };
    }

    if (reason.includes('HAS NOT BEEN USED') || reason.includes('SERVICE_DISABLED') || reason.includes('PERMISSION_DENIED')) {
      return {
        status: 'not-enabled',
        message: 'A Identity Toolkit API não está ativada no projeto Google Cloud associado.',
        howToFix: [
          `Abra https://console.cloud.google.com/apis/library/identitytoolkit.googleapis.com?project=${projectId}`,
          'Clique em "Ativar" e aguarde 1 a 2 minutos pela propagação.',
          'Volte a tentar iniciar sessão.'
        ]
      };
    }

    if (reason.includes('API KEY NOT VALID') || reason.includes('API_KEY_INVALID') || res.status === 403) {
      return {
        status: 'bad-key',
        message: 'A chave de API do Firebase foi recusada (inválida ou restringida a outros domínios).',
        howToFix: [
          `Confirme a "apiKey" em firebase-applet-config.json contra a do projeto ${projectId}.`,
          'Em Google Cloud → APIs & Services → Credentials, verifique as restrições de HTTP referrer da chave.',
          'Adicione o domínio onde a aplicação está publicada (e localhost, em desenvolvimento).'
        ]
      };
    }

    if (reason.includes('PROJECT_NOT_FOUND')) {
      return {
        status: 'bad-key',
        message: `O projeto Firebase "${projectId}" não foi encontrado.`,
        howToFix: ['Verifique o "projectId" e a "apiKey" em firebase-applet-config.json.']
      };
    }

    // EMAIL_NOT_FOUND / INVALID_LOGIN_CREDENTIALS / INVALID_PASSWORD: o serviço
    // respondeu corretamente sobre uma conta inexistente — está tudo operacional.
    if (
      res.ok ||
      reason.includes('EMAIL_NOT_FOUND') ||
      reason.includes('INVALID_LOGIN_CREDENTIALS') ||
      reason.includes('INVALID_PASSWORD') ||
      reason.includes('TOO_MANY_ATTEMPTS')
    ) {
      return {
        status: 'ok',
        message: 'O Firebase Authentication está ativo e a responder. O erro é das credenciais, não da configuração.'
      };
    }

    return {
      status: 'unknown',
      message: `Resposta inesperada do servidor de autenticação: ${body?.error?.message || res.status}`,
      howToFix: ['Abra a consola do navegador (F12) e verifique o detalhe do erro.']
    };
  } catch (e: any) {
    return {
      status: 'network',
      message: 'Não foi possível contactar o servidor de autenticação do Google.',
      howToFix: [
        'Verifique a ligação à Internet.',
        'Confirme que nenhuma firewall/extensão está a bloquear identitytoolkit.googleapis.com.',
        `Confirme que o domínio atual está em Firebase Console → Authentication → Settings → Authorized domains (projeto ${projectId}).`
      ]
    };
  }
}

/**
 * Reconfirma a identidade do utilizador com sessão ativa, exigindo a palavra-passe.
 * É isto que dá valor real a uma "assinatura digital" de homologação: sem esta
 * verificação, qualquer pessoa com o computador desbloqueado assinaria a pauta.
 */
export async function reauthenticate(password: string): Promise<{ success: boolean; error?: string }> {
  const user = auth.currentUser;
  if (!user || !user.email) {
    return { success: false, error: 'Não existe nenhuma sessão ativa para assinar.' };
  }
  try {
    const credential = EmailAuthProvider.credential(user.email, password);
    await reauthenticateWithCredential(user, credential);
    return { success: true };
  } catch (e: any) {
    return { success: false, error: translateAuthError(e?.code, e) };
  }
}
