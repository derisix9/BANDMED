import * as XLSX from 'xlsx';
import { Student } from '../types';
import { StudentMiniPautaItem } from '../types/pauta';
import { calculateMT, calculateMFD, calculateCA, calculateBirthYearAndAge, normalizeGender } from './pautaCalculations';

/**
 * Leitura e validação REAL de ficheiros de pauta (.xlsx / .xls / .csv).
 *
 * Nada aqui é simulado: o ficheiro é lido byte a byte com SheetJS, as colunas são
 * detetadas a partir dos cabeçalhos reais, e cada linha é confrontada com os alunos
 * efetivamente matriculados na turma selecionada. Linhas que não correspondam a
 * nenhum aluno real são marcadas como erro e nunca chegam à base de dados.
 */

export type FieldKey = 'proc' | 'name' | 'gender' | 'birth' | 'mac' | 'npp' | 'npt';

export interface FieldDefinition {
  key: FieldKey;
  label: string;
  required: boolean;
  /** Sinónimos aceites no cabeçalho, já normalizados (sem acentos, maiúsculas). */
  aliases: string[];
}

export const FIELD_DEFINITIONS: FieldDefinition[] = [
  { key: 'proc', label: 'N.º de Processo', required: false, aliases: ['PROC', 'PROC ID', 'PROCESSO', 'N PROCESSO', 'NO PROCESSO', 'NUM PROCESSO', 'MATRICULA', 'PROC_ID'] },
  { key: 'name', label: 'Nome do Aluno', required: true, aliases: ['NOME', 'NOME ALUNO', 'NOME DO ALUNO', 'ALUNO', 'ESTUDANTE', 'NOME_ALUNO', 'NOME COMPLETO'] },
  { key: 'gender', label: 'Género', required: false, aliases: ['SEXO', 'GENERO', 'SEXO IDADE', 'SEXO_IDADE', 'M F'] },
  { key: 'birth', label: 'Data de Nascimento', required: false, aliases: ['NASCIMENTO', 'DATA NASCIMENTO', 'DATA DE NASCIMENTO', 'DT NASC', 'ANO NASCIMENTO'] },
  { key: 'mac', label: 'MAC (30%)', required: true, aliases: ['MAC', 'NOTA MAC', 'NOTA_MAC', 'AVALIACAO CONTINUA', 'MEDIA AVALIACAO CONTINUA'] },
  { key: 'npp', label: 'NPP (30%)', required: true, aliases: ['NPP', 'NOTA NPP', 'NOTA_NPP', 'PROVA PARCIAL', 'NOTA PROVA PARCIAL'] },
  { key: 'npt', label: 'NPT (40%)', required: true, aliases: ['NPT', 'NOTA NPT', 'NOTA_NPT', 'PROVA TRIMESTRAL', 'NOTA PROVA TRIMESTRAL'] }
];

export type ColumnMapping = Partial<Record<FieldKey, number>>;

export interface ParsedSheet {
  name: string;
  /** Cabeçalhos tal como aparecem no ficheiro. */
  headers: string[];
  /** Linhas de dados (já sem o cabeçalho). */
  rows: unknown[][];
  /** Índice (0-based) da linha do ficheiro onde o cabeçalho foi encontrado. */
  headerRowIndex: number;
}

export interface ParsedWorkbook {
  fileName: string;
  fileSizeLabel: string;
  sheets: ParsedSheet[];
}

export type RowStatus = 'valid' | 'warning' | 'error';

export interface ImportRow {
  /** Número da linha no ficheiro original (1-based, como o Excel mostra). */
  excelRow: number;
  rawProc: string;
  rawName: string;
  mac: number | '';
  npp: number | '';
  npt: number | '';
  mt: number | '';
  /** Aluno real da turma com que esta linha foi emparelhada, se algum. */
  matchedStudentId: string | null;
  matchedStudentName: string | null;
  matchMethod: 'processo' | 'nome' | null;
  status: RowStatus;
  messages: string[];
}

// ---------------------------------------------------------------------------
// Leitura do ficheiro
// ---------------------------------------------------------------------------

export function normalizeHeader(value: unknown): string {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .trim()
    .toUpperCase();
}

export function normalizeName(value: unknown): string {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function formatSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

/**
 * Encontra a linha de cabeçalho. Ficheiros oficiais costumam trazer títulos,
 * logótipos e linhas em branco antes da tabela, por isso não se assume a linha 1:
 * procura-se, nas primeiras 25 linhas, aquela que contenha mais campos conhecidos.
 */
function detectHeaderRow(matrix: unknown[][]): number {
  let bestIndex = 0;
  let bestScore = -1;
  const limit = Math.min(matrix.length, 25);

  for (let i = 0; i < limit; i++) {
    const cells = matrix[i] || [];
    let score = 0;
    for (const cell of cells) {
      const norm = normalizeHeader(cell);
      if (!norm) continue;
      if (FIELD_DEFINITIONS.some((f) => f.aliases.includes(norm) || norm === f.key.toUpperCase())) {
        score++;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestIndex = i;
    }
  }

  return bestScore > 0 ? bestIndex : 0;
}

export async function readSpreadsheet(file: File): Promise<ParsedWorkbook> {
  const buffer = await file.arrayBuffer();
  // `raw: false` + `cellDates` mantém datas legíveis; lemos tudo como matriz para
  // podermos localizar o cabeçalho manualmente.
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });

  const sheets: ParsedSheet[] = workbook.SheetNames.map((name) => {
    const sheet = workbook.Sheets[name];
    const matrix = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1,
      blankrows: false,
      defval: ''
    });

    const headerRowIndex = detectHeaderRow(matrix);
    const headers = (matrix[headerRowIndex] || []).map((h) => String(h ?? '').trim());
    const rows = matrix.slice(headerRowIndex + 1).filter((r) => (r || []).some((c) => String(c ?? '').trim() !== ''));

    return { name, headers, rows, headerRowIndex };
  });

  return {
    fileName: file.name,
    fileSizeLabel: formatSize(file.size),
    sheets
  };
}

// ---------------------------------------------------------------------------
// Mapeamento de colunas
// ---------------------------------------------------------------------------

export function autoDetectMapping(headers: string[]): ColumnMapping {
  const normalized = headers.map(normalizeHeader);
  const mapping: ColumnMapping = {};

  for (const field of FIELD_DEFINITIONS) {
    // 1ª passagem: correspondência exata com um sinónimo conhecido.
    let index = normalized.findIndex((h) => h && (h === field.key.toUpperCase() || field.aliases.includes(h)));
    // 2ª passagem: o cabeçalho contém o sinónimo (ex.: "NOTA MAC 30%").
    if (index === -1) {
      index = normalized.findIndex(
        (h) => h && (h.includes(field.key.toUpperCase()) || field.aliases.some((a) => h.includes(a)))
      );
    }
    if (index !== -1 && !Object.values(mapping).includes(index)) {
      mapping[field.key] = index;
    }
  }

  return mapping;
}

export function missingRequiredFields(mapping: ColumnMapping): FieldDefinition[] {
  return FIELD_DEFINITIONS.filter((f) => f.required && mapping[f.key] === undefined);
}

// ---------------------------------------------------------------------------
// Validação das linhas contra os alunos reais
// ---------------------------------------------------------------------------

function parseGrade(raw: unknown): { value: number | ''; error?: string } {
  const text = String(raw ?? '').trim();
  if (!text) return { value: '' };

  // Aceita vírgula decimal (formato pt-PT) e espaços.
  const normalized = text.replace(/\s/g, '').replace(',', '.');
  const num = Number(normalized);

  if (!Number.isFinite(num)) {
    return { value: '', error: `valor "${text}" não é numérico` };
  }
  if (num < 0 || num > 20) {
    return { value: '', error: `nota ${num} fora do intervalo permitido (0 a 20)` };
  }
  return { value: Math.round(num * 100) / 100 };
}

export function buildImportRows(
  sheet: ParsedSheet,
  mapping: ColumnMapping,
  classStudents: Student[]
): ImportRow[] {
  const byProc = new Map<string, Student>();
  const byName = new Map<string, Student>();
  for (const st of classStudents) {
    if (st.procNumber) byProc.set(String(st.procNumber).trim().toLowerCase(), st);
    if (st.name) byName.set(normalizeName(st.name), st);
  }

  const seenStudentIds = new Set<string>();

  return sheet.rows.map((cells, idx) => {
    const excelRow = sheet.headerRowIndex + 2 + idx; // +1 cabeçalho, +1 para 1-based
    const get = (key: FieldKey): unknown =>
      mapping[key] !== undefined ? cells[mapping[key] as number] : '';

    const rawProc = String(get('proc') ?? '').trim();
    const rawName = String(get('name') ?? '').trim();

    const messages: string[] = [];
    let status: RowStatus = 'valid';

    const macParsed = parseGrade(get('mac'));
    const nppParsed = parseGrade(get('npp'));
    const nptParsed = parseGrade(get('npt'));

    for (const [label, parsed] of [['MAC', macParsed], ['NPP', nppParsed], ['NPT', nptParsed]] as const) {
      if (parsed.error) {
        messages.push(`${label}: ${parsed.error}`);
        status = 'error';
      }
    }

    // Emparelhamento com um aluno REAL da turma.
    let matched: Student | undefined;
    let matchMethod: ImportRow['matchMethod'] = null;

    if (rawProc) {
      matched = byProc.get(rawProc.toLowerCase());
      if (matched) matchMethod = 'processo';
    }
    if (!matched && rawName) {
      matched = byName.get(normalizeName(rawName));
      if (matched) matchMethod = 'nome';
    }

    if (!matched) {
      status = 'error';
      messages.push(
        rawName || rawProc
          ? 'não corresponde a nenhum aluno matriculado nesta turma'
          : 'linha sem nome nem n.º de processo'
      );
    } else {
      if (seenStudentIds.has(matched.id)) {
        status = 'error';
        messages.push(`aluno "${matched.name}" aparece repetido no ficheiro`);
      } else {
        seenStudentIds.add(matched.id);
      }

      if (matchMethod === 'nome' && rawProc) {
        status = status === 'error' ? status : 'warning';
        messages.push(`emparelhado pelo nome — o n.º de processo "${rawProc}" não coincide com o do registo`);
      }
      if (matchMethod === 'nome' && !rawProc) {
        status = status === 'error' ? status : 'warning';
        messages.push('emparelhado pelo nome (ficheiro sem n.º de processo)');
      }
    }

    const missing = [
      macParsed.value === '' && !macParsed.error ? 'MAC' : null,
      nppParsed.value === '' && !nppParsed.error ? 'NPP' : null,
      nptParsed.value === '' && !nptParsed.error ? 'NPT' : null
    ].filter(Boolean) as string[];

    if (missing.length > 0 && status !== 'error') {
      status = 'warning';
      messages.push(`sem nota de ${missing.join(', ')} — ficará por lançar`);
    }

    const mt =
      macParsed.value === '' && nppParsed.value === '' && nptParsed.value === ''
        ? ''
        : calculateMT(macParsed.value, nppParsed.value, nptParsed.value);

    return {
      excelRow,
      rawProc,
      rawName,
      mac: macParsed.value,
      npp: nppParsed.value,
      npt: nptParsed.value,
      mt,
      matchedStudentId: matched?.id ?? null,
      matchedStudentName: matched?.name ?? null,
      matchMethod,
      status,
      messages: messages.length > 0 ? messages : ['validado']
    };
  });
}

/** Alunos da turma que não aparecem no ficheiro — o docente deve saber disto. */
export function findMissingStudents(rows: ImportRow[], classStudents: Student[]): Student[] {
  const present = new Set(rows.map((r) => r.matchedStudentId).filter(Boolean) as string[]);
  return classStudents.filter((s) => !present.has(s.id));
}

// ---------------------------------------------------------------------------
// Conversão para as linhas da mini-pauta (o que é gravado)
// ---------------------------------------------------------------------------

export type TrimesterKey = 1 | 2 | 3;

/**
 * Funde as notas importadas com as linhas já existentes da mini-pauta, escrevendo
 * apenas no trimestre escolhido e apenas para as linhas válidas. As notas dos
 * outros trimestres são preservadas tal como estão.
 */
export function mergeImportIntoMiniPauta(
  existingRows: StudentMiniPautaItem[],
  classStudents: Student[],
  subjectId: string,
  importRows: ImportRow[],
  trimester: TrimesterKey
): { rows: StudentMiniPautaItem[]; applied: number } {
  const existingById = new Map(existingRows.map((r) => [String(r.studentId), r]));
  const importByStudent = new Map(
    importRows
      .filter((r) => r.status !== 'error' && r.matchedStudentId)
      .map((r) => [r.matchedStudentId as string, r])
  );

  let applied = 0;

  const rows = classStudents.map((st, idx) => {
    const previous = existingById.get(String(st.id));
    const { birthYear, age } = calculateBirthYearAndAge(st.birthDate);

    const base: StudentMiniPautaItem =
      previous ?? {
        id: `${st.id}-${subjectId}`,
        studentId: st.id,
        num: idx + 1,
        name: st.name || '',
        gender: normalizeGender(st.gender, st.name),
        birthYear,
        age,
        isDebtor: st.financialStatus === 'debito' || !st.isTuitionPaidCurrentMonth,
        isDesistente: st.status === 'suspended' || st.status === 'transferred',
        mac1: '', npp1: '', npt1: '', mt1: '',
        mac2: '', npp2: '', npt2: '', mt2: '',
        mac3: '', npp3: '', npt3: '', mt3: '',
        mfd: '', pg: '', ca: '', obs: ''
      };

    const incoming = importByStudent.get(String(st.id));
    if (!incoming) {
      return { ...base, num: idx + 1 };
    }

    applied++;
    const updated: StudentMiniPautaItem = { ...base, num: idx + 1 };

    if (trimester === 1) {
      updated.mac1 = incoming.mac;
      updated.npp1 = incoming.npp;
      updated.npt1 = incoming.npt;
      updated.mt1 = incoming.mt;
    } else if (trimester === 2) {
      updated.mac2 = incoming.mac;
      updated.npp2 = incoming.npp;
      updated.npt2 = incoming.npt;
      updated.mt2 = incoming.mt;
    } else {
      updated.mac3 = incoming.mac;
      updated.npp3 = incoming.npp;
      updated.npt3 = incoming.npt;
      updated.mt3 = incoming.mt;
    }

    // MFD/CA só se recalculam quando existe pelo menos um trimestre lançado.
    const mfd = calculateMFD(updated.mt1, updated.mt2, updated.mt3);
    updated.mfd = mfd;
    updated.ca = mfd === '' ? '' : calculateCA(mfd);

    return updated;
  });

  return { rows, applied };
}

/** Gera e descarrega um modelo .xlsx com os alunos REAIS da turma selecionada. */
export function downloadTemplateForClass(
  classStudents: Student[],
  className: string,
  subjectName: string
): void {
  const header = ['N_ORDEM', 'PROC_ID', 'NOME_ALUNO', 'SEXO', 'NOTA_MAC', 'NOTA_NPP', 'NOTA_NPT'];
  const body = classStudents.map((st, i) => [
    i + 1,
    st.procNumber || '',
    st.name || '',
    normalizeGender(st.gender, st.name),
    '',
    '',
    ''
  ]);

  const sheet = XLSX.utils.aoa_to_sheet([header, ...body]);
  sheet['!cols'] = [{ wch: 9 }, { wch: 14 }, { wch: 38 }, { wch: 7 }, { wch: 10 }, { wch: 10 }, { wch: 10 }];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, 'Pauta');

  const safe = (s: string) => s.replace(/[^\w\-]+/g, '_').slice(0, 40);
  XLSX.writeFile(workbook, `Modelo_Pauta_${safe(className)}_${safe(subjectName)}.xlsx`);
}

/** Exporta o relatório de validação da importação (auditoria real, não fictícia). */
export function downloadValidationReport(rows: ImportRow[], fileName: string): void {
  const header = ['Linha_Excel', 'Processo_Ficheiro', 'Nome_Ficheiro', 'Aluno_Emparelhado', 'Metodo', 'MAC', 'NPP', 'NPT', 'MT', 'Estado', 'Observacoes'];
  const body = rows.map((r) => [
    r.excelRow,
    r.rawProc,
    r.rawName,
    r.matchedStudentName || '',
    r.matchMethod || '',
    r.mac,
    r.npp,
    r.npt,
    r.mt,
    r.status === 'valid' ? 'Válido' : r.status === 'warning' ? 'Aviso' : 'Erro',
    r.messages.join(' | ')
  ]);

  const sheet = XLSX.utils.aoa_to_sheet([header, ...body]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, 'Validacao');
  XLSX.writeFile(workbook, `Auditoria_${fileName.replace(/\.[^.]+$/, '')}.xlsx`);
}
