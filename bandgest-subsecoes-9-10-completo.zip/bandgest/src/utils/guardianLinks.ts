import {
  GuardianRelation,
  GuardianStudentLink,
  GuardianUnlinkReason,
  Student,
  User
} from '../types';

/**
 * VÍNCULO / DESVÍNCULO DE FILHOS — regras de negócio (sem React nem Firebase).
 *
 * Um Encarregado de Educação é uma conta de utilizador com perfil 'encarregado'.
 * O que ele consegue ver no Portal Online (notas, boletim, finanças) é decidido
 * aqui, num único sítio:
 *
 *  1. Vínculo ATIVO registado em Serviços → Vínculo/Desvínculo de Filhos.
 *  2. Acesso "implícito" herdado da ficha do Aluno (contas criadas antes deste
 *     módulo existir): `linkedStudentId` da conta, e-mail igual ao do encarregado
 *     na ficha, ou nome igual quando a ficha não tem e-mail.
 *  3. Um Desvínculo registado BLOQUEIA sempre o acesso implícito — sem isto,
 *     desvincular um filho não teria qualquer efeito enquanto a ficha do aluno
 *     continuasse a apontar para o mesmo e-mail.
 */

export const GUARDIAN_RELATION_LABELS: Record<GuardianRelation, string> = {
  pai: 'Pai',
  mae: 'Mãe',
  avo: 'Avô / Avó',
  tio: 'Tio / Tia',
  irmao: 'Irmão / Irmã (maior de idade)',
  padrasto_madrasta: 'Padrasto / Madrasta',
  tutor_legal: 'Tutor Legal',
  outro: 'Outro'
};

export const UNLINK_REASON_LABELS: Record<GuardianUnlinkReason, string> = {
  erro_cadastro: 'Vínculo criado por engano / erro de cadastro',
  mudanca_encarregado: 'Mudança de Encarregado de Educação',
  decisao_judicial: 'Decisão judicial / tutela',
  pedido_encarregado: 'A pedido do próprio Encarregado',
  aluno_saiu: 'Aluno transferido ou concluiu os estudos',
  outro: 'Outro motivo'
};

export function normalizeText(value?: string | null): string {
  return (value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Últimos 9 dígitos de um telefone (ignora +244, espaços e hífenes). */
export function phoneKey(value?: string | null): string {
  const digits = (value || '').replace(/\D/g, '');
  return digits.length >= 9 ? digits.slice(-9) : '';
}

export type ChildAccessSource = 'vinculo' | 'ficha';

export interface GuardianChild {
  student: Student;
  /** 'vinculo' = vínculo registado; 'ficha' = herdado dos dados da ficha do aluno. */
  source: ChildAccessSource;
  link?: GuardianStudentLink;
}

type GuardianIdentity = Pick<User, 'id' | 'email' | 'name' | 'linkedStudentId'>;

/** A ficha do aluno aponta para esta conta de Encarregado? (acesso implícito) */
export function isImplicitGuardianMatch(user: GuardianIdentity, student: Student): boolean {
  if (user.linkedStudentId && user.linkedStudentId === student.id) return true;

  const userEmail = normalizeText(user.email);
  const ficheEmail = normalizeText(student.guardianEmail);
  if (userEmail && ficheEmail && userEmail === ficheEmail) return true;

  // Sem e-mail na ficha, o nome exato é o único elo possível. Nunca "contém":
  // "Maria" não pode abrir a ficha de quem tem "Ana Maria Santos" como encarregada.
  const userName = normalizeText(user.name);
  if (!ficheEmail && userName && userName === normalizeText(student.guardianName)) return true;

  return false;
}

/**
 * Educandos a que esta conta de Encarregado tem acesso: vínculos ativos +
 * acesso implícito da ficha, exceto os pares explicitamente desvinculados.
 */
export function resolveGuardianChildren(
  user: GuardianIdentity,
  students: Student[],
  links: GuardianStudentLink[] = []
): GuardianChild[] {
  const active = new Map<string, GuardianStudentLink>();
  const blocked = new Set<string>();
  for (const link of links) {
    if (link.guardianUserId !== user.id) continue;
    if (link.status === 'ativo') active.set(link.studentId, link);
    else blocked.add(link.studentId);
  }

  const result: GuardianChild[] = [];
  for (const student of students) {
    const link = active.get(student.id);
    if (link) {
      result.push({ student, source: 'vinculo', link });
    } else if (!blocked.has(student.id) && isImplicitGuardianMatch(user, student)) {
      result.push({ student, source: 'ficha' });
    }
  }
  return result.sort((a, b) => a.student.name.localeCompare(b.student.name, 'pt'));
}

export interface GuardianSuggestion {
  student: Student;
  reason: string;
}

/**
 * Educandos que provavelmente pertencem a este Encarregado mas ainda não têm
 * acesso: mesmo telefone ou mesmo nome de encarregado na ficha. Nunca sugere
 * um par que a escola já desvinculou de propósito.
 */
export function suggestStudentsForGuardian(
  user: Pick<User, 'id' | 'email' | 'name' | 'phone' | 'linkedStudentId'>,
  students: Student[],
  links: GuardianStudentLink[] = []
): GuardianSuggestion[] {
  const hasAccess = new Set(resolveGuardianChildren(user, students, links).map((c) => c.student.id));
  const blocked = new Set(
    links.filter((l) => l.guardianUserId === user.id && l.status === 'desvinculado').map((l) => l.studentId)
  );
  const userPhone = phoneKey(user.phone);
  const userName = normalizeText(user.name);

  const out: GuardianSuggestion[] = [];
  for (const s of students) {
    if (hasAccess.has(s.id) || blocked.has(s.id)) continue;
    if (userPhone && phoneKey(s.guardianPhone) === userPhone) {
      out.push({ student: s, reason: 'Mesmo telefone do Encarregado na ficha' });
    } else if (userName && userName === normalizeText(s.guardianName)) {
      out.push({ student: s, reason: 'Mesmo nome de Encarregado na ficha' });
    }
  }
  return out.sort((a, b) => a.student.name.localeCompare(b.student.name, 'pt'));
}

/** Mapeia o texto livre de `guardianRelation` (ficha) para o tipo de relação. */
export function relationFromText(text?: string | null): GuardianRelation {
  const t = normalizeText(text);
  if (!t) return 'outro';
  if (/\bpai\b/.test(t)) return 'pai';
  if (/\bmae\b/.test(t)) return 'mae';
  if (/\bavo\b|\bavos\b/.test(t)) return 'avo';
  if (/\btio\b|\btia\b/.test(t)) return 'tio';
  if (/\birmao\b|\birma\b/.test(t)) return 'irmao';
  if (/padrasto|madrasta/.test(t)) return 'padrasto_madrasta';
  if (/tutor/.test(t)) return 'tutor_legal';
  return 'outro';
}

export function relationLabel(link: Pick<GuardianStudentLink, 'relation' | 'relationOther'>): string {
  if (link.relation === 'outro' && link.relationOther?.trim()) return link.relationOther.trim();
  return GUARDIAN_RELATION_LABELS[link.relation] || 'Outro';
}

/** Alunos (não transferidos) que nenhuma conta de Encarregado consegue ver. */
export function studentsWithoutGuardianAccess(
  guardians: GuardianIdentity[],
  students: Student[],
  links: GuardianStudentLink[] = []
): Student[] {
  const covered = new Set<string>();
  for (const g of guardians) {
    for (const c of resolveGuardianChildren(g, students, links)) covered.add(c.student.id);
  }
  return students
    .filter((s) => s.status !== 'transferred' && !covered.has(s.id))
    .sort((a, b) => a.name.localeCompare(b.name, 'pt'));
}
