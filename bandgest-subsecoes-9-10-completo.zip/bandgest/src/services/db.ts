import {
  User,
  Student,
  Teacher,
  ClassRoom,
  Subject,
  Course,
  AttendanceSheet,
  ExamPauta,
  TuitionInvoice,
  Notice,
  SchoolNotification,
  UserRole,
  LibraryBook,
  BookLoan,
  TimetableEntry,
  InstitutionSettings,
  SchoolServiceItem,
  SchoolAuditLog,
  SchoolCalendarEvent,
  StudentTrimesterRecord,
  InstitutionSummary,
  Funcionario,
  SchoolDepartment,
  DepartmentKind,
  Supplier,
  Matricula,
  MatriculaTipo,
  MatriculaEstado,
  MatriculaTipoAluno,
  GuardianStudentLink,
  GuardianRelation,
  GuardianUnlinkReason,
  Admission,
  AdmissionDocument,
  AdmissionStatus,
  AdmissionAssessmentType,
  ExamQuestion,
  ExamPaper,
  ExamPaperItem,
  ExamPaperType,
  QuestionStatus,
  CurriculumPlan,
  CurriculumUnit,
  ExtracurricularActivity,
  ActivityScheduleSlot,
  ActivityEnrollment,
  ActivitySession,
  ActivityAttendanceEntry,
  ActivityStatus,
  PayrollRecord,
  LeaveRequest,
  TeacherEvaluation,
  TeacherEvaluationCriterionScore,
  CanteenMenu,
  CanteenSubscription,
  CanteenServiceRecord,
  CanteenServiceEntry,
  MealType,
  Asset,
  AssetCategory,
  AssetCondition,
  AssetStatus,
  StockItem,
  StockMovement,
  SchoolVehicle,
  TransportRoute,
  TransportRouteStop,
  StockMovementType,
  StudentMedicalRecord,
  BloodType,
  MedicalAllergy,
  MedicalCondition,
  MedicalMedication,
  MedicalEmergencyContact,
  MedicalOccurrence,
  VaccinationStatus,
  DisciplinaryIncident,
  IncidentParticipant,
  IncidentCategory,
  IncidentSeverity,
  IncidentStatus,
  DisciplinaryMeasure,
  IncidentGuardianNotification,
  IncidentFollowUp,
  PickupAuthorization,
  PickupAuthorizationKind,
  PickupPersonRelation,
  PickupRecord,
  PickupReason,
  SmsWhatsappNotification,
  CommunicationChannel,
  NotificationAudienceType,
  NotificationRecipient,
  ParentTeacherMeeting,
  MeetingType,
  MeetingParticipant,
  MeetingParticipantStatus,
  GuardianChatThread,
  ChatMessage,
  ChatThreadStatus,
  DataSubjectRequest,
  DataSubjectRequestType,
  DataSubjectRequestStatus,
  AutomaticBackupSchedule,
  DataProtectionPolicy
} from '../types';
import { database } from './firebase';
import { createAccount, signIn, signOutUser, sendPasswordReset } from './auth';
import { ref, get, set, update, remove, query, orderByChild, equalTo, onValue } from 'firebase/database';
import { findTuitionRowForGrade } from '../utils/educationSubsystems';
import { calculateMT, calculateMFD, calculateCA, normalizeGradeRules } from '../utils/pautaCalculations';
import {
  generateStudentProcNumber,
  generateTeacherAgentNumber,
  generateFuncionarioNumber,
  generateSupplierCode,
  generateGuardianAutoEmail,
  generateStudentAutoEmail,
  generateTempPassword,
  generateMatriculaNumber,
  generateAssetCode,
  generateStockItemCode,
  generateVehicleCode,
  generateRouteCode,
  generateMedicalRecordCode,
  generateIncidentCode,
  generatePickupAuthorizationCode,
  generateNotificationCode,
  generateMeetingCode,
  generateChatThreadCode,
  generateDataSubjectRequestCode
} from '../utils/idGenerators';
import { getDefaultAngolaHolidays } from '../utils/academicYear';
import { defaultAutomaticBackupSchedule, computeNextRunIso, isBackupDue, describeSchedule } from '../utils/backupSchedule';
import {
  defaultDataProtectionPolicy,
  validateDataSubjectRequest,
  DataSubjectRequestFieldsInput,
  REQUEST_TYPE_LABELS,
  REQUEST_STATUS_META
} from '../utils/dataProtection';
import {
  normalizeMedicalRecordFields,
  validateMedicalRecord,
  validateIncident,
  validateMeasure,
  validatePickupAuthorization,
  isPersonForbiddenForStudent,
  INCIDENT_CATEGORY_LABELS,
  MedicalRecordFieldsInput,
  IncidentFieldsInput,
  PickupAuthorizationFieldsInput
} from '../utils/healthSafety';
import {
  CHANNEL_LABELS,
  AUDIENCE_TYPE_LABELS,
  validateNotification,
  buildRecipientsForAudience,
  NotificationFieldsInput,
  MEETING_STATUS_META,
  validateMeeting,
  MeetingFieldsInput,
  buildMeetingParticipants,
  validateChatThreadFields
} from '../utils/comunicacao';
import { relationFromText, resolveGuardianChildren } from '../utils/guardianLinks';
import {
  DECISION_STATUSES,
  ADMISSION_STATUS_META,
  admissionToStudentPayload,
  canTransition,
  computeVacancies,
  emptyDocuments,
  findDuplicateAdmission,
  findDuplicateStudent,
  generateAdmissionCode,
  validateAdmission
} from '../utils/admissions';
import {
  countQuestionUsage,
  generateExamPaperCode,
  generateQuestionCode,
  normalizeQuestionFields,
  paperTypeNeedsApproval,
  validatePaperForPublish,
  validateQuestion,
  sumPoints
} from '../utils/questionBank';
import { buildMulticaixaFields } from '../utils/multicaixa';
import {
  anyDateToIso,
  isoToDate,
  isoToPtDate,
  countSchoolWeeks,
  formatWeeksLabel,
  parseWeeksLabel,
  formatPeriodRange,
  parsePeriodRange,
  resolveActiveTrimester,
  nextAcademicYearLabel,
  defaultPeriodForAcademicYear,
  proposeTrimesterDates
} from '../utils/academicCalendar';
import {
  generatePlanCode,
  normalizePlanFields,
  normalizeUnit,
  validatePlan,
  validatePlanForApproval,
  findDuplicatePlan,
  clonePlanInput
} from '../utils/curriculum';
import {
  activeEnrollments,
  canTransitionActivity,
  checkEnrollment,
  findResourceConflicts,
  generateActivityCode,
  normalizeActivityFields,
  validateActivity,
  validateSessionDate,
  waitlist
} from '../utils/extracurriculars';
import {
  findMenu,
  findServiceRecord,
  generateSubscriptionCode,
  normalizeMenuFields,
  normalizeSubscriptionFields,
  validateMenu,
  validateServiceRecord,
  validateSubscription
} from '../utils/canteen';
import { computePayroll, getEffectivePayrollTaxSettings, listEligiblePeople } from '../utils/payroll';
import { countWorkingDays, hasOverlappingLeave, listLeaveEligiblePeople } from '../utils/leaveManagement';
import { buildDefaultCriteria, classifyScore, computeFinalScore } from '../utils/teacherEvaluation';

const STORAGE_KEY = 'bandmed_escola_db_v1';

// Initial Demo Seed Data
const defaultUsers: User[] = [];

const defaultStudents: Student[] = [];

const defaultTeachers: Teacher[] = [];

const defaultClasses: ClassRoom[] = [];

const defaultSubjects: Subject[] = [];

const defaultCourses: Course[] = [];

const defaultAttendance: AttendanceSheet = {
  id: '', date: '', formattedDate: '', classId: '', className: '',
  subjectId: '', subjectName: '', teacherId: '', teacherName: '',
  timeSlot: '', room: '', status: 'aberto', lessonSummary: '',
  isDigitallySigned: false, students: []
};

const defaultAttendanceSheets: AttendanceSheet[] = [];

const defaultPauta: ExamPauta = {
  id: '', referenceCode: '', academicYear: '', trimester: '1',
  classId: '', className: '', subjectId: '', subjectName: '',
  evaluationTitle: '', teacherName: '', teacherAgentNumber: '',
  status: 'em_lancamento', classAverage: 0, highestGrade: 0, lowestGrade: 0,
  approvalRatePercent: 0, approvedCount: 0, failedCount: 0, lastUpdated: '',
  grades: []
};

const defaultInvoices: TuitionInvoice[] = [];

const defaultNotices: Notice[] = [];

export const defaultNotifications: SchoolNotification[] = [];

const defaultBooks: LibraryBook[] = [];

const defaultLoans: BookLoan[] = [];

const defaultTimetable: TimetableEntry[] = [];

// Structural/functional defaults only — NO institution identity is hardcoded here.
// A brand-new installation must have its real name, NIF, address, logo, etc. filled in
// by the admin under Configurações > Dados da Instituição, and persisted to o Realtime Database.
function computeDefaultAcademicYear(): string {
  const now = new Date();
  const y = now.getFullYear();
  // School year in Angola runs roughly Sep–Jul, so before September we're still in "y-1/y"
  const startYear = now.getMonth() >= 8 ? y : y - 1;
  return `${startYear}/${startYear + 1}`;
}

const defaultSettings: InstitutionSettings = {
  schoolName: '',
  subTitle: '',
  nif: '',
  decreeAuthorization: '',
  province: '',
  municipality: '',
  address: '',
  email: '',
  phone: '',
  logoUrl: '',
  currentAcademicYear: computeDefaultAcademicYear(),
  availableAcademicYears: [computeDefaultAcademicYear()],
  currencyCode: 'Kz',
  currentTrimester: '1',
  selectedSubsystems: [],
  directorGeral: '',
  directorPedagogico: '',
  chefeSecretaria: '',
  website: '',
  bairro: '',
  academicPeriod: '',
  academicWeeks: '',
  trimesterSchedules: {
    t1: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' },
    t2: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' },
    t3: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' }
  }
};

export const defaultServices: SchoolServiceItem[] = [];

export const defaultAuditLogs: SchoolAuditLog[] = [];
export const defaultMatriculas: Matricula[] = [];

export const defaultEvents: SchoolCalendarEvent[] = [];

export interface SchoolDatabase {
  users: User[];
  currentUser: User;
  students: Student[];
  matriculas?: Matricula[];
  teachers: Teacher[];
  funcionarios?: Funcionario[];
  departments?: SchoolDepartment[];
  suppliers?: Supplier[];
  /** Vínculos / desvínculos Encarregado ↔ Aluno (Serviços 4). */
  guardianLinks?: GuardianStudentLink[];
  /** Candidaturas de pré-matrícula (Serviços 5). */
  admissions?: Admission[];
  /** Banco de questões (Serviços 6). */
  questions?: ExamQuestion[];
  /** Provas e exames montados a partir do banco (Serviços 6). */
  examPapers?: ExamPaper[];
  /** Planos curriculares por disciplina/classe/ano letivo (Serviços 7). */
  curriculumPlans?: CurriculumPlan[];
  /** Atividades extracurriculares e as suas inscrições/sessões (Serviços 8). */
  extracurricularActivities?: ExtracurricularActivity[];
  /** Ementas do refeitório (Serviços 9). */
  canteenMenus?: CanteenMenu[];
  /** Inscrições de alunos no refeitório (Serviços 9). */
  canteenSubscriptions?: CanteenSubscription[];
  /** Registos diários de serviço do refeitório (Serviços 9). */
  canteenServices?: CanteenServiceRecord[];
  /** Folha de Pagamento — recibos mensais gerados para docentes e funcionários (RH 1). */
  payrollRecords?: PayrollRecord[];
  /** Pedidos de Férias & Licenças de docentes e funcionários (RH 3). */
  leaveRequests?: LeaveRequest[];
  /** Avaliações de Desempenho Docente (RH 2). */
  teacherEvaluations?: TeacherEvaluation[];
  /** Inventário de Ativos (Logística 2). */
  assets?: Asset[];
  /** Itens de estoque/consumíveis (Logística 3). */
  stockItems?: StockItem[];
  /** Movimentos de entrada/saída de estoque (Logística 3). */
  stockMovements?: StockMovement[];
  /** Viaturas do transporte escolar (Logística 4). */
  vehicles?: SchoolVehicle[];
  /** Rotas do transporte escolar (Logística 4). */
  transportRoutes?: TransportRoute[];
  /** Fichas médicas dos alunos — DADO DE SAÚDE CONFIDENCIAL (Saúde & Segurança 1). */
  medicalRecords?: StudentMedicalRecord[];
  /** Incidentes disciplinares (Saúde & Segurança 2). */
  disciplinaryIncidents?: DisciplinaryIncident[];
  /** Pessoas autorizadas (ou proibidas) de recolher cada aluno (Saúde & Segurança 3). */
  pickupAuthorizations?: PickupAuthorization[];
  /** Registo de saídas/recolhas efetuadas ou recusadas (Saúde & Segurança 3). */
  pickupRecords?: PickupRecord[];
  /** Notificações em massa via SMS/WhatsApp (Comunicação 2). */
  smsWhatsappNotifications?: SmsWhatsappNotification[];
  /** Reuniões Pais-Professores agendadas (Comunicação 3). */
  parentTeacherMeetings?: ParentTeacherMeeting[];
  /** Conversas de chat entre a Escola e os Encarregados de Educação (Comunicação 4). */
  guardianChatThreads?: GuardianChatThread[];
  /** Pedidos de titulares de dados (Configurações > 10. Política de Proteção de Dados). */
  dataSubjectRequests?: DataSubjectRequest[];
  classes: ClassRoom[];
  subjects: Subject[];
  courses?: Course[];
  attendance: AttendanceSheet;
  attendanceSheets?: AttendanceSheet[];
  pauta: ExamPauta;
  invoices: TuitionInvoice[];
  services?: SchoolServiceItem[];
  notices: Notice[];
  notifications?: SchoolNotification[];
  books: LibraryBook[];
  loans: BookLoan[];
  timetable: TimetableEntry[];
  settings: InstitutionSettings;
  tuitionFees?: TuitionInvoice[];
  auditLogs?: SchoolAuditLog[];
  events?: SchoolCalendarEvent[];
  miniPautasStore?: Record<string, Record<string, any[]>>;
  /** Pautas homologadas (assinadas) — registo real, não simulado. */
  homologations?: PautaHomologation[];
  lastCloudSync?: string;
}

/** Ato de homologação de uma pauta: quem assinou, quando, e o que foi assinado. */
export interface PautaHomologation {
  id: string;
  classId: string;
  className: string;
  subjectId: string;
  subjectName: string;
  trimester: 1 | 2 | 3 | 'final';
  academicYear: string;
  signedByUserId: string;
  signedByName: string;
  signedByRole: string;
  signedAt: string;
  studentCount: number;
  approvedCount: number;
  failedCount: number;
  /** Impressão digital das notas assinadas, para detetar alterações posteriores. */
  gradesFingerprint: string;
  notes?: string;
}

export function createCleanInstitutionDb(
  institutionId: string,
  adminUser: User,
  settingsData?: Partial<InstitutionSettings>
): SchoolDatabase {
  return {
    users: [adminUser],
    currentUser: adminUser,
    students: [],
    matriculas: [],
    teachers: [],
    funcionarios: [],
    departments: [],
    suppliers: [],
    guardianLinks: [],
    admissions: [],
    questions: [],
    examPapers: [],
    curriculumPlans: [],
    extracurricularActivities: [],
    canteenMenus: [],
    canteenSubscriptions: [],
    canteenServices: [],
    payrollRecords: [],
    leaveRequests: [],
    teacherEvaluations: [],
    assets: [],
    stockItems: [],
    stockMovements: [],
    vehicles: [],
    transportRoutes: [],
    medicalRecords: [],
    disciplinaryIncidents: [],
    pickupAuthorizations: [],
    pickupRecords: [],
    smsWhatsappNotifications: [],
    parentTeacherMeetings: [],
    guardianChatThreads: [],
    dataSubjectRequests: [],
    classes: [],
    subjects: [],
    courses: [],
    attendance: {
      id: `att-init-${institutionId}`,
      date: new Date().toISOString().split('T')[0],
      formattedDate: new Date().toLocaleDateString('pt-PT'),
      classId: '',
      className: '',
      subjectId: '',
      subjectName: '',
      teacherId: adminUser.id,
      teacherName: adminUser.name,
      timeSlot: '08:00 - 09:30',
      room: '',
      status: 'aberto',
      lessonSummary: '',
      isDigitallySigned: false,
      students: []
    },
    attendanceSheets: [],
    pauta: {
      id: `pauta-init-${institutionId}`,
      referenceCode: `PAUTA-${Date.now().toString().slice(-4)}`,
      academicYear: settingsData?.currentAcademicYear || `${new Date().getFullYear()}/${new Date().getFullYear() + 1}`,
      trimester: '1',
      classId: '',
      className: '',
      subjectId: '',
      subjectName: '',
      evaluationTitle: '1.ª Avaliação Trimestral',
      teacherName: adminUser.name,
      teacherAgentNumber: '',
      status: 'em_lancamento',
      classAverage: 0,
      highestGrade: 0,
      lowestGrade: 0,
      approvalRatePercent: 0,
      approvedCount: 0,
      failedCount: 0,
      lastUpdated: new Date().toLocaleDateString('pt-PT'),
      grades: []
    },
    invoices: [],
    tuitionFees: [],
    services: [],
    notices: [],
    notifications: [],
    books: [],
    loans: [],
    timetable: [],
    miniPautasStore: {},
    homologations: [],
    events: [],
    auditLogs: [
      {
        id: `audit-${Date.now()}`,
        timestamp: new Date().toLocaleDateString('pt-PT') + ' ' + new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' }),
        userName: adminUser.name,
        userRole: 'Administrador Geral',
        action: 'Criação da Instituição',
        details: 'Instituição registada e base de dados isolada inicializada com sucesso.',
        module: 'sistema',
        createdAt: Date.now(),
        badgeColor: '#0b1f3a'
      }
    ],
    settings: {
      institutionId,
      schoolName: settingsData?.schoolName || '',
      subTitle: settingsData?.subTitle || '',
      nif: settingsData?.nif || '',
      decreeAuthorization: settingsData?.decreeAuthorization || '',
      province: settingsData?.province || '',
      municipality: settingsData?.municipality || '',
      address: settingsData?.address || '',
      email: settingsData?.email || '',
      phone: settingsData?.phone || '',
      logoUrl: settingsData?.logoUrl || '',
      currentAcademicYear: settingsData?.currentAcademicYear || `${new Date().getFullYear()}/${new Date().getFullYear() + 1}`,
      availableAcademicYears: settingsData?.availableAcademicYears && settingsData.availableAcademicYears.length > 0
        ? settingsData.availableAcademicYears
        : [settingsData?.currentAcademicYear || `${new Date().getFullYear()}/${new Date().getFullYear() + 1}`],
      currencyCode: 'Kz',
      currentTrimester: '1',
      directorGeral: settingsData?.directorGeral || '',
      directorPedagogico: settingsData?.directorPedagogico || '',
      chefeSecretaria: settingsData?.chefeSecretaria || '',
      website: settingsData?.website || '',
      bairro: settingsData?.bairro || '',
      academicPeriod: settingsData?.academicPeriod || '',
      academicWeeks: settingsData?.academicWeeks || '',
      trimesterSchedules: settingsData?.trimesterSchedules || {
        t1: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' },
        t2: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' },
        t3: { startDate: '', endDate: '', examPeriod: '', gradesCouncilDate: '', weeksCount: '' }
      },
      academicPauses: [],
      tuitionRows: [],
      emolumentos: [],
      financialRules: {
        paymentDueDay: 10,
        lateFeePercent: 10.0,
        discountPercent: 8.0,
        siblingDiscountPercent: 10.0
      },
      gradeRules: {
        macWeight: 0.3,
        ppWeight: 0.3,
        ptWeight: 0.4,
        minPassingGrade: 10,
        passingGrade: 10,
        recursoMinGrade: 7,
        examWaiverGrade: 14,
        strictDecimals: false,
        roundRuleHalfUp: true
      },
      securityPolicies: {
        twoFactorActive: false,
        sessionTimeout: '60',
        maxFailedAttempts: '5',
        passwordExpirationDays: '90'
      }
    }
  };
}

function getInitialDb(): SchoolDatabase {
  if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
    let activeInstId = localStorage.getItem('escola_active_institution_id');
    if (!activeInstId) {
      try {
        const sessionUserRaw = localStorage.getItem('bandmed_session_user');
        if (sessionUserRaw) {
          const sessionUser = JSON.parse(sessionUserRaw);
          if (sessionUser && sessionUser.institutionId) {
            activeInstId = sessionUser.institutionId;
          }
        }
      } catch {
        // ignore
      }
    }

    if (activeInstId && activeInstId !== 'inst_bandmed') {
      const savedInst = localStorage.getItem('escola_inst_' + activeInstId);
      if (savedInst) {
        try {
          const parsed = JSON.parse(savedInst);
          if (parsed && typeof parsed === 'object' && Array.isArray(parsed.users)) {
            return parsed;
          }
        } catch {
          // ignore and fallback
        }
      }
    }
  }

  // Clean, empty database. Nothing here is seeded/fake — every collection starts
  // empty and is populated exclusively through real writes to Realtime Database.
  let base: any = {
    users: [] as User[],
    currentUser: null,
    students: defaultStudents,
    matriculas: defaultMatriculas,
    teachers: defaultTeachers,
    departments: [],
    suppliers: [],
    guardianLinks: [],
    admissions: [],
    questions: [],
    examPapers: [],
    curriculumPlans: [],
    extracurricularActivities: [],
    canteenMenus: [],
    canteenSubscriptions: [],
    canteenServices: [],
    payrollRecords: [],
    leaveRequests: [],
    teacherEvaluations: [],
    assets: [],
    stockItems: [],
    stockMovements: [],
    vehicles: [],
    transportRoutes: [],
    medicalRecords: [],
    disciplinaryIncidents: [],
    pickupAuthorizations: [],
    pickupRecords: [],
    smsWhatsappNotifications: [],
    parentTeacherMeetings: [],
    guardianChatThreads: [],
    dataSubjectRequests: [],
    classes: defaultClasses,
    subjects: defaultSubjects,
    courses: defaultCourses,
    attendance: defaultAttendance,
    attendanceSheets: defaultAttendanceSheets,
    pauta: defaultPauta,
    invoices: defaultInvoices,
    services: defaultServices,
    notices: defaultNotices,
    notifications: defaultNotifications,
    books: defaultBooks,
    loans: defaultLoans,
    timetable: defaultTimetable,
    settings: defaultSettings,
    auditLogs: defaultAuditLogs,
    events: defaultEvents,
    miniPautasStore: {}
  };

  // Rehydrate ONLY what this browser genuinely persisted from a real session
  // (this cache is a local mirror of Realtime Database, never a source of seed data).
  try {
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        base = {
          ...base,
          ...parsed,
          users: Array.isArray(parsed.users) ? parsed.users : base.users,
          students: Array.isArray(parsed.students) ? parsed.students : base.students,
          matriculas: Array.isArray(parsed.matriculas) ? parsed.matriculas : base.matriculas,
          teachers: Array.isArray(parsed.teachers) ? parsed.teachers : base.teachers,
          departments: Array.isArray(parsed.departments) ? parsed.departments : base.departments,
          suppliers: Array.isArray(parsed.suppliers) ? parsed.suppliers : base.suppliers,
          guardianLinks: Array.isArray(parsed.guardianLinks) ? parsed.guardianLinks : base.guardianLinks,
          admissions: Array.isArray(parsed.admissions) ? parsed.admissions : base.admissions,
          questions: Array.isArray(parsed.questions) ? parsed.questions : base.questions,
          examPapers: Array.isArray(parsed.examPapers) ? parsed.examPapers : base.examPapers,
          curriculumPlans: Array.isArray(parsed.curriculumPlans) ? parsed.curriculumPlans : base.curriculumPlans,
          extracurricularActivities: Array.isArray(parsed.extracurricularActivities)
            ? parsed.extracurricularActivities
            : base.extracurricularActivities,
          canteenMenus: Array.isArray(parsed.canteenMenus) ? parsed.canteenMenus : base.canteenMenus,
          canteenSubscriptions: Array.isArray(parsed.canteenSubscriptions) ? parsed.canteenSubscriptions : base.canteenSubscriptions,
          canteenServices: Array.isArray(parsed.canteenServices) ? parsed.canteenServices : base.canteenServices,
          payrollRecords: Array.isArray(parsed.payrollRecords) ? parsed.payrollRecords : base.payrollRecords,
          leaveRequests: Array.isArray(parsed.leaveRequests) ? parsed.leaveRequests : base.leaveRequests,
          teacherEvaluations: Array.isArray(parsed.teacherEvaluations) ? parsed.teacherEvaluations : base.teacherEvaluations,
          assets: Array.isArray(parsed.assets) ? parsed.assets : base.assets,
          stockItems: Array.isArray(parsed.stockItems) ? parsed.stockItems : base.stockItems,
          stockMovements: Array.isArray(parsed.stockMovements) ? parsed.stockMovements : base.stockMovements,
          vehicles: Array.isArray(parsed.vehicles) ? parsed.vehicles : base.vehicles,
          transportRoutes: Array.isArray(parsed.transportRoutes) ? parsed.transportRoutes : base.transportRoutes,
          medicalRecords: Array.isArray(parsed.medicalRecords) ? parsed.medicalRecords : base.medicalRecords,
          disciplinaryIncidents: Array.isArray(parsed.disciplinaryIncidents) ? parsed.disciplinaryIncidents : base.disciplinaryIncidents,
          pickupAuthorizations: Array.isArray(parsed.pickupAuthorizations) ? parsed.pickupAuthorizations : base.pickupAuthorizations,
          pickupRecords: Array.isArray(parsed.pickupRecords) ? parsed.pickupRecords : base.pickupRecords,
          smsWhatsappNotifications: Array.isArray(parsed.smsWhatsappNotifications) ? parsed.smsWhatsappNotifications : base.smsWhatsappNotifications,
          parentTeacherMeetings: Array.isArray(parsed.parentTeacherMeetings) ? parsed.parentTeacherMeetings : base.parentTeacherMeetings,
          guardianChatThreads: Array.isArray(parsed.guardianChatThreads) ? parsed.guardianChatThreads : base.guardianChatThreads,
          dataSubjectRequests: Array.isArray(parsed.dataSubjectRequests) ? parsed.dataSubjectRequests : base.dataSubjectRequests,
          classes: Array.isArray(parsed.classes) ? parsed.classes : base.classes,
          subjects: Array.isArray(parsed.subjects) ? parsed.subjects : base.subjects,
          courses: Array.isArray(parsed.courses) ? parsed.courses : base.courses,
          invoices: Array.isArray(parsed.invoices) ? parsed.invoices : base.invoices,
          attendance: parsed.attendance || base.attendance,
          attendanceSheets: Array.isArray(parsed.attendanceSheets) ? parsed.attendanceSheets : base.attendanceSheets,
          books: Array.isArray(parsed.books) ? parsed.books : base.books,
          services: Array.isArray(parsed.services) ? parsed.services : base.services,
          notices: Array.isArray(parsed.notices) ? parsed.notices : base.notices,
          notifications: Array.isArray(parsed.notifications) ? parsed.notifications : base.notifications,
          auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : base.auditLogs,
          events: Array.isArray(parsed.events) ? parsed.events : base.events,
          miniPautasStore: parsed.miniPautasStore || {},
          settings: { ...defaultSettings, ...(parsed.settings || {}) }
        };
      }
    }
  } catch (e) {
    console.error('Error loading db from localStorage', e);
  }

  base.tuitionFees = base.invoices;
  return base as SchoolDatabase;
}

const IDB_NAME = 'bandmed_school_db';
const IDB_STORE = 'school_database';
const IDB_VERSION = 1;

class SchoolIndexedDB {
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  private getDB(): Promise<IDBDatabase | null> {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return Promise.resolve(null);
    }
    if (!this.dbPromise) {
      this.dbPromise = new Promise((resolve) => {
        try {
          const req = window.indexedDB.open(IDB_NAME, IDB_VERSION);
          req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(IDB_STORE)) {
              db.createObjectStore(IDB_STORE);
            }
          };
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => {
            resolve(null);
          };
        } catch {
          resolve(null);
        }
      });
    }
    return this.dbPromise;
  }

  public async save(data: SchoolDatabase, instId?: string): Promise<boolean> {
    const db = await this.getDB();
    if (!db) return false;
    const storeKey = instId ? `inst_${instId}` : (data.settings?.institutionId ? `inst_${data.settings.institutionId}` : 'current_db');
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(IDB_STORE, 'readwrite');
        const store = tx.objectStore(IDB_STORE);
        store.put(data, storeKey);
        store.put(data, 'current_db');
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch {
        resolve(false);
      }
    });
  }

  public async load(instId?: string): Promise<SchoolDatabase | null> {
    const db = await this.getDB();
    if (!db) return null;
    const storeKey = instId ? (instId.startsWith('inst_') ? instId : `inst_${instId}`) : 'current_db';
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(IDB_STORE, 'readonly');
        const store = tx.objectStore(IDB_STORE);
        const req = store.get(storeKey);
        req.onsuccess = () => {
          if (req.result) {
            resolve(req.result);
          } else if (storeKey !== 'current_db') {
            const fallbackReq = store.get('current_db');
            fallbackReq.onsuccess = () => resolve(fallbackReq.result || null);
            fallbackReq.onerror = () => resolve(null);
          } else {
            resolve(null);
          }
        };
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }

  public async clear(): Promise<void> {
    const db = await this.getDB();
    if (!db) return;
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).clear();
    } catch (e) {
      console.warn(e);
    }
  }
}

export const idbService = new SchoolIndexedDB();

/**
 * Remove recursivamente todas as propriedades com valor `undefined` de um payload antes
 * de o escrever no Firebase Realtime Database, que rejeita a operação completa (lançando
 * "contains undefined in property...") se encontrar uma única. Arrays são preservados;
 * elementos `undefined` dentro de arrays são convertidos em `null` para não alterar índices.
 */
function stripUndefinedDeep<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => (item === undefined ? null : stripUndefinedDeep(item))) as unknown as T;
  }
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    Object.entries(value as Record<string, unknown>).forEach(([key, val]) => {
      if (val === undefined) return;
      out[key] = stripUndefinedDeep(val);
    });
    return out as unknown as T;
  }
  return value;
}

/**
 * Strips heavy dataUrls from attachments for localStorage to guarantee never exceeding browser 5MB quota.
 * Full dataUrls remain safely preserved in IndexedDB and in-memory application state.
 */
function prepareSafeLocalStorageSnapshot(db: SchoolDatabase): string {
  const sanitizeStudent = (st: Student): Student => ({
    ...st,
    docPassPhoto: (st.docPassPhoto && st.docPassPhoto.length > 20000) ? '' : st.docPassPhoto,
    docBiFile: st.docBiFile
      ? { ...st.docBiFile, dataUrl: (st.docBiFile.dataUrl && st.docBiFile.dataUrl.length > 20000) ? '' : st.docBiFile.dataUrl }
      : null,
    docCertificateFile: st.docCertificateFile
      ? { ...st.docCertificateFile, dataUrl: (st.docCertificateFile.dataUrl && st.docCertificateFile.dataUrl.length > 20000) ? '' : st.docCertificateFile.dataUrl }
      : null,
    additionalDocs: (st.additionalDocs || []).map((doc) => ({
      ...doc,
      dataUrl: (doc.dataUrl && doc.dataUrl.length > 20000) ? '' : doc.dataUrl
    }))
  });

  const sanitizeTeacher = (t: Teacher): Teacher => ({
    ...t,
    avatar: (t.avatar && t.avatar.length > 20000) ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150' : t.avatar
  });

  const safeDb: SchoolDatabase = {
    ...db,
    students: (db.students || []).map(sanitizeStudent),
    teachers: (db.teachers || []).map(sanitizeTeacher),
    funcionarios: db.funcionarios || [],
    departments: db.departments || [],
    suppliers: db.suppliers || [],
    guardianLinks: db.guardianLinks || [],
    admissions: db.admissions || [],
    questions: db.questions || [],
    examPapers: db.examPapers || [],
    curriculumPlans: db.curriculumPlans || [],
    extracurricularActivities: db.extracurricularActivities || [],
    canteenMenus: (db.canteenMenus || []).map((m) => ({ ...m, allergens: m.allergens || [] })),
    canteenSubscriptions: (db.canteenSubscriptions || []).map((s) => ({ ...s, allergies: s.allergies || [] })),
    canteenServices: db.canteenServices || [],
    payrollRecords: db.payrollRecords || [],
    leaveRequests: db.leaveRequests || [],
    teacherEvaluations: db.teacherEvaluations || [],
    assets: db.assets || [],
    stockItems: db.stockItems || [],
    stockMovements: db.stockMovements || [],
    vehicles: db.vehicles || [],
    transportRoutes: db.transportRoutes || [],
    medicalRecords: db.medicalRecords || [],
    disciplinaryIncidents: db.disciplinaryIncidents || [],
    pickupAuthorizations: db.pickupAuthorizations || [],
    pickupRecords: db.pickupRecords || [],
    smsWhatsappNotifications: db.smsWhatsappNotifications || [],
    parentTeacherMeetings: db.parentTeacherMeetings || [],
    guardianChatThreads: db.guardianChatThreads || [],
    dataSubjectRequests: db.dataSubjectRequests || [],
  };

  return JSON.stringify(safeDb);
}

export class SchoolDatabaseService {
  private db: SchoolDatabase;
  private listeners: Set<(db: SchoolDatabase) => void> = new Set();
  private syncStatusListeners: Set<(status: 'synced' | 'syncing' | 'offline' | 'error') => void> = new Set();
  private syncStatus: 'synced' | 'syncing' | 'offline' | 'error' = 'synced';
  private syncTimer: any = null;
  private lastSyncedTimestamp: string = '';
  public activeInstitutionId: string = 'inst_bandmed';
  private unsubscribeRealtime: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      const active = localStorage.getItem('escola_active_institution_id');
      if (active) {
        this.activeInstitutionId = active;
      } else {
        try {
          const sessionUserRaw = localStorage.getItem('bandmed_session_user');
          if (sessionUserRaw) {
            const sessionUser = JSON.parse(sessionUserRaw);
            if (sessionUser && sessionUser.institutionId) {
              this.activeInstitutionId = sessionUser.institutionId;
            }
          }
        } catch {
          // ignore
        }
      }
    }
    this.db = getInitialDb();
    // Hydrate any rich offline data from IndexedDB
    this.initFromIndexedDb();
    // Automatically initialize institutional cloud synchronization
    this.initRemoteSync();
  }

  private async initFromIndexedDb(): Promise<void> {
    try {
      const stored = await idbService.load(this.activeInstitutionId);
      if (stored) {
        const storedInstId = stored.settings?.institutionId || 'inst_bandmed';
        // Only hydrate if the stored database matches the currently active institution
        if (storedInstId === this.activeInstitutionId) {
          this.db = {
            ...this.db,
            ...stored,
            // Guard: never wipe out new admin users or created accounts with stale IndexedDB users
            users: (this.db.users && this.db.users.length > 0) ? this.db.users : (stored.users || this.db.users),
            students: (stored.students && stored.students.length > 0) ? stored.students : this.db.students,
            matriculas: (stored.matriculas && stored.matriculas.length > 0) ? stored.matriculas : this.db.matriculas,
            teachers: (stored.teachers && stored.teachers.length > 0) ? stored.teachers : this.db.teachers,
            funcionarios: (stored.funcionarios && stored.funcionarios.length > 0) ? stored.funcionarios : this.db.funcionarios,
            departments: (stored.departments && stored.departments.length > 0) ? stored.departments : this.db.departments,
            suppliers: (stored.suppliers && stored.suppliers.length > 0) ? stored.suppliers : this.db.suppliers,
            guardianLinks: (stored.guardianLinks && stored.guardianLinks.length > 0) ? stored.guardianLinks : this.db.guardianLinks,
            admissions: (stored.admissions && stored.admissions.length > 0) ? stored.admissions : this.db.admissions,
            questions: (stored.questions && stored.questions.length > 0) ? stored.questions : this.db.questions,
            examPapers: (stored.examPapers && stored.examPapers.length > 0) ? stored.examPapers : this.db.examPapers,
            curriculumPlans: (stored.curriculumPlans && stored.curriculumPlans.length > 0) ? stored.curriculumPlans : this.db.curriculumPlans,
            extracurricularActivities:
              (stored.extracurricularActivities && stored.extracurricularActivities.length > 0)
                ? stored.extracurricularActivities
                : this.db.extracurricularActivities,
            canteenMenus: (stored.canteenMenus && stored.canteenMenus.length > 0) ? stored.canteenMenus : this.db.canteenMenus,
            canteenSubscriptions:
              (stored.canteenSubscriptions && stored.canteenSubscriptions.length > 0) ? stored.canteenSubscriptions : this.db.canteenSubscriptions,
            canteenServices: (stored.canteenServices && stored.canteenServices.length > 0) ? stored.canteenServices : this.db.canteenServices,
            payrollRecords: (stored.payrollRecords && stored.payrollRecords.length > 0) ? stored.payrollRecords : this.db.payrollRecords,
            leaveRequests: (stored.leaveRequests && stored.leaveRequests.length > 0) ? stored.leaveRequests : this.db.leaveRequests,
            teacherEvaluations: (stored.teacherEvaluations && stored.teacherEvaluations.length > 0) ? stored.teacherEvaluations : this.db.teacherEvaluations,
            assets: (stored.assets && stored.assets.length > 0) ? stored.assets : this.db.assets,
            stockItems: (stored.stockItems && stored.stockItems.length > 0) ? stored.stockItems : this.db.stockItems,
            stockMovements: (stored.stockMovements && stored.stockMovements.length > 0) ? stored.stockMovements : this.db.stockMovements,
            vehicles: (stored.vehicles && stored.vehicles.length > 0) ? stored.vehicles : this.db.vehicles,
            transportRoutes: (stored.transportRoutes && stored.transportRoutes.length > 0) ? stored.transportRoutes : this.db.transportRoutes,
            medicalRecords: (stored.medicalRecords && stored.medicalRecords.length > 0) ? stored.medicalRecords : this.db.medicalRecords,
            disciplinaryIncidents: (stored.disciplinaryIncidents && stored.disciplinaryIncidents.length > 0) ? stored.disciplinaryIncidents : this.db.disciplinaryIncidents,
            pickupAuthorizations: (stored.pickupAuthorizations && stored.pickupAuthorizations.length > 0) ? stored.pickupAuthorizations : this.db.pickupAuthorizations,
            pickupRecords: (stored.pickupRecords && stored.pickupRecords.length > 0) ? stored.pickupRecords : this.db.pickupRecords,
            smsWhatsappNotifications: (stored.smsWhatsappNotifications && stored.smsWhatsappNotifications.length > 0) ? stored.smsWhatsappNotifications : this.db.smsWhatsappNotifications,
            parentTeacherMeetings: (stored.parentTeacherMeetings && stored.parentTeacherMeetings.length > 0) ? stored.parentTeacherMeetings : this.db.parentTeacherMeetings,
            guardianChatThreads: (stored.guardianChatThreads && stored.guardianChatThreads.length > 0) ? stored.guardianChatThreads : this.db.guardianChatThreads,
            dataSubjectRequests: (stored.dataSubjectRequests && stored.dataSubjectRequests.length > 0) ? stored.dataSubjectRequests : this.db.dataSubjectRequests,
            attendanceSheets: stored.attendanceSheets || this.db.attendanceSheets,
            invoices: stored.invoices || this.db.invoices
          };
          const currentData = this.getDatabase();
          this.listeners.forEach((listener) => listener(currentData));
        }
      }
    } catch (e) {
      console.warn('Could not hydrate from IndexedDB:', e);
    }
  }

  public getSnapshot(): SchoolDatabase {
    return {
      ...this.db,
      attendance: this.db.attendance,
      attendanceSheets: this.db.attendanceSheets || [],
      invoices: this.db.invoices || [],
      tuitionFees: this.db.invoices || [],
      books: this.db.books || [],
      students: this.db.students || [],
      matriculas: this.db.matriculas || [],
      teachers: this.db.teachers || [],
      funcionarios: this.db.funcionarios || [],
      departments: this.db.departments || [],
      suppliers: this.db.suppliers || [],
      guardianLinks: this.db.guardianLinks || [],
      admissions: this.db.admissions || [],
      questions: this.db.questions || [],
      examPapers: this.db.examPapers || [],
      curriculumPlans: this.db.curriculumPlans || [],
      extracurricularActivities: this.db.extracurricularActivities || [],
      canteenMenus: (this.db.canteenMenus || []).map((m) => ({ ...m, allergens: m.allergens || [] })),
      // uma inscrição sem alergias/refeições/dias perderia esses campos ao voltar da nuvem.
      canteenSubscriptions: (this.db.canteenSubscriptions || []).map((s) => ({
        ...s,
        meals: s.meals || [],
        weekdays: s.weekdays || [],
        allergies: s.allergies || []
      })),
      canteenServices: this.db.canteenServices || [],
      payrollRecords: this.db.payrollRecords || [],
      leaveRequests: this.db.leaveRequests || [],
      teacherEvaluations: this.db.teacherEvaluations || [],
      assets: this.db.assets || [],
      stockItems: this.db.stockItems || [],
      stockMovements: this.db.stockMovements || [],
      vehicles: this.db.vehicles || [],
      transportRoutes: this.db.transportRoutes || [],
      medicalRecords: this.db.medicalRecords || [],
      disciplinaryIncidents: this.db.disciplinaryIncidents || [],
      pickupAuthorizations: this.db.pickupAuthorizations || [],
      pickupRecords: this.db.pickupRecords || [],
      smsWhatsappNotifications: this.db.smsWhatsappNotifications || [],
      parentTeacherMeetings: this.db.parentTeacherMeetings || [],
      guardianChatThreads: this.db.guardianChatThreads || [],
      dataSubjectRequests: this.db.dataSubjectRequests || [],
      classes: this.db.classes || [],
      courses: Array.isArray(this.db.courses) ? this.db.courses : [],
      subjects: Array.isArray(this.db.subjects) ? this.db.subjects : [],
      notices: this.db.notices || [],
      notifications: Array.isArray(this.db.notifications) ? this.db.notifications : [],
      auditLogs: Array.isArray(this.db.auditLogs) ? this.db.auditLogs : [],
      events: Array.isArray(this.db.events) ? this.db.events : [],
      miniPautasStore: this.db.miniPautasStore || {}
    };
  }

  public getDatabase(): SchoolDatabase {
    return this.getSnapshot();
  }

  public getDb(): SchoolDatabase {
    return this.getSnapshot();
  }

  public getSettings(): InstitutionSettings {
    return this.db.settings || defaultSettings;
  }

  public getSyncStatus(): 'synced' | 'syncing' | 'offline' | 'error' {
    return this.syncStatus;
  }

  public subscribeSyncStatus(listener: (status: 'synced' | 'syncing' | 'offline' | 'error') => void): () => void {
    this.syncStatusListeners.add(listener);
    listener(this.syncStatus);
    return () => {
      this.syncStatusListeners.delete(listener);
    };
  }

  private setSyncStatus(status: 'synced' | 'syncing' | 'offline' | 'error') {
    this.syncStatus = status;
    this.syncStatusListeners.forEach((fn) => fn(status));
  }

  public async initRemoteSync(): Promise<void> {
    try {
      this.setSyncStatus('syncing');
      const docRef = this.activeInstitutionId === 'inst_bandmed'
        ? ref(database, 'school_data/bandmed_main')
        : ref(database, 'institutions/' + this.activeInstitutionId);

      const hasLocalDb =
        typeof window !== 'undefined' &&
        typeof localStorage !== 'undefined' &&
        (localStorage.getItem('escola_inst_' + this.activeInstitutionId) !== null || (this.activeInstitutionId === 'inst_bandmed' && localStorage.getItem(STORAGE_KEY) !== null));

      // Add a non-blocking timeout protection to avoid hanging if the client is temporarily offline
      const docSnapPromise = get(docRef);
      const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3500));
      const docSnap = await Promise.race([docSnapPromise, timeoutPromise]);

      if (docSnap && docSnap.exists()) {
        const remote = docSnap.val() as any;
        if (remote) {
          if (!hasLocalDb || (remote.lastCloudSync && remote.lastCloudSync > (this.db.lastCloudSync || ''))) {
            this.db = {
              ...this.db,
              ...remote,
              users: Array.isArray(remote.users) && remote.users.length > 0 ? remote.users : this.db.users,
              students: Array.isArray(remote.students) ? remote.students : this.db.students,
              matriculas: Array.isArray(remote.matriculas) ? remote.matriculas : this.db.matriculas,
              teachers: Array.isArray(remote.teachers) ? remote.teachers : this.db.teachers,
              funcionarios: Array.isArray(remote.funcionarios) ? remote.funcionarios : this.db.funcionarios,
              departments: Array.isArray(remote.departments) ? remote.departments : this.db.departments,
              suppliers: Array.isArray(remote.suppliers) ? remote.suppliers : this.db.suppliers,
              guardianLinks: Array.isArray(remote.guardianLinks) ? remote.guardianLinks : this.db.guardianLinks,
              admissions: Array.isArray(remote.admissions) ? remote.admissions : this.db.admissions,
              questions: Array.isArray(remote.questions) ? remote.questions : this.db.questions,
              examPapers: Array.isArray(remote.examPapers) ? remote.examPapers : this.db.examPapers,
              curriculumPlans: Array.isArray(remote.curriculumPlans) ? remote.curriculumPlans : this.db.curriculumPlans,
              extracurricularActivities: Array.isArray(remote.extracurricularActivities)
                ? remote.extracurricularActivities
                : this.db.extracurricularActivities,
              canteenMenus: Array.isArray(remote.canteenMenus) ? remote.canteenMenus : this.db.canteenMenus,
              canteenSubscriptions: Array.isArray(remote.canteenSubscriptions) ? remote.canteenSubscriptions : this.db.canteenSubscriptions,
              canteenServices: Array.isArray(remote.canteenServices) ? remote.canteenServices : this.db.canteenServices,
              payrollRecords: Array.isArray(remote.payrollRecords) ? remote.payrollRecords : this.db.payrollRecords,
              leaveRequests: Array.isArray(remote.leaveRequests) ? remote.leaveRequests : this.db.leaveRequests,
              teacherEvaluations: Array.isArray(remote.teacherEvaluations) ? remote.teacherEvaluations : this.db.teacherEvaluations,
              assets: Array.isArray(remote.assets) ? remote.assets : this.db.assets,
              stockItems: Array.isArray(remote.stockItems) ? remote.stockItems : this.db.stockItems,
              stockMovements: Array.isArray(remote.stockMovements) ? remote.stockMovements : this.db.stockMovements,
              vehicles: Array.isArray(remote.vehicles) ? remote.vehicles : this.db.vehicles,
              transportRoutes: Array.isArray(remote.transportRoutes) ? remote.transportRoutes : this.db.transportRoutes,
              medicalRecords: Array.isArray(remote.medicalRecords) ? remote.medicalRecords : this.db.medicalRecords,
              disciplinaryIncidents: Array.isArray(remote.disciplinaryIncidents) ? remote.disciplinaryIncidents : this.db.disciplinaryIncidents,
              pickupAuthorizations: Array.isArray(remote.pickupAuthorizations) ? remote.pickupAuthorizations : this.db.pickupAuthorizations,
              pickupRecords: Array.isArray(remote.pickupRecords) ? remote.pickupRecords : this.db.pickupRecords,
              smsWhatsappNotifications: Array.isArray(remote.smsWhatsappNotifications) ? remote.smsWhatsappNotifications : this.db.smsWhatsappNotifications,
              parentTeacherMeetings: Array.isArray(remote.parentTeacherMeetings) ? remote.parentTeacherMeetings : this.db.parentTeacherMeetings,
              guardianChatThreads: Array.isArray(remote.guardianChatThreads) ? remote.guardianChatThreads : this.db.guardianChatThreads,
              dataSubjectRequests: Array.isArray(remote.dataSubjectRequests) ? remote.dataSubjectRequests : this.db.dataSubjectRequests,
              classes: Array.isArray(remote.classes) ? remote.classes : this.db.classes,
              courses: Array.isArray(remote.courses) ? remote.courses : this.db.courses,
              subjects: Array.isArray(remote.subjects) ? remote.subjects : this.db.subjects,
              timetable: remote.timetable || this.db.timetable,
              services: remote.services || this.db.services,
              invoices: remote.invoices || remote.tuitionFees || this.db.invoices,
              tuitionFees: remote.invoices || remote.tuitionFees || this.db.invoices,
              notices: remote.notices || this.db.notices,
              notifications: Array.isArray(remote.notifications) ? remote.notifications : this.db.notifications,
              auditLogs: Array.isArray(remote.auditLogs) ? remote.auditLogs : this.db.auditLogs,
              events: Array.isArray(remote.events) ? remote.events : this.db.events,
              miniPautasStore: remote.miniPautasStore || this.db.miniPautasStore || {},
              settings: { ...this.db.settings, ...(remote.settings || {}) }
            };
            this.lastSyncedTimestamp = remote.lastCloudSync || '';
            this.setSyncStatus('synced');
            this.notifyLocal();
          } else {
            await this.pushToCloudStorage();
          }
        }
      } else if (!hasLocalDb) {
        await this.pushToCloudStorage();
      }

      if (this.unsubscribeRealtime) {
        this.unsubscribeRealtime();
        this.unsubscribeRealtime = null;
      }

      // Setup real-time listener for Realtime Database changes across active clients
      this.unsubscribeRealtime = onValue(docRef, (snapshot) => {
        if (snapshot.exists()) {
          const remote = snapshot.val() as any;
          if (remote && remote.lastCloudSync && remote.lastCloudSync !== this.lastSyncedTimestamp) {
            this.lastSyncedTimestamp = remote.lastCloudSync;
            this.db = {
              ...this.db,
              ...remote,
              users: Array.isArray(remote.users) && remote.users.length > 0 ? remote.users : this.db.users,
              students: Array.isArray(remote.students) ? remote.students : this.db.students,
              matriculas: Array.isArray(remote.matriculas) ? remote.matriculas : this.db.matriculas,
              teachers: Array.isArray(remote.teachers) ? remote.teachers : this.db.teachers,
              funcionarios: Array.isArray(remote.funcionarios) ? remote.funcionarios : this.db.funcionarios,
              departments: Array.isArray(remote.departments) ? remote.departments : this.db.departments,
              suppliers: Array.isArray(remote.suppliers) ? remote.suppliers : this.db.suppliers,
              guardianLinks: Array.isArray(remote.guardianLinks) ? remote.guardianLinks : this.db.guardianLinks,
              admissions: Array.isArray(remote.admissions) ? remote.admissions : this.db.admissions,
              questions: Array.isArray(remote.questions) ? remote.questions : this.db.questions,
              examPapers: Array.isArray(remote.examPapers) ? remote.examPapers : this.db.examPapers,
              curriculumPlans: Array.isArray(remote.curriculumPlans) ? remote.curriculumPlans : this.db.curriculumPlans,
              extracurricularActivities: Array.isArray(remote.extracurricularActivities)
                ? remote.extracurricularActivities
                : this.db.extracurricularActivities,
              canteenMenus: Array.isArray(remote.canteenMenus) ? remote.canteenMenus : this.db.canteenMenus,
              canteenSubscriptions: Array.isArray(remote.canteenSubscriptions) ? remote.canteenSubscriptions : this.db.canteenSubscriptions,
              canteenServices: Array.isArray(remote.canteenServices) ? remote.canteenServices : this.db.canteenServices,
              payrollRecords: Array.isArray(remote.payrollRecords) ? remote.payrollRecords : this.db.payrollRecords,
              leaveRequests: Array.isArray(remote.leaveRequests) ? remote.leaveRequests : this.db.leaveRequests,
              teacherEvaluations: Array.isArray(remote.teacherEvaluations) ? remote.teacherEvaluations : this.db.teacherEvaluations,
              assets: Array.isArray(remote.assets) ? remote.assets : this.db.assets,
              stockItems: Array.isArray(remote.stockItems) ? remote.stockItems : this.db.stockItems,
              stockMovements: Array.isArray(remote.stockMovements) ? remote.stockMovements : this.db.stockMovements,
              vehicles: Array.isArray(remote.vehicles) ? remote.vehicles : this.db.vehicles,
              transportRoutes: Array.isArray(remote.transportRoutes) ? remote.transportRoutes : this.db.transportRoutes,
              medicalRecords: Array.isArray(remote.medicalRecords) ? remote.medicalRecords : this.db.medicalRecords,
              disciplinaryIncidents: Array.isArray(remote.disciplinaryIncidents) ? remote.disciplinaryIncidents : this.db.disciplinaryIncidents,
              pickupAuthorizations: Array.isArray(remote.pickupAuthorizations) ? remote.pickupAuthorizations : this.db.pickupAuthorizations,
              pickupRecords: Array.isArray(remote.pickupRecords) ? remote.pickupRecords : this.db.pickupRecords,
              smsWhatsappNotifications: Array.isArray(remote.smsWhatsappNotifications) ? remote.smsWhatsappNotifications : this.db.smsWhatsappNotifications,
              parentTeacherMeetings: Array.isArray(remote.parentTeacherMeetings) ? remote.parentTeacherMeetings : this.db.parentTeacherMeetings,
              guardianChatThreads: Array.isArray(remote.guardianChatThreads) ? remote.guardianChatThreads : this.db.guardianChatThreads,
              dataSubjectRequests: Array.isArray(remote.dataSubjectRequests) ? remote.dataSubjectRequests : this.db.dataSubjectRequests,
              classes: Array.isArray(remote.classes) ? remote.classes : this.db.classes,
              courses: Array.isArray(remote.courses) ? remote.courses : this.db.courses,
              subjects: Array.isArray(remote.subjects) ? remote.subjects : this.db.subjects,
              timetable: remote.timetable || this.db.timetable,
              services: remote.services || this.db.services,
              invoices: remote.invoices || remote.tuitionFees || this.db.invoices,
              tuitionFees: remote.invoices || remote.tuitionFees || this.db.invoices,
              notices: remote.notices || this.db.notices,
              notifications: Array.isArray(remote.notifications) ? remote.notifications : this.db.notifications,
              auditLogs: Array.isArray(remote.auditLogs) ? remote.auditLogs : this.db.auditLogs,
              events: Array.isArray(remote.events) ? remote.events : this.db.events,
              miniPautasStore: remote.miniPautasStore || this.db.miniPautasStore || {},
              settings: { ...this.db.settings, ...(remote.settings || {}) }
            };
            this.setSyncStatus('synced');
            this.notifyLocal();
          }
        }
      }, (error) => {
        console.warn('Realtime Database listener:', error);
      });

    } catch (e) {
      console.warn('Conexão Firebase Realtime Database em modo offline:', e);
      this.setSyncStatus('offline');
    }
  }

  public async saveUserToCloud(user: User): Promise<void> {
    try {
      const cleanEmail = user.email.trim().toLowerCase();
      // NEVER persist a password to Realtime Database — Firebase Authentication is the
      // only place credentials live. `user.id` is expected to be the Firebase Auth UID.
      const { password: _omitPassword, ...userWithoutPassword } = user as any;
      const userData: User = {
        ...userWithoutPassword,
        email: cleanEmail,
        institutionId: user.institutionId || this.activeInstitutionId
      };

      if (user.id) {
        await update(ref(database, 'users/' + user.id), stripUndefinedDeep(userData));
      }
    } catch (e) {
      console.warn('Erro ao salvar utilizador no Realtime Database ("users"):', e);
    }
  }

  public async pushToCloudStorage(): Promise<boolean> {
    try {
      this.setSyncStatus('syncing');
      const timestamp = new Date().toISOString();
      this.lastSyncedTimestamp = timestamp;

      // Sanitize heavy attachments so Realtime Database document stays well within quota
      const sanitizedStudents = (this.db.students || []).map((st) => ({
        ...st,
        docPassPhoto: (st.docPassPhoto && st.docPassPhoto.length > 30000) ? '' : st.docPassPhoto,
        docBiFile: st.docBiFile ? { ...st.docBiFile, dataUrl: (st.docBiFile.dataUrl && st.docBiFile.dataUrl.length > 30000) ? '' : st.docBiFile.dataUrl } : null,
        docCertificateFile: st.docCertificateFile ? { ...st.docCertificateFile, dataUrl: (st.docCertificateFile.dataUrl && st.docCertificateFile.dataUrl.length > 30000) ? '' : st.docCertificateFile.dataUrl } : null,
        additionalDocs: (st.additionalDocs || []).map((doc) => ({
          ...doc,
          dataUrl: (doc.dataUrl && doc.dataUrl.length > 30000) ? '' : doc.dataUrl
        }))
      }));

      const payload = {
        users: (this.db.users || []).map(({ password: _pw, ...u }: any) => u),
        students: sanitizedStudents,
        // `matriculas` nunca era enviada: ficava só no navegador de quem matriculava
        // e desaparecia noutros dispositivos / após limpar a cache.
        matriculas: this.db.matriculas || [],
        teachers: this.db.teachers || [],
        funcionarios: this.db.funcionarios || [],
        departments: this.db.departments || [],
        suppliers: this.db.suppliers || [],
        guardianLinks: this.db.guardianLinks || [],
        admissions: this.db.admissions || [],
        questions: this.db.questions || [],
        examPapers: this.db.examPapers || [],
        curriculumPlans: this.db.curriculumPlans || [],
        extracurricularActivities: this.db.extracurricularActivities || [],
        canteenMenus: this.db.canteenMenus || [],
        canteenSubscriptions: this.db.canteenSubscriptions || [],
        canteenServices: this.db.canteenServices || [],
        payrollRecords: this.db.payrollRecords || [],
        leaveRequests: this.db.leaveRequests || [],
        teacherEvaluations: this.db.teacherEvaluations || [],
        assets: this.db.assets || [],
        stockItems: this.db.stockItems || [],
        stockMovements: this.db.stockMovements || [],
        vehicles: this.db.vehicles || [],
        transportRoutes: this.db.transportRoutes || [],
        medicalRecords: this.db.medicalRecords || [],
        disciplinaryIncidents: this.db.disciplinaryIncidents || [],
        pickupAuthorizations: this.db.pickupAuthorizations || [],
        pickupRecords: this.db.pickupRecords || [],
        smsWhatsappNotifications: this.db.smsWhatsappNotifications || [],
        parentTeacherMeetings: this.db.parentTeacherMeetings || [],
        guardianChatThreads: this.db.guardianChatThreads || [],
        dataSubjectRequests: this.db.dataSubjectRequests || [],
        classes: this.db.classes || [],
        courses: this.db.courses || [],
        subjects: this.db.subjects || [],
        timetable: this.db.timetable || [],
        services: this.db.services || [],
        invoices: this.db.invoices || [],
        tuitionFees: this.db.invoices || [],
        attendance: this.db.attendance || [],
        attendanceSheets: this.db.attendanceSheets || [],
        pauta: this.db.pauta || [],
        notices: this.db.notices || [],
        notifications: this.db.notifications || [],
        books: this.db.books || [],
        loans: this.db.loans || [],
        auditLogs: this.db.auditLogs || defaultAuditLogs,
        events: this.db.events || defaultEvents,
        miniPautasStore: this.db.miniPautasStore || {},
        homologations: this.db.homologations || [],
        settings: this.db.settings || {},
        lastCloudSync: timestamp
      };

      const docRef = this.activeInstitutionId === 'inst_bandmed'
        ? ref(database, 'school_data/bandmed_main')
        : ref(database, 'institutions/' + this.activeInstitutionId);

      // O Realtime Database rejeita a escrita INTEIRA se qualquer propriedade do payload
      // tiver o valor `undefined`. Bastava um campo opcional por preencher (por exemplo a
      // Entidade Multicaixa de uma conta bancária) para toda a sincronização falhar em
      // silêncio — e as Configurações nunca chegarem à nuvem.
      await update(docRef, stripUndefinedDeep(payload));

      // Regista localmente o carimbo temporal sincronizado. Sem isto, `this.db.lastCloudSync`
      // ficava permanentemente vazio e qualquer cópia remota (mesmo mais antiga) era tratada
      // como mais recente no arranque seguinte, sobrepondo-se aos dados locais.
      this.db.lastCloudSync = timestamp;

      // Automatically persist all institution users directly into the 'users' collection
      if (Array.isArray(this.db.users)) {
        for (const u of this.db.users) {
          this.saveUserToCloud(u).catch(() => {});
        }
      }

      this.setSyncStatus('synced');
      return true;
    } catch (e) {
      console.warn('Erro ao sincronizar com o Realtime Database:', e);
      this.setSyncStatus('offline');
      return false;
    }
  }

  private scheduleSync() {
    if (this.syncTimer) clearTimeout(this.syncTimer);
    this.syncTimer = setTimeout(() => {
      this.pushToCloudStorage();
    }, 600);
  }

  public subscribe(listener: (db: SchoolDatabase) => void): () => void {
    this.listeners.add(listener);
    listener(this.getDatabase());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyLocal() {
    // 1. Asynchronously persist complete database (including high-res files & attachments) to IndexedDB
    idbService.save(this.db).catch(() => {});

    // 2. Persist to localStorage with intelligent quota-safe fallback & institution isolation
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        const fullJson = JSON.stringify(this.db);
        localStorage.setItem('escola_inst_' + this.activeInstitutionId, fullJson);

        if (this.activeInstitutionId === 'inst_bandmed') {
          if (fullJson.length < 2000000) {
            localStorage.setItem(STORAGE_KEY, fullJson);
          } else {
            const safeJson = prepareSafeLocalStorageSnapshot(this.db);
            localStorage.setItem(STORAGE_KEY, safeJson);
          }
        }
      } catch {
        try {
          // Attempt sanitized snapshot if full string exceeded quota
          const safeJson = prepareSafeLocalStorageSnapshot(this.db);
          localStorage.setItem('escola_inst_' + this.activeInstitutionId, safeJson);
          if (this.activeInstitutionId === 'inst_bandmed') {
            localStorage.setItem(STORAGE_KEY, safeJson);
          }
        } catch {
          // If still constrained by browser quota, save core records without crashing
          try {
            const compactSnapshot = {
              currentUser: this.db.currentUser,
              settings: this.db.settings,
              users: this.db.users,
              classes: this.db.classes,
              subjects: this.db.subjects,
              courses: this.db.courses
            };
            localStorage.setItem('escola_inst_' + this.activeInstitutionId, JSON.stringify(compactSnapshot));
            if (this.activeInstitutionId === 'inst_bandmed') {
              localStorage.setItem(STORAGE_KEY, JSON.stringify(compactSnapshot));
            }
          } catch {
            // Silently handled: IndexedDB has already persisted full data safely
          }
        }
      }
    }
    const currentData = this.getDatabase();
    this.listeners.forEach((listener) => listener(currentData));
  }

  private notify() {
    this.notifyLocal();
    this.scheduleSync();
  }

  // Multi-Tenancy & Institution Management
  public getInstitutionsIndex(): InstitutionSummary[] {
    const defaultList: InstitutionSummary[] = [
      {
        id: 'inst_bandmed',
        name: 'Complexo Escolar Privado BandMed',
        adminEmail: 'admin@escola.pt',
        adminName: 'Dr. Carlos Mendes',
        createdAt: '2024-01-01T00:00:00.000Z'
      }
    ];

    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        const stored = localStorage.getItem('escola_institutions_index');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch (e) {
        console.warn('Erro ao ler índice de instituições:', e);
      }
    }
    return defaultList;
  }

  public async saveInstitutionSummary(summary: InstitutionSummary): Promise<void> {
    // O registo global de instituições é um único nó partilhado por todas as
    // escolas (`institutions_registry/index`). Fundir a partir do valor
    // guardado no PRÓPRIO navegador (localStorage) — como este método fazia
    // antes — apaga da nuvem qualquer instituição registada por outra pessoa,
    // num browser diferente, que este navegador nunca viu. Por isso lê-se
    // primeiro o estado mais recente do Realtime Database (quando disponível)
    // e só depois se funde a entrada desta instituição nele.
    let list = this.getInstitutionsIndex();
    try {
      const remoteSnap = await get(ref(database, 'institutions_registry/index/list'));
      if (remoteSnap.exists()) {
        const remoteList = remoteSnap.val();
        if (Array.isArray(remoteList) && remoteList.length > 0) {
          list = remoteList;
        }
      }
    } catch (e) {
      console.warn('Não foi possível ler o registo remoto de instituições antes de gravar; a fundir apenas com o registo local:', e);
    }

    const existingIdx = list.findIndex((i) => i.id === summary.id);
    let updated: InstitutionSummary[];
    if (existingIdx >= 0) {
      updated = [...list];
      updated[existingIdx] = summary;
    } else {
      updated = [...list, summary];
    }

    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('escola_institutions_index', JSON.stringify(updated));
      } catch (e) {
        console.warn('Erro ao salvar índice de instituições:', e);
      }
    }

    try {
      const regDoc = ref(database, 'institutions_registry/index');
      await update(regDoc, { list: updated, updatedAt: new Date().toISOString() });
    } catch (e) {
      console.warn('Erro ao salvar índice no Realtime Database:', e);
    }
  }

  public async registerInstitutionAndAdmin(
    adminData: {
      name: string;
      email: string;
      password: string;
      avatar?: string;
      username?: string;
    },
    institutionData?: Partial<InstitutionSettings>
  ): Promise<{ success: boolean; institutionId: string; user: User; error?: string }> {
    const cleanEmail = adminData.email.trim().toLowerCase();
    const cleanName = adminData.name.trim();

    if (!cleanName) {
      return { success: false, error: 'Por favor, indique o nome do Administrador.', user: undefined as any, institutionId: '' };
    }
    if (!cleanEmail) {
      return { success: false, error: 'Por favor, indique o e-mail institucional.', user: undefined as any, institutionId: '' };
    }
    if (!adminData.password || adminData.password.trim().length < 6) {
      return { success: false, error: 'A palavra-passe deve conter pelo menos 6 caracteres.', user: undefined as any, institutionId: '' };
    }

    const newInstId = 'inst_' + Date.now();

    // Create the REAL Firebase Authentication account for the founding admin.
    const authResult = await createAccount(cleanEmail, adminData.password.trim());
    if (!authResult.success || !authResult.uid) {
      return { success: false, error: authResult.error || 'Não foi possível criar a conta de administrador.', user: undefined as any, institutionId: '' };
    }

    // `createAccount` runs on a disposable secondary Auth instance so it never
    // touches the app's main session. For a brand-new institution there is no
    // admin signed in yet, so sign in now on the MAIN Auth instance — Realtime Database's
    // security rules require an authenticated request before any of the writes
    // below (institution summary, admin profile, institution data) will succeed.
    const signInResult = await signIn(cleanEmail, adminData.password.trim());
    if (!signInResult.success) {
      return { success: false, error: signInResult.error || 'Conta criada, mas não foi possível iniciar sessão automaticamente. Tente entrar manualmente.', user: undefined as any, institutionId: '' };
    }

    const adminUser: User = {
      id: authResult.uid,
      name: cleanName,
      email: cleanEmail,
      username: adminData.username?.trim() || cleanEmail.split('@')[0],
      role: 'admin',
      roleTitle: 'Administrador Geral',
      avatar: adminData.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      institutionId: newInstId
    };

    const cleanDb = createCleanInstitutionDb(newInstId, adminUser, institutionData);

    const summary: InstitutionSummary = {
      id: newInstId,
      name: institutionData?.schoolName || 'Nova Instituição',
      adminEmail: cleanEmail,
      adminName: cleanName,
      createdAt: new Date().toISOString()
    };

    if (this.unsubscribeRealtime) {
      this.unsubscribeRealtime();
      this.unsubscribeRealtime = null;
    }

    this.activeInstitutionId = newInstId;
    this.db = cleanDb;

    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('escola_active_institution_id', newInstId);
        localStorage.setItem('escola_inst_' + newInstId, JSON.stringify(cleanDb));
        localStorage.setItem('bandmed_session_user', JSON.stringify(adminUser));
      } catch (e) {
        console.warn('Erro ao salvar nova instituição no localStorage:', e);
      }
    }

    // Persist the admin profile to 'users' FIRST and in STRICT mode: without this
    // document, database.rules.json cannot resolve the caller's institution, every
    // later write is denied, and the next login fails with "conta sem perfil".
    // A silent failure here used to produce a registration that only *looked* complete.
    try {
      await update(
        ref(database, 'users/' + adminUser.id),
        { ...adminUser, email: cleanEmail, institutionId: newInstId }
      );
    } catch (e: any) {
      console.error('Falha ao gravar o perfil do administrador no Realtime Database:', e);
      return {
        success: false,
        institutionId: '',
        user: undefined as any,
        error:
          'A conta de acesso foi criada, mas não foi possível gravar o perfil na base de dados ' +
          '(' + (e?.code || 'erro desconhecido') + '). Verifique as regras do Realtime Database ' +
          '(database.rules.json) e se o Realtime Database está ativo no projeto. Pode iniciar sessão ' +
          'com este e-mail assim que o problema for corrigido.'
      };
    }

    // Persist institution summary to registry
    await this.saveInstitutionSummary(summary);
    // Push institution database to the Realtime Database
    await this.pushToCloudStorage();
    await this.initRemoteSync();
    this.notifyLocal();

    return { success: true, institutionId: newInstId, user: adminUser };
  }

  public async switchInstitution(institutionId: string): Promise<boolean> {
    if (this.activeInstitutionId === institutionId) return true;

    if (this.unsubscribeRealtime) {
      this.unsubscribeRealtime();
      this.unsubscribeRealtime = null;
    }

    this.activeInstitutionId = institutionId;
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      localStorage.setItem('escola_active_institution_id', institutionId);
      const savedInst = localStorage.getItem('escola_inst_' + institutionId);
      if (savedInst) {
        try {
          this.db = JSON.parse(savedInst);
          this.notifyLocal();
        } catch (e) {
          console.warn('Erro ao carregar instituição local:', e);
        }
      }
    }

    this.initRemoteSync();
    return true;
  }

  // User Management
  public getUsers(): User[] {
    return this.db.users || [];
  }

  public async addUser(userData: {
    name: string;
    email: string;
    role: UserRole;
    roleTitle?: string;
    avatar?: string;
    phone?: string;
    processNumber?: string;
    password: string;
    username?: string;
    autoGeneratedEmail?: boolean;
    linkedTeacherId?: string;
    linkedStudentId?: string;
    linkedFuncionarioId?: string;
  }): Promise<User> {
    const roleTitleMap: Record<string, string> = {
      admin: 'Administrador Geral',
      director: 'Direção Pedagógica',
      secretaria: 'Secretaria Escolar',
      professor: 'Corpo Docente',
      financeiro: 'Tesouraria & Finanças',
      aluno: 'Estudante',
      encarregado: 'Encarregado de Educação',
      funcionario: 'Funcionário da Escola'
    };

    const cleanEmail = userData.email.trim().toLowerCase();

    // Create the REAL Firebase Authentication account first — this is now the
    // only place the password is used; it is never stored anywhere else.
    const authResult = await createAccount(cleanEmail, userData.password);
    if (!authResult.success || !authResult.uid) {
      throw new Error(authResult.error || 'Não foi possível criar a conta de acesso deste utilizador.');
    }

    const newUser: User = {
      id: authResult.uid,
      name: userData.name.trim(),
      email: cleanEmail,
      username: userData.username?.trim() || cleanEmail.split('@')[0],
      role: userData.role,
      roleTitle: userData.roleTitle || roleTitleMap[userData.role] || 'Utilizador',
      // Marca o início da contagem da validade da credencial (política de segurança).
      passwordUpdatedAt: new Date().toISOString(),
      avatar: userData.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      phone: userData.phone || '',
      processNumber: userData.processNumber || '',
      institutionId: this.activeInstitutionId,
      autoGeneratedEmail: userData.autoGeneratedEmail || undefined,
      linkedTeacherId: userData.linkedTeacherId || undefined,
      linkedStudentId: userData.linkedStudentId || undefined,
      linkedFuncionarioId: userData.linkedFuncionarioId || undefined
    };

    const currentUsers = this.db.users || [];
    this.db.users = [newUser, ...currentUsers];

    // Persist the profile (WITHOUT password) into Realtime Database, keyed by the Firebase Auth UID
    await this.saveUserToCloud(newUser);

    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Criação de Utilizador',
      details: `Novo utilizador "${newUser.name}" (${newUser.roleTitle}) registado com o perfil [${newUser.role}].`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });

    this.notify();
    return newUser;
  }

  /**
   * Cria, num único passo, a conta de acesso de um Aluno e, automaticamente, a
   * conta do respectivo Encarregado de Educação (caso ainda não exista uma).
   *
   * Regras de geração automática de e-mail (quando o campo correspondente não
   * estiver preenchido na ficha do aluno):
   *  - Encarregado de Educação: nomedoencarregado@encarregadoed.com
   *  - Aluno: nomedoaluno+numerodeprocesso@gmail.com
   *
   * O e-mail gerado é também gravado de volta na ficha do aluno, para manter a
   * base de dados consistente. A conta do Encarregado recebe uma palavra-passe
   * temporária (gerada automaticamente quando não for indicada), a comunicar
   * ao titular — que pode depois defini-la de novo através do link de
   * redefinição de palavra-passe.
   */
  public async createStudentAndGuardianAccounts(params: {
    studentId: string;
    studentPassword: string;
    guardianPassword?: string;
  }): Promise<{
    studentUser: User;
    guardianUser: User | null;
    guardianCreated: boolean;
    guardianPassword?: string;
    studentEmailWasGenerated: boolean;
    guardianEmailWasGenerated: boolean;
  }> {
    const student = (this.db.students || []).find((s) => s.id === params.studentId);
    if (!student) {
      throw new Error('Aluno não encontrado na base de dados.');
    }

    const alreadyHasStudentUser = (this.db.users || []).some(
      (u) => u.role === 'aluno' && u.linkedStudentId === student.id
    );
    if (alreadyHasStudentUser) {
      throw new Error('Este aluno já possui uma conta de utilizador criada.');
    }

    // 1. Conta do Aluno
    let studentEmail = (student.email || '').trim();
    let studentEmailWasGenerated = false;
    if (!studentEmail) {
      studentEmail = generateStudentAutoEmail(student.name, student.procNumber);
      studentEmailWasGenerated = true;
    }

    const studentUser = await this.addUser({
      name: student.name,
      email: studentEmail,
      role: 'aluno',
      roleTitle: 'Estudante',
      avatar: student.avatar,
      processNumber: student.procNumber,
      password: params.studentPassword,
      autoGeneratedEmail: studentEmailWasGenerated,
      linkedStudentId: student.id
    });

    if (studentEmailWasGenerated) {
      this.updateStudent(student.id, { email: studentEmail });
    }

    // 2. Conta do Encarregado de Educação (automática, apenas se ainda não existir)
    let guardianUser: User | null = null;
    let guardianEmailWasGenerated = false;
    let guardianPasswordUsed: string | undefined;

    const alreadyHasGuardianUser = (this.db.users || []).some(
      (u) => u.role === 'encarregado' && u.linkedStudentId === student.id
    );

    if (!alreadyHasGuardianUser && student.guardianName && student.guardianName.trim()) {
      let guardianEmail = (student.guardianEmail || '').trim();
      if (!guardianEmail) {
        guardianEmail = generateGuardianAutoEmail(student.guardianName);
        guardianEmailWasGenerated = true;
      }
      guardianPasswordUsed = (params.guardianPassword || '').trim() || generateTempPassword();

      try {
        guardianUser = await this.addUser({
          name: student.guardianName,
          email: guardianEmail,
          role: 'encarregado',
          roleTitle: 'Encarregado de Educação',
          phone: student.guardianPhone,
          password: guardianPasswordUsed,
          autoGeneratedEmail: guardianEmailWasGenerated,
          linkedStudentId: student.id
        });

        if (guardianEmailWasGenerated) {
          this.updateStudent(student.id, { guardianEmail });
        }
      } catch (guardianError) {
        // Se o e-mail do encarregado já estiver em uso por outra conta (ex.: já
        // é utilizador de outro educando), a conta do aluno mantém-se criada,
        // mas o erro é reportado para o administrador tratar manualmente.
        throw new Error(
          `Conta do aluno criada com sucesso, mas não foi possível criar automaticamente a conta do Encarregado de Educação: ${
            (guardianError as Error)?.message || 'erro desconhecido'
          }`
        );
      }
    }

    return {
      studentUser,
      guardianUser,
      guardianCreated: !!guardianUser,
      guardianPassword: guardianUser ? guardianPasswordUsed : undefined,
      studentEmailWasGenerated,
      guardianEmailWasGenerated
    };
  }

  /**
   * Sends the user a password-reset e-mail via Firebase Auth. This replaces the old
   * behaviour of an administrator typing a new password directly — the client SDK
   * cannot set another account's password (that requires a trusted server / Cloud
   * Function with the Firebase Admin SDK), so a reset link is the correct approach.
   */
  public async resetUserPassword(email: string): Promise<{ success: boolean; error?: string }> {
    const result = await sendPasswordReset(email);
    return result;
  }

  public updateUser(userId: string, updates: Partial<User>): User | null {
    if (!this.db.users) return null;
    const idx = this.db.users.findIndex((u) => u.id === userId);
    if (idx === -1) return null;

    const existing = this.db.users[idx];
    // Password changes are handled separately through Firebase Auth
    // (see resetUserPassword) — never write a password onto the profile.
    const { password: _ignoredPassword, ...safeUpdates } = updates as any;
    const updated: User = {
      ...existing,
      ...safeUpdates,
      id: existing.id
    };

    this.db.users[idx] = updated;

    if (this.db.currentUser && this.db.currentUser.id === userId) {
      this.db.currentUser = updated;
    }

    // Automatically sync updated user directly into Realtime Database 'users' node
    this.saveUserToCloud(updated).catch(() => {});

    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Atualização de Utilizador',
      details: `Dados do utilizador "${updated.name}" atualizados.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#1d4ed8'
    });

    this.notify();
    return updated;
  }

  public deleteUser(userId: string): { success: boolean; error?: string } {
    if (!this.db.users) return { success: false, error: 'Lista de utilizadores vazia.' };

    const target = this.db.users.find((u) => u.id === userId);
    if (!target) return { success: false, error: 'Utilizador não encontrado.' };

    if (target.role === 'admin') {
      const adminCount = this.db.users.filter((u) => u.role === 'admin').length;
      if (adminCount <= 1) {
        return {
          success: false,
          error: 'Não é possível eliminar o único Administrador Geral da instituição.'
        };
      }
    }

    if (this.db.currentUser && this.db.currentUser.id === userId) {
      return {
        success: false,
        error: 'Não pode eliminar a sua própria conta ativa em sessão.'
      };
    }

    this.db.users = this.db.users.filter((u) => u.id !== userId);

    // Remove the Realtime Database profile. NOTE: the Firebase Auth account itself can only be
    // deleted with the Admin SDK on a trusted server (Cloud Function) — the client SDK
    // cannot delete another user's auth account. Until such a function exists, disable
    // portal access for this person via Configurações, in addition to this deletion.
    try {
      if (target.id) remove(ref(database, 'users/' + target.id)).catch(() => {});
    } catch {
      // ignore
    }

    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Eliminação de Utilizador',
      details: `Utilizador "${target.name}" (${target.roleTitle}) eliminado da base de dados.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#ac332b'
    });

    this.notify();
    return { success: true };
  }

  /**
   * Called once on app boot with whatever Firebase Auth reports for this browser
   * (watchAuthState in App.tsx). This is the ONLY place session validity is decided —
   * a leftover 'bandmed_session_user' in localStorage with no matching Firebase token
   * must never be treated as a valid session.
   */
  public async restoreSession(uid: string | null): Promise<User | null> {
    if (!uid) {
      // No Firebase token for this browser: drop any stale local session.
      this.db.currentUser = null;
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        try {
          localStorage.removeItem('bandmed_session_user');
        } catch (e) {
          console.warn(e);
        }
      }
      this.notifyLocal();
      return null;
    }

    // A real token exists. If the locally cached profile already matches it, trust it
    // and avoid an extra round-trip.
    if (this.db.currentUser && this.db.currentUser.id === uid) {
      return this.db.currentUser;
    }

    let profile: User | null = null;
    try {
      const profileDoc = await get(ref(database, 'users/' + uid));
      if (profileDoc.exists()) {
        profile = profileDoc.val() as User;
      }
    } catch (e) {
      console.warn('Erro ao restaurar perfil da sessão:', e);
    }

    if (!profile) {
      // Authenticated with Firebase but no school profile on record: cannot let
      // this session into the app.
      this.db.currentUser = null;
      return null;
    }

    if (profile.institutionId && profile.institutionId !== this.activeInstitutionId) {
      await this.switchInstitution(profile.institutionId);
    }

    if (!this.db.users.some((u) => u.id === profile!.id)) {
      this.db.users = [profile, ...(this.db.users || [])];
    }

    this.db.currentUser = profile;
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('bandmed_session_user', JSON.stringify(profile));
        localStorage.setItem('escola_active_institution_id', this.activeInstitutionId);
      } catch (e) {
        console.warn(e);
      }
    }

    this.notify();
    return profile;
  }

  // Auth & Session
  public getCurrentUser(): User | null {
    return this.db.currentUser || null;
  }

  public setCurrentUser(user: User) {
    this.db.currentUser = user;
    this.notify();
  }

  /**
   * Ends the Firebase Auth session and clears the local mirror. Real sign-out —
   * no more toggling a "logged out" flag while a demo user stays selected.
   */
  public async logout() {
    try {
      await signOutUser();
    } catch (e) {
      console.warn(e);
    }
    this.db.currentUser = null;
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.removeItem('bandmed_session_user');
      }
    } catch (e) {
      console.warn(e);
    }
    this.notify();
  }

  /**
   * Resolves a login identifier (e-mail, username, número de processo/agente) to the
   * e-mail address registered in Realtime Database, since Firebase Auth always signs in by e-mail.
   */
  private async resolveLoginEmail(identifier: string): Promise<string | null> {
    const term = identifier.trim().toLowerCase();
    if (!term) return null;
    if (term.includes('@')) return term;

    // 1. Search the 'users' node (staff/students/teachers/guardians with portal access).
    //    NOTE: this runs BEFORE sign-in, so database.rules.json will normally deny it
    //    (reading /users requires an authenticated staff account). That is expected —
    //    we simply fall through to the locally mirrored users below, and ultimately
    //    ask the person to use their e-mail address.
    //    Requires an index on 'username' and 'processNumber' under /users in
    //    database.rules.json (".indexOn": ["username", "processNumber"]) for this to
    //    run efficiently — it still works without it, just with a console warning.
    try {
      const usersRef = ref(database, 'users');
      for (const field of ['username', 'processNumber']) {
        const q = query(usersRef, orderByChild(field), equalTo(term));
        const snap = await get(q);
        if (snap.exists()) {
          const matches = snap.val() as Record<string, User>;
          const firstKey = Object.keys(matches)[0];
          const u = matches[firstKey];
          if (u?.email) return u.email.toLowerCase();
        }
      }
    } catch {
      // Permission denied (not signed in yet) or offline — fall through to local cache.
    }

    // 2. Fallback to whatever is mirrored locally in this session
    const local = this.db.users.find(
      (u) =>
        (u.username && u.username.toLowerCase() === term) ||
        (u.processNumber && u.processNumber.toLowerCase() === term)
    );
    if (local?.email) return local.email.toLowerCase();

    return null;
  }

  /**
   * Authenticates against Firebase Authentication (the single source of truth for
   * credentials) and then loads the matching profile document from Realtime Database
   * (collection 'users', keyed by the Firebase Auth UID) to resolve role/permissions.
   */
  public async authenticate(identifier: string, password: string): Promise<{ success: boolean; user?: User; error?: string }> {
    const term = identifier.trim();
    const pwd = password.trim();

    if (!term) {
      return { success: false, error: 'Por favor, introduza o seu e-mail, nome de utilizador ou número de processo.' };
    }
    if (!pwd) {
      return { success: false, error: 'Por favor, introduza a sua palavra-passe.' };
    }

    const email = await this.resolveLoginEmail(term);
    if (!email) {
      return {
        success: false,
        error:
          'Não foi possível identificar este utilizador a partir de "' + term + '". ' +
          'Por motivos de segurança, a procura por nome de utilizador ou n.º de processo só funciona ' +
          'em dispositivos onde a instituição já foi carregada. Inicie sessão com o seu endereço de e-mail.'
      };
    }

    const authResult = await signIn(email, pwd);
    if (!authResult.success || !authResult.uid) {
      return { success: false, error: authResult.error || 'Credenciais inválidas.' };
    }

    // Load this user's profile document (role, name, institution, etc.) from the Realtime Database.
    let profile: User | null = null;
    try {
      const profileDoc = await get(ref(database, 'users/' + authResult.uid));
      if (profileDoc.exists()) {
        profile = profileDoc.val() as User;
      }
    } catch (e) {
      console.warn('Erro ao carregar perfil do utilizador no Realtime Database:', e);
    }

    if (!profile) {
      return {
        success: false,
        error: 'A sua conta está autenticada, mas não tem um perfil associado no sistema escolar. Contacte o administrador.'
      };
    }

    if (profile.institutionId && profile.institutionId !== this.activeInstitutionId) {
      await this.switchInstitution(profile.institutionId);
    }

    if (!this.db.users.some((u) => u.id === profile!.id)) {
      this.db.users = [profile, ...(this.db.users || [])];
    }

    this.db.currentUser = profile;

    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('bandmed_session_user', JSON.stringify(profile));
        localStorage.setItem('escola_active_institution_id', this.activeInstitutionId);
      } catch (e) {
        console.warn('Erro ao persistir sessão do utilizador:', e);
      }
    }

    this.notify();
    return { success: true, user: profile };
  }


  // Dynamic synchronization of enrolled students count in classes
  public syncClassStudentCounts() {
    if (!this.db.classes) return;
    this.db.classes = this.db.classes.map((cls) => {
      const realEnrolled = (this.db.students || []).filter(
        (s) => String(s.classId) === String(cls.id)
      ).length;
      return {
        ...cls,
        studentCount: realEnrolled > 0 ? realEnrolled : (cls.studentCount || 0)
      };
    });
  }

  // ================= MATRÍCULAS =================
  // A ficha do Aluno (Student) guarda só dados pessoais/documentais. A
  // Matrícula (1 aluno → N matrículas, uma por ano letivo em que estudou
  // nesta instituição) é que define turma, regime e plano financeiro, e é
  // ela que gera as obrigações financeiras (taxa de matrícula + mensalidades)
  // em `db.invoices` — nunca a ficha de cadastro do aluno.

  public getMatriculasByStudent(studentId: string): Matricula[] {
    return (this.db.matriculas || [])
      .filter((m) => m.studentId === studentId)
      .sort((a, b) => b.academicYear.localeCompare(a.academicYear));
  }

  /** Histórico escolar DENTRO da instituição (anos em que o aluno estudou aqui). */
  public getHistoricoEscolar(studentId: string): Matricula[] {
    return this.getMatriculasByStudent(studentId);
  }

  /** Nº de matrícula sequencial real, nunca repetido: MAT-<ano letivo>-<seq 4 dígitos>. */
  public generateMatriculaNumber(academicYear?: string): string {
    const yearPart = (academicYear || this.db.settings?.currentAcademicYear || String(new Date().getFullYear())).replace('/', '-');
    let max = 0;
    for (const m of this.db.matriculas || []) {
      const match = (m.numeroMatricula || '').match(/MAT-.*-(\d+)$/);
      if (match) max = Math.max(max, parseInt(match[1], 10));
    }
    return `MAT-${yearPart}-${String(max + 1).padStart(4, '0')}`;
  }

  /**
   * Confirma uma Matrícula: grava o registo histórico, atualiza o "instantâneo"
   * de turma/plano financeiro do Aluno (que Turmas/Assiduidade/Pautas/Propinas
   * já consomem via `Student`) e GERA AS OBRIGAÇÕES FINANCEIRAS — 1 fatura da
   * taxa de matrícula + N faturas de propina (mensalidades). Nunca inventa
   * valores: tudo vem dos dados da própria Matrícula, que por sua vez vêm da
   * Tabela Financeira real (`settings.tuitionRows`) e das Regras Financeiras
   * (`settings.financialRules`) configuradas pela instituição.
   */
  public confirmMatricula(
    data: Omit<Matricula, 'id' | 'numeroMatricula' | 'generatedInvoiceIds' | 'createdAt' | 'studentName' | 'studentProcNumber' | 'studentAvatar' | 'studentGender' | 'studentBirthDate'>
  ): Matricula {
    const student = this.db.students.find((s) => s.id === data.studentId);
    if (!student) throw new Error('Aluno não encontrado. Cadastre o aluno antes de matricular.');

    const matricula: Matricula = {
      ...data,
      id: `mat-${Date.now()}`,
      numeroMatricula: this.generateMatriculaNumber(data.academicYear),
      studentName: student.name,
      studentProcNumber: student.procNumber,
      studentAvatar: student.avatar,
      studentGender: student.gender,
      studentBirthDate: student.birthDate,
      createdAt: new Date().toISOString()
    };

    // 1) Guardar o registo histórico da matrícula
    this.db.matriculas = [matricula, ...(this.db.matriculas || [])];

    // 2) Aluno passa a refletir a turma/plano financeiro desta matrícula
    //    (estado "atual" consumido por Turmas/Assiduidade/Pautas/Propinas)
    const exempt = matricula.tipoAluno === 'isento' || matricula.tipoAluno === 'bolseiro';
    this.updateStudent(student.id, {
      classId: matricula.classId,
      className: matricula.className,
      grade: matricula.grade,
      shift: matricula.shift,
      courseName: matricula.courseName,
      monthlyTuitionKz: matricula.valorPropinaKz,
      financialStatus: exempt ? 'isento' : matricula.estadoFinanceiro,
      status: 'active',
      studentSituation: 'Activo'
    } as Partial<Student>);
    this.syncClassStudentCounts();

    // 3) GERAR PAGAMENTOS — Matrícula ⇒ obrigação financeira única;
    //    Propina ⇒ N mensalidades (nunca geradas para alunos isentos/bolseiros)
    const invoiceIds: string[] = [];
    const baseInvoice = {
      studentId: student.id,
      studentName: student.name,
      procNumber: student.procNumber,
      avatar: student.avatar,
      className: matricula.className,
      guardianName: matricula.responsavelFinanceiroNome || student.guardianName || '',
      guardianNif: student.guardianNif || '',
      guardianPhone: matricula.responsavelFinanceiroTelefone || student.guardianPhone || '',
      guardianAddress: student.residence?.province
        ? student.residence.province + (student.residence.neighborhood ? ', ' + student.residence.neighborhood : '')
        : student.address || '',
      studentBiNumber: student.biNumber || '',
      status: 'pendente' as const,
      lateFeeKz: 0
    };

    if (!exempt && matricula.valorMatriculaKz > 0) {
      const dueDay = Math.min(matricula.diaVencimento || this.db.settings?.financialRules?.paymentDueDay || 10, 28);
      const due = new Date();
      due.setDate(dueDay);
      const inv = this.createInvoice({
        ...baseInvoice,
        period: matricula.academicYear,
        description: `Taxa de Matrícula — ${matricula.grade} (${matricula.academicYear})`,
        baseAmountKz: matricula.valorMatriculaKz,
        totalAmountKz: matricula.valorMatriculaKz,
        dueDate: due.toISOString().slice(0, 10)
      });
      invoiceIds.push(inv.id);
    }

    const installments = matricula.numeroParcelas || 0;
    if (!exempt && matricula.valorPropinaKz > 0 && installments > 0) {
      const net = Math.round(matricula.valorPropinaKz * (1 - (matricula.descontoPercent || 0) / 100));
      const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
      const startIso = this.db.settings?.academicPeriodStartIso;
      let cursor = startIso ? new Date(startIso + 'T00:00:00') : new Date(`${matricula.academicYear.split('/')[0]}-09-01T00:00:00`);
      for (let i = 0; i < installments; i++) {
        const dueDay = Math.min(matricula.diaVencimento || this.db.settings?.financialRules?.paymentDueDay || 10, 28);
        const due = new Date(cursor.getFullYear(), cursor.getMonth(), dueDay);
        const inv = this.createInvoice({
          ...baseInvoice,
          period: `${monthNames[cursor.getMonth()]} ${cursor.getFullYear()}`,
          description: `Propina — ${monthNames[cursor.getMonth()]} ${cursor.getFullYear()} — ${matricula.grade} ${matricula.className}`,
          baseAmountKz: net,
          totalAmountKz: net,
          dueDate: due.toISOString().slice(0, 10)
        });
        invoiceIds.push(inv.id);
        cursor = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
      }
    }

    matricula.generatedInvoiceIds = invoiceIds;
    this.db.matriculas = (this.db.matriculas || []).map((m) => (m.id === matricula.id ? matricula : m));
    this.notify();
    return matricula;
  }

  public updateMatricula(id: string, updates: Partial<Matricula>) {
    this.db.matriculas = (this.db.matriculas || []).map((m) => (m.id === id ? { ...m, ...updates } : m));
    this.notify();
  }

  // Students CRUD
  public addStudent(
    student: Omit<Student, 'id' | 'procNumber' | 'attendanceRate' | 'currentAverage'> & {
      procNumber?: string;
    }
  ): Student {
    const photo = student.docPassPhoto || student.avatar || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150';
    const newStudent: Student = {
      ...student,
      id: `stu-${Date.now()}`,
      // Número de processo automático e aleatório: <ano lectivo inicial>-<4 a 6 dígitos>
      // (ex.: 2026-81457), nunca repetido face aos já atribuídos.
      procNumber:
        student.procNumber ||
        generateStudentProcNumber(
          (this.db.students || []).map((s) => s.procNumber),
          this.db.settings?.currentAcademicYear
        ),
      avatar: photo,
      docPassPhoto: photo,
      // Sem dados inventados: um aluno acabado de matricular ainda não tem
      // assiduidade medida nem média, e não tem nenhuma nota lançada.
      attendanceRate: 100,
      currentAverage: 0,
      unexcusedAbsences: 0,
      excusedAbsences: 0,
      isTuitionPaidCurrentMonth: student.financialStatus !== 'debito',
      disciplineGrades: student.disciplineGrades || []
    };
    this.db.students = [newStudent, ...this.db.students];
    this.syncClassStudentCounts();
    this.notify();
    return newStudent;
  }

  public updateStudent(id: string, updates: Partial<Student>) {
    this.db.students = this.db.students.map((s) => {
      if (s.id !== id) return s;
      const updated = { ...s, ...updates };
      if (updates.docPassPhoto && !updates.avatar) {
        updated.avatar = updates.docPassPhoto;
      } else if (updates.avatar && !updates.docPassPhoto) {
        updated.docPassPhoto = updates.avatar;
      }
      return updated;
    });
    this.syncClassStudentCounts();
    this.notify();
  }

  public deleteStudent(id: string) {
    this.db.students = this.db.students.filter((s) => s.id !== id);
    this.syncClassStudentCounts();
    this.notify();
  }

  // Teachers CRUD
  public addTeacher(
    teacher: Omit<Teacher, 'id' | 'agentNumber' | 'rating' | 'evaluationsCount'> & {
      agentNumber?: string;
    }
  ): Teacher {
    const newTeacher: Teacher = {
      ...teacher,
      id: `prof-${Date.now()}`,
      // Número de agente automático e aleatório: AG-<4 dígitos> (ex.: AG-0044),
      // nunca repetido face aos já atribuídos.
      agentNumber:
        teacher.agentNumber ||
        generateTeacherAgentNumber((this.db.teachers || []).map((t) => t.agentNumber)),
      // No fabricated rating: a real teacher has no evaluations until the
      // institution actually records one.
      rating: 0,
      evaluationsCount: 0,
      allocatedClasses: teacher.allocatedClasses || []
    };
    this.db.teachers = [newTeacher, ...this.db.teachers];
    this.notify();
    return newTeacher;
  }

  public updateTeacher(id: string, updates: Partial<Teacher>) {
    this.db.teachers = this.db.teachers.map((t) => (t.id === id ? { ...t, ...updates } : t));
    // If teacher's name was changed, sync to classes where this teacher is assigned as Director
    if (updates.name && this.db.classes) {
      this.db.classes = this.db.classes.map((c) =>
        c.headTeacherId === id ? { ...c, headTeacherName: updates.name! } : c
      );
    }
    this.notify();
  }

  public deleteTeacher(id: string): { success: boolean; unlinkedClassesCount: number } {
    let unlinkedCount = 0;
    if (this.db.classes) {
      this.db.classes = this.db.classes.map((c) => {
        if (c.headTeacherId === id) {
          unlinkedCount++;
          return { ...c, headTeacherId: '', headTeacherName: 'A designar' };
        }
        return c;
      });
    }
    this.db.teachers = this.db.teachers.filter((t) => t.id !== id);
    this.notify();
    return { success: true, unlinkedClassesCount: unlinkedCount };
  }

  // Funcionários CRUD (pessoal não-docente: secretaria, direção, tesouraria, apoio, etc.)
  public getFuncionarios(): Funcionario[] {
    return this.db.funcionarios || [];
  }

  public addFuncionario(
    funcionario: Omit<Funcionario, 'id' | 'employeeNumber'> & { employeeNumber?: string }
  ): Funcionario {
    const newFuncionario: Funcionario = {
      ...funcionario,
      id: `func-${Date.now()}`,
      employeeNumber:
        funcionario.employeeNumber ||
        generateFuncionarioNumber((this.db.funcionarios || []).map((f) => f.employeeNumber))
    };
    this.db.funcionarios = [newFuncionario, ...(this.db.funcionarios || [])];
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Cadastro de Funcionário',
      details: `Novo funcionário "${newFuncionario.name}" registado na base de dados institucional.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return newFuncionario;
  }

  public updateFuncionario(id: string, updates: Partial<Funcionario>) {
    this.db.funcionarios = (this.db.funcionarios || []).map((f) => (f.id === id ? { ...f, ...updates } : f));
    this.notify();
  }

  public deleteFuncionario(id: string): { success: boolean } {
    this.db.funcionarios = (this.db.funcionarios || []).filter((f) => f.id !== id);
    this.notify();
    return { success: true };
  }

  public clearFuncionarios() {
    this.db.funcionarios = [];
    this.notify();
  }

  // ------------------------------------------------------------------
  // Departamentos (Cadastro → Departamentos)
  //  • curricular   → usados no seletor de Departamento dos Professores
  //  • profissional → usados no seletor de Departamento dos Funcionários
  // O departamento é guardado por NOME nos registos de professores e
  // funcionários; por isso renomear cascateia e eliminar é bloqueado
  // enquanto houver pessoas associadas.
  // ------------------------------------------------------------------
  public getDepartments(kind?: DepartmentKind): SchoolDepartment[] {
    const all = this.db.departments || [];
    return kind ? all.filter((d) => d.kind === kind) : all;
  }

  /** Nº de professores (curricular) ou funcionários (profissional) num departamento. */
  public countDepartmentMembers(kind: DepartmentKind, name: string): number {
    const target = name.trim().toLowerCase();
    const people: Array<{ department?: string }> =
      kind === 'curricular' ? this.db.teachers || [] : this.db.funcionarios || [];
    return people.filter((p) => (p.department || '').trim().toLowerCase() === target).length;
  }

  public addDepartment(
    department: Omit<SchoolDepartment, 'id' | 'createdAt'>
  ): { success: boolean; error?: string; department?: SchoolDepartment } {
    const name = department.name.trim();
    if (!name) return { success: false, error: 'Indique o nome do departamento.' };
    const duplicate = (this.db.departments || []).some(
      (d) => d.kind === department.kind && d.name.trim().toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      return { success: false, error: `Já existe um departamento "${name}" nesta categoria.` };
    }
    const created: SchoolDepartment = {
      ...department,
      name,
      id: `dept-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString()
    };
    this.db.departments = [...(this.db.departments || []), created];
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Cadastro de Departamento',
      details: `Departamento ${created.kind === 'curricular' ? 'curricular' : 'profissional'} "${created.name}" registado.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, department: created };
  }

  public updateDepartment(
    id: string,
    updates: Partial<Omit<SchoolDepartment, 'id' | 'createdAt'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.departments || []).find((d) => d.id === id);
    if (!current) return { success: false, error: 'Departamento não encontrado.' };

    const nextKind = updates.kind ?? current.kind;
    const nextName = (updates.name ?? current.name).trim();
    if (!nextName) return { success: false, error: 'Indique o nome do departamento.' };

    const duplicate = (this.db.departments || []).some(
      (d) => d.id !== id && d.kind === nextKind && d.name.trim().toLowerCase() === nextName.toLowerCase()
    );
    if (duplicate) {
      return { success: false, error: `Já existe um departamento "${nextName}" nesta categoria.` };
    }

    // A categoria não pode mudar se houver pessoas associadas (ficariam órfãs).
    if (nextKind !== current.kind && this.countDepartmentMembers(current.kind, current.name) > 0) {
      return {
        success: false,
        error: 'Não é possível mudar a categoria: existem professores/funcionários associados a este departamento.'
      };
    }

    this.db.departments = (this.db.departments || []).map((d) =>
      d.id === id ? { ...d, ...updates, name: nextName, kind: nextKind } : d
    );

    // Renomeação cascateia para os registos que usam o nome antigo.
    if (nextName !== current.name) {
      if (current.kind === 'curricular') {
        this.db.teachers = (this.db.teachers || []).map((t) =>
          (t.department || '').trim().toLowerCase() === current.name.trim().toLowerCase()
            ? { ...t, department: nextName }
            : t
        );
      } else {
        this.db.funcionarios = (this.db.funcionarios || []).map((f) =>
          (f.department || '').trim().toLowerCase() === current.name.trim().toLowerCase()
            ? { ...f, department: nextName }
            : f
        );
      }
    }
    this.notify();
    return { success: true };
  }

  public deleteDepartment(
    id: string
  ): { success: boolean; error?: string; membersCount?: number } {
    const current = (this.db.departments || []).find((d) => d.id === id);
    if (!current) return { success: false, error: 'Departamento não encontrado.' };
    const membersCount = this.countDepartmentMembers(current.kind, current.name);
    if (membersCount > 0) {
      return {
        success: false,
        membersCount,
        error: `Não é possível eliminar: ${membersCount} ${
          current.kind === 'curricular'
            ? membersCount === 1 ? 'professor está associado' : 'professores estão associados'
            : membersCount === 1 ? 'funcionário está associado' : 'funcionários estão associados'
        } a "${current.name}". Reatribua-os a outro departamento primeiro ou marque este como Inativo.`
      };
    }
    this.db.departments = (this.db.departments || []).filter((d) => d.id !== id);
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Fornecedores da instituição (Logística → Fornecedores)
  // ------------------------------------------------------------------
  public getSuppliers(): Supplier[] {
    return this.db.suppliers || [];
  }

  public addSupplier(
    supplier: Omit<Supplier, 'id' | 'code' | 'createdAt'>
  ): { success: boolean; error?: string; supplier?: Supplier } {
    const name = supplier.name.trim();
    if (!name) return { success: false, error: 'Indique o nome do fornecedor.' };
    const nif = (supplier.nif || '').trim();
    if (nif && (this.db.suppliers || []).some((s) => (s.nif || '').trim() === nif)) {
      return { success: false, error: `Já existe um fornecedor registado com o NIF ${nif}.` };
    }
    const created: Supplier = {
      ...supplier,
      name,
      nif: nif || undefined,
      id: `forn-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateSupplierCode((this.db.suppliers || []).map((s) => s.code)),
      createdAt: new Date().toISOString()
    };
    this.db.suppliers = [created, ...(this.db.suppliers || [])];
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action: 'Cadastro de Fornecedor',
      details: `Novo fornecedor "${created.name}" (${created.code}) registado.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, supplier: created };
  }

  public updateSupplier(
    id: string,
    updates: Partial<Omit<Supplier, 'id' | 'code' | 'createdAt'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.suppliers || []).find((s) => s.id === id);
    if (!current) return { success: false, error: 'Fornecedor não encontrado.' };
    const nextName = (updates.name ?? current.name).trim();
    if (!nextName) return { success: false, error: 'Indique o nome do fornecedor.' };
    const nextNif = (updates.nif ?? current.nif ?? '').trim();
    if (nextNif && (this.db.suppliers || []).some((s) => s.id !== id && (s.nif || '').trim() === nextNif)) {
      return { success: false, error: `Já existe um fornecedor registado com o NIF ${nextNif}.` };
    }
    this.db.suppliers = (this.db.suppliers || []).map((s) =>
      s.id === id ? { ...s, ...updates, name: nextName, nif: nextNif || undefined } : s
    );
    this.notify();
    return { success: true };
  }

  public deleteSupplier(id: string): { success: boolean } {
    this.db.suppliers = (this.db.suppliers || []).filter((s) => s.id !== id);
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Logística 2 — Inventário de Ativos
  // ------------------------------------------------------------------
  private logisticsAudit(action: string, details: string) {
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: 'Administrador',
      action,
      details,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
  }

  private newLogisticsId(prefix: string): string {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  }

  public getAssets(): Asset[] {
    return this.db.assets || [];
  }

  private validateAsset(
    fields: Partial<Omit<Asset, 'id' | 'code' | 'createdAt'>>,
    ignoreId?: string
  ): string | null {
    if (!(fields.name || '').trim()) return 'Indique o nome do ativo.';
    if (fields.category === 'outro' && !(fields.categoryOtherDescricao || '').trim()) {
      return 'Descreva a categoria quando selecionar "Outro".';
    }
    if (fields.acquisitionValueKz !== undefined && (!Number.isFinite(fields.acquisitionValueKz) || fields.acquisitionValueKz < 0)) {
      return 'O valor de aquisição não pode ser negativo.';
    }
    const serial = (fields.serialNumber || '').trim().toLowerCase();
    if (serial && (this.db.assets || []).some((a) => a.id !== ignoreId && (a.serialNumber || '').trim().toLowerCase() === serial)) {
      return `Já existe um ativo registado com o número de série ${fields.serialNumber!.trim()}.`;
    }
    return null;
  }

  public addAsset(
    asset: Omit<Asset, 'id' | 'code' | 'createdAt' | 'updatedAt' | 'supplierName'>
  ): { success: boolean; error?: string; asset?: Asset } {
    const error = this.validateAsset(asset);
    if (error) return { success: false, error };
    const supplier = asset.supplierId ? (this.db.suppliers || []).find((s) => s.id === asset.supplierId) : undefined;
    const created: Asset = {
      ...asset,
      name: asset.name.trim(),
      categoryOtherDescricao: asset.category === 'outro' ? asset.categoryOtherDescricao?.trim() : undefined,
      serialNumber: asset.serialNumber?.trim() || undefined,
      supplierName: supplier?.name,
      id: this.newLogisticsId('ativo'),
      code: generateAssetCode((this.db.assets || []).map((a) => a.code)),
      createdAt: new Date().toISOString()
    };
    this.db.assets = [created, ...(this.db.assets || [])];
    this.logisticsAudit('Cadastro de Ativo', `Novo ativo "${created.name}" (${created.code}) registado.`);
    this.notify();
    return { success: true, asset: created };
  }

  public updateAsset(
    id: string,
    updates: Partial<Omit<Asset, 'id' | 'code' | 'createdAt' | 'supplierName'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.assets || []).find((a) => a.id === id);
    if (!current) return { success: false, error: 'Ativo não encontrado.' };
    const merged = { ...current, ...updates };
    const error = this.validateAsset(merged, id);
    if (error) return { success: false, error };
    const supplier = merged.supplierId ? (this.db.suppliers || []).find((s) => s.id === merged.supplierId) : undefined;
    this.db.assets = (this.db.assets || []).map((a) =>
      a.id === id
        ? {
            ...merged,
            name: merged.name.trim(),
            categoryOtherDescricao: merged.category === 'outro' ? merged.categoryOtherDescricao?.trim() : undefined,
            serialNumber: merged.serialNumber?.trim() || undefined,
            supplierName: supplier?.name ?? (merged.supplierId ? current.supplierName : undefined),
            updatedAt: new Date().toISOString()
          }
        : a
    );
    this.notify();
    return { success: true };
  }

  public deleteAsset(id: string): { success: boolean } {
    const target = (this.db.assets || []).find((a) => a.id === id);
    this.db.assets = (this.db.assets || []).filter((a) => a.id !== id);
    if (target) this.logisticsAudit('Eliminação de Ativo', `Ativo "${target.name}" (${target.code}) eliminado do inventário.`);
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Logística 3 — Controlo de Estoque
  // ------------------------------------------------------------------
  public getStockItems(): StockItem[] {
    return this.db.stockItems || [];
  }

  public getStockMovements(): StockMovement[] {
    return this.db.stockMovements || [];
  }

  private validateStockItem(fields: Partial<StockItem>): string | null {
    if (!(fields.name || '').trim()) return 'Indique o nome do item.';
    if (fields.unit === 'outro' && !(fields.unitOtherDescricao || '').trim()) {
      return 'Descreva a unidade de medida quando selecionar "Outro".';
    }
    if (!Number.isFinite(fields.currentQuantity) || (fields.currentQuantity as number) < 0) {
      return 'A quantidade em estoque não pode ser negativa.';
    }
    if (!Number.isFinite(fields.minQuantity) || (fields.minQuantity as number) < 0) {
      return 'O estoque mínimo não pode ser negativo.';
    }
    return null;
  }

  public addStockItem(
    item: Omit<StockItem, 'id' | 'code' | 'createdAt' | 'updatedAt' | 'supplierName'>
  ): { success: boolean; error?: string; item?: StockItem } {
    const error = this.validateStockItem(item);
    if (error) return { success: false, error };
    const name = item.name.trim();
    if ((this.db.stockItems || []).some((s) => s.name.trim().toLowerCase() === name.toLowerCase())) {
      return { success: false, error: `Já existe um item de estoque chamado "${name}".` };
    }
    const supplier = item.supplierId ? (this.db.suppliers || []).find((s) => s.id === item.supplierId) : undefined;
    const now = new Date().toISOString();
    const created: StockItem = {
      ...item,
      name,
      unitOtherDescricao: item.unit === 'outro' ? item.unitOtherDescricao?.trim() : undefined,
      supplierName: supplier?.name,
      id: this.newLogisticsId('stk'),
      code: generateStockItemCode((this.db.stockItems || []).map((s) => s.code)),
      createdAt: now
    };
    this.db.stockItems = [created, ...(this.db.stockItems || [])];
    // Estoque inicial fica registado como primeira entrada, para o histórico bater com o saldo.
    if (created.currentQuantity > 0) {
      const movement: StockMovement = {
        id: this.newLogisticsId('mov'),
        itemId: created.id,
        itemName: created.name,
        type: 'entrada',
        quantity: created.currentQuantity,
        date: now.slice(0, 10),
        reason: 'Estoque inicial',
        performedByName: this.currentActorName(),
        createdAt: now
      };
      this.db.stockMovements = [movement, ...(this.db.stockMovements || [])];
    }
    this.logisticsAudit('Cadastro de Item de Estoque', `Novo item "${created.name}" (${created.code}) registado.`);
    this.notify();
    return { success: true, item: created };
  }

  /** Atualiza os dados do item. A quantidade só muda através de movimentos. */
  public updateStockItem(
    id: string,
    updates: Partial<Omit<StockItem, 'id' | 'code' | 'createdAt' | 'currentQuantity' | 'supplierName'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.stockItems || []).find((s) => s.id === id);
    if (!current) return { success: false, error: 'Item não encontrado.' };
    const merged = { ...current, ...updates };
    const error = this.validateStockItem(merged);
    if (error) return { success: false, error };
    const name = merged.name.trim();
    if ((this.db.stockItems || []).some((s) => s.id !== id && s.name.trim().toLowerCase() === name.toLowerCase())) {
      return { success: false, error: `Já existe um item de estoque chamado "${name}".` };
    }
    const supplier = merged.supplierId ? (this.db.suppliers || []).find((s) => s.id === merged.supplierId) : undefined;
    this.db.stockItems = (this.db.stockItems || []).map((s) =>
      s.id === id
        ? {
            ...merged,
            name,
            unitOtherDescricao: merged.unit === 'outro' ? merged.unitOtherDescricao?.trim() : undefined,
            supplierName: supplier?.name ?? (merged.supplierId ? current.supplierName : undefined),
            updatedAt: new Date().toISOString()
          }
        : s
    );
    if (name !== current.name) {
      this.db.stockMovements = (this.db.stockMovements || []).map((m) => (m.itemId === id ? { ...m, itemName: name } : m));
    }
    this.notify();
    return { success: true };
  }

  public deleteStockItem(id: string): { success: boolean } {
    const target = (this.db.stockItems || []).find((s) => s.id === id);
    this.db.stockItems = (this.db.stockItems || []).filter((s) => s.id !== id);
    this.db.stockMovements = (this.db.stockMovements || []).filter((m) => m.itemId !== id);
    if (target) this.logisticsAudit('Eliminação de Item de Estoque', `Item "${target.name}" (${target.code}) e respetivo histórico eliminados.`);
    this.notify();
    return { success: true };
  }

  public registerStockMovement(input: {
    itemId: string;
    type: StockMovementType;
    quantity: number;
    date?: string;
    reason?: string;
    relatedDocument?: string;
  }): { success: boolean; error?: string; movement?: StockMovement } {
    const item = (this.db.stockItems || []).find((s) => s.id === input.itemId);
    if (!item) return { success: false, error: 'Item de estoque não encontrado.' };
    if (!Number.isFinite(input.quantity) || input.quantity <= 0) {
      return { success: false, error: 'A quantidade do movimento tem de ser maior que zero.' };
    }
    if (input.type === 'saida' && input.quantity > item.currentQuantity) {
      return {
        success: false,
        error: `Estoque insuficiente: existem apenas ${item.currentQuantity} em "${item.name}".`
      };
    }
    const nextQty = input.type === 'entrada' ? item.currentQuantity + input.quantity : item.currentQuantity - input.quantity;
    const now = new Date().toISOString();
    const movement: StockMovement = {
      id: this.newLogisticsId('mov'),
      itemId: item.id,
      itemName: item.name,
      type: input.type,
      quantity: input.quantity,
      date: input.date || now.slice(0, 10),
      reason: input.reason?.trim() || undefined,
      relatedDocument: input.relatedDocument?.trim() || undefined,
      performedByName: this.currentActorName(),
      createdAt: now
    };
    this.db.stockMovements = [movement, ...(this.db.stockMovements || [])];
    this.db.stockItems = (this.db.stockItems || []).map((s) =>
      s.id === item.id ? { ...s, currentQuantity: nextQty, updatedAt: now } : s
    );
    this.logisticsAudit(
      input.type === 'entrada' ? 'Entrada de Estoque' : 'Saída de Estoque',
      `${input.type === 'entrada' ? 'Entrada' : 'Saída'} de ${input.quantity} em "${item.name}" (${item.code}). Saldo: ${nextQty}.`
    );
    this.notify();
    return { success: true, movement };
  }

  // ------------------------------------------------------------------
  // Logística 4 — Transporte Escolar (viaturas, rotas e alunos)
  // ------------------------------------------------------------------
  public getVehicles(): SchoolVehicle[] {
    return this.db.vehicles || [];
  }

  public getTransportRoutes(): TransportRoute[] {
    return this.db.transportRoutes || [];
  }

  private normalizePlate(plate: string): string {
    return plate.trim().toUpperCase().replace(/\s+/g, '');
  }

  public addVehicle(
    vehicle: Omit<SchoolVehicle, 'id' | 'code' | 'createdAt'>
  ): { success: boolean; error?: string; vehicle?: SchoolVehicle } {
    const plate = vehicle.plate.trim().toUpperCase();
    if (!plate) return { success: false, error: 'Indique a matrícula da viatura.' };
    if (!vehicle.model.trim()) return { success: false, error: 'Indique o modelo da viatura.' };
    if (!Number.isFinite(vehicle.capacity) || vehicle.capacity < 1) {
      return { success: false, error: 'A capacidade tem de ser de pelo menos 1 lugar.' };
    }
    if ((this.db.vehicles || []).some((v) => this.normalizePlate(v.plate) === this.normalizePlate(plate))) {
      return { success: false, error: `Já existe uma viatura registada com a matrícula ${plate}.` };
    }
    const created: SchoolVehicle = {
      ...vehicle,
      plate,
      model: vehicle.model.trim(),
      id: this.newLogisticsId('veic'),
      code: generateVehicleCode((this.db.vehicles || []).map((v) => v.code)),
      createdAt: new Date().toISOString()
    };
    this.db.vehicles = [created, ...(this.db.vehicles || [])];
    this.logisticsAudit('Cadastro de Viatura', `Nova viatura ${created.plate} (${created.code}) registada.`);
    this.notify();
    return { success: true, vehicle: created };
  }

  public updateVehicle(
    id: string,
    updates: Partial<Omit<SchoolVehicle, 'id' | 'code' | 'createdAt'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.vehicles || []).find((v) => v.id === id);
    if (!current) return { success: false, error: 'Viatura não encontrada.' };
    const merged = { ...current, ...updates };
    const plate = merged.plate.trim().toUpperCase();
    if (!plate) return { success: false, error: 'Indique a matrícula da viatura.' };
    if (!merged.model.trim()) return { success: false, error: 'Indique o modelo da viatura.' };
    if (!Number.isFinite(merged.capacity) || merged.capacity < 1) {
      return { success: false, error: 'A capacidade tem de ser de pelo menos 1 lugar.' };
    }
    if ((this.db.vehicles || []).some((v) => v.id !== id && this.normalizePlate(v.plate) === this.normalizePlate(plate))) {
      return { success: false, error: `Já existe uma viatura registada com a matrícula ${plate}.` };
    }
    const overloaded = (this.db.transportRoutes || []).find(
      (r) => r.vehicleId === id && r.studentIds.length > merged.capacity
    );
    if (overloaded) {
      return {
        success: false,
        error: `A rota "${overloaded.name}" tem ${overloaded.studentIds.length} alunos, acima da nova capacidade (${merged.capacity}).`
      };
    }
    const nextVehicle: SchoolVehicle = { ...merged, plate, model: merged.model.trim() };
    this.db.vehicles = (this.db.vehicles || []).map((v) => (v.id === id ? nextVehicle : v));
    this.db.transportRoutes = (this.db.transportRoutes || []).map((r) =>
      r.vehicleId === id ? { ...r, vehicleName: `${nextVehicle.plate} · ${nextVehicle.model}` } : r
    );
    this.notify();
    return { success: true };
  }

  public deleteVehicle(id: string): { success: boolean; error?: string } {
    const inUse = (this.db.transportRoutes || []).find((r) => r.vehicleId === id);
    if (inUse) {
      return { success: false, error: `Esta viatura está atribuída à rota "${inUse.name}". Retire-a da rota antes de eliminar.` };
    }
    const target = (this.db.vehicles || []).find((v) => v.id === id);
    this.db.vehicles = (this.db.vehicles || []).filter((v) => v.id !== id);
    if (target) this.logisticsAudit('Eliminação de Viatura', `Viatura ${target.plate} (${target.code}) eliminada.`);
    this.notify();
    return { success: true };
  }

  private validateRoute(
    fields: Partial<TransportRoute>,
    ignoreId?: string
  ): { error?: string; vehicleName?: string } {
    if (!(fields.name || '').trim()) return { error: 'Indique o nome da rota.' };
    if (!(fields.stops || []).some((s) => s.name.trim())) {
      return { error: 'Adicione pelo menos uma paragem à rota.' };
    }
    if (fields.monthlyFeeKz !== undefined && (!Number.isFinite(fields.monthlyFeeKz) || fields.monthlyFeeKz < 0)) {
      return { error: 'A mensalidade não pode ser negativa.' };
    }
    let vehicleName: string | undefined;
    if (fields.vehicleId) {
      const vehicle = (this.db.vehicles || []).find((v) => v.id === fields.vehicleId);
      if (!vehicle) return { error: 'Viatura selecionada não encontrada.' };
      if ((fields.studentIds || []).length > vehicle.capacity) {
        return { error: `A viatura ${vehicle.plate} tem capacidade para ${vehicle.capacity} alunos.` };
      }
      vehicleName = `${vehicle.plate} · ${vehicle.model}`;
    }
    return { vehicleName };
  }

  public addTransportRoute(
    route: Omit<TransportRoute, 'id' | 'code' | 'createdAt' | 'vehicleName' | 'studentIds'>
  ): { success: boolean; error?: string; route?: TransportRoute } {
    const check = this.validateRoute({ ...route, studentIds: [] });
    if (check.error) return { success: false, error: check.error };
    const created: TransportRoute = {
      ...route,
      name: route.name.trim(),
      stops: route.stops.filter((s) => s.name.trim()).map((s) => ({ name: s.name.trim(), time: s.time || undefined })),
      vehicleName: check.vehicleName,
      studentIds: [],
      id: this.newLogisticsId('rota'),
      code: generateRouteCode((this.db.transportRoutes || []).map((r) => r.code)),
      createdAt: new Date().toISOString()
    };
    this.db.transportRoutes = [created, ...(this.db.transportRoutes || [])];
    this.logisticsAudit('Cadastro de Rota', `Nova rota "${created.name}" (${created.code}) registada.`);
    this.notify();
    return { success: true, route: created };
  }

  public updateTransportRoute(
    id: string,
    updates: Partial<Omit<TransportRoute, 'id' | 'code' | 'createdAt' | 'vehicleName' | 'studentIds'>>
  ): { success: boolean; error?: string } {
    const current = (this.db.transportRoutes || []).find((r) => r.id === id);
    if (!current) return { success: false, error: 'Rota não encontrada.' };
    const merged = { ...current, ...updates };
    const check = this.validateRoute(merged, id);
    if (check.error) return { success: false, error: check.error };
    this.db.transportRoutes = (this.db.transportRoutes || []).map((r) =>
      r.id === id
        ? {
            ...merged,
            name: merged.name.trim(),
            stops: merged.stops.filter((s) => s.name.trim()).map((s) => ({ name: s.name.trim(), time: s.time || undefined })),
            vehicleName: check.vehicleName
          }
        : r
    );
    this.notify();
    return { success: true };
  }

  public deleteTransportRoute(id: string): { success: boolean } {
    const target = (this.db.transportRoutes || []).find((r) => r.id === id);
    this.db.transportRoutes = (this.db.transportRoutes || []).filter((r) => r.id !== id);
    if (target) this.logisticsAudit('Eliminação de Rota', `Rota "${target.name}" (${target.code}) eliminada.`);
    this.notify();
    return { success: true };
  }

  /** Inscreve um aluno numa rota: respeita a capacidade da viatura e impede duplicação noutras rotas ativas do mesmo turno. */
  public assignStudentToRoute(routeId: string, studentId: string): { success: boolean; error?: string } {
    const route = (this.db.transportRoutes || []).find((r) => r.id === routeId);
    if (!route) return { success: false, error: 'Rota não encontrada.' };
    const student = (this.db.students || []).find((s) => s.id === studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };
    if (route.studentIds.includes(studentId)) return { success: false, error: 'O aluno já está inscrito nesta rota.' };
    if (route.status !== 'ativa') return { success: false, error: 'Não é possível inscrever alunos numa rota inativa.' };
    if (route.vehicleId) {
      const vehicle = (this.db.vehicles || []).find((v) => v.id === route.vehicleId);
      if (vehicle && route.studentIds.length >= vehicle.capacity) {
        return { success: false, error: `A viatura ${vehicle.plate} já está lotada (${vehicle.capacity} lugares).` };
      }
    }
    const clash = (this.db.transportRoutes || []).find(
      (r) =>
        r.id !== routeId &&
        r.status === 'ativa' &&
        r.studentIds.includes(studentId) &&
        (r.shift === 'ambos' || route.shift === 'ambos' || r.shift === route.shift)
    );
    if (clash) {
      return { success: false, error: `${student.name} já está inscrito(a) na rota "${clash.name}" no mesmo turno.` };
    }
    this.db.transportRoutes = (this.db.transportRoutes || []).map((r) =>
      r.id === routeId ? { ...r, studentIds: [...r.studentIds, studentId] } : r
    );
    this.notify();
    return { success: true };
  }

  public removeStudentFromRoute(routeId: string, studentId: string): { success: boolean; error?: string } {
    const route = (this.db.transportRoutes || []).find((r) => r.id === routeId);
    if (!route) return { success: false, error: 'Rota não encontrada.' };
    this.db.transportRoutes = (this.db.transportRoutes || []).map((r) =>
      r.id === routeId ? { ...r, studentIds: r.studentIds.filter((id) => id !== studentId) } : r
    );
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Saúde & Segurança — 1. Ficha Médica, 2. Incidentes Disciplinares,
  // 3. Autorizações de Recolha
  // ------------------------------------------------------------------
  private healthSafetyAudit(action: string, details: string, badgeColor = '#0b1f3a') {
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action,
      details,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor
    });
  }

  private newHealthSafetyId(prefix: string): string {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  }

  // ---------- 1. Ficha Médica do Aluno ----------

  public getMedicalRecords(): StudentMedicalRecord[] {
    return this.db.medicalRecords || [];
  }

  public getMedicalRecordByStudentId(studentId: string): StudentMedicalRecord | undefined {
    return (this.db.medicalRecords || []).find((r) => r.studentId === studentId);
  }

  /** Regista, na trilha de auditoria, que a ficha médica de um aluno foi consultada (dado de saúde confidencial). */
  public logMedicalRecordView(record: StudentMedicalRecord) {
    this.healthSafetyAudit(
      'Consulta de Ficha Médica',
      `Ficha médica de ${record.studentName} (${record.studentProcNumber}) consultada — dado de saúde confidencial.`
    );
  }

  public saveMedicalRecord(
    input: { id?: string } & MedicalRecordFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; record?: StudentMedicalRecord } {
    const fields = normalizeMedicalRecordFields(input);
    const student = (this.db.students || []).find((s) => s.id === fields.studentId);
    const errors = validateMedicalRecord(fields, student, this.db.medicalRecords || [], input.id);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.medicalRecords || []).find((r) => r.id === input.id);
      if (!current) return { success: false, error: 'Ficha médica não encontrada.' };
      const updated: StudentMedicalRecord = {
        ...current,
        ...fields,
        reviewedAt: now.slice(0, 10),
        updatedAt: now,
        updatedBy: this.currentActorName()
      };
      this.db.medicalRecords = (this.db.medicalRecords || []).map((r) => (r.id === input.id ? updated : r));
      this.healthSafetyAudit(
        'Atualização de Ficha Médica',
        `Ficha médica de ${updated.studentName} (${updated.studentProcNumber}) atualizada — dado de saúde confidencial.`
      );
      this.notify();
      return { success: true, record: updated };
    }

    const created: StudentMedicalRecord = {
      ...fields,
      id: this.newHealthSafetyId('fmed'),
      code: generateMedicalRecordCode((this.db.medicalRecords || []).map((r) => r.code)),
      studentName: student!.name,
      studentProcNumber: student!.procNumber,
      className: student!.className,
      occurrences: [],
      reviewedAt: now.slice(0, 10),
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.medicalRecords = [created, ...(this.db.medicalRecords || [])];
    this.healthSafetyAudit(
      'Cadastro de Ficha Médica',
      `Nova ficha médica de ${created.studentName} (${created.code}) registada — dado de saúde confidencial.`
    );
    this.notify();
    return { success: true, record: created };
  }

  public deleteMedicalRecord(id: string): { success: boolean; error?: string } {
    const target = (this.db.medicalRecords || []).find((r) => r.id === id);
    if (!target) return { success: false, error: 'Ficha médica não encontrada.' };
    this.db.medicalRecords = (this.db.medicalRecords || []).filter((r) => r.id !== id);
    this.healthSafetyAudit(
      'Eliminação de Ficha Médica',
      `Ficha médica de ${target.studentName} (${target.code}) eliminada.`,
      '#b91c1c'
    );
    this.notify();
    return { success: true };
  }

  public addMedicalOccurrence(
    recordId: string,
    occurrence: Omit<MedicalOccurrence, 'id' | 'recordedBy' | 'recordedAt'>
  ): { success: boolean; error?: string; record?: StudentMedicalRecord } {
    const current = (this.db.medicalRecords || []).find((r) => r.id === recordId);
    if (!current) return { success: false, error: 'Ficha médica não encontrada.' };
    if (!occurrence.description.trim()) return { success: false, error: 'Descreva a ocorrência.' };
    const created: MedicalOccurrence = {
      ...occurrence,
      description: occurrence.description.trim(),
      actionTaken: occurrence.actionTaken?.trim() || undefined,
      id: this.newHealthSafetyId('mocc'),
      recordedBy: this.currentActorName(),
      recordedAt: new Date().toISOString()
    };
    const updated: StudentMedicalRecord = { ...current, occurrences: [created, ...current.occurrences] };
    this.db.medicalRecords = (this.db.medicalRecords || []).map((r) => (r.id === recordId ? updated : r));
    this.healthSafetyAudit(
      'Registo de Ocorrência de Saúde',
      `Ocorrência registada na ficha médica de ${current.studentName} (${current.code}).`
    );
    this.notify();
    return { success: true, record: updated };
  }

  // ---------- 2. Incidentes Disciplinares ----------

  public getDisciplinaryIncidents(): DisciplinaryIncident[] {
    return this.db.disciplinaryIncidents || [];
  }

  public saveDisciplinaryIncident(
    input: { id?: string } & IncidentFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; incident?: DisciplinaryIncident } {
    const errors = validateIncident(input);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const participants: IncidentParticipant[] = input.participants.map((p) => {
      const student = (this.db.students || []).find((s) => s.id === p.studentId);
      return {
        studentId: p.studentId,
        studentName: student?.name || 'Aluno não encontrado',
        studentProcNumber: student?.procNumber || '—',
        className: student?.className,
        role: p.role
      };
    });

    const notification: IncidentGuardianNotification = {
      notified: input.guardianNotification.notified,
      date: input.guardianNotification.date,
      channel: input.guardianNotification.channel as IncidentGuardianNotification['channel'],
      notes: input.guardianNotification.notes?.trim() || undefined
    };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.disciplinaryIncidents || []).find((i) => i.id === input.id);
      if (!current) return { success: false, error: 'Incidente não encontrado.' };
      const updated: DisciplinaryIncident = {
        ...current,
        academicYear: input.academicYear,
        date: input.date,
        time: input.time || undefined,
        location: input.location?.trim() || undefined,
        category: input.category,
        categoryOther: input.category === 'outro' ? input.categoryOther?.trim() : undefined,
        severity: input.severity,
        description: input.description.trim(),
        reportedBy: input.reportedBy.trim(),
        participants,
        guardianNotification: notification,
        updatedAt: now,
        updatedBy: this.currentActorName()
      };
      this.db.disciplinaryIncidents = (this.db.disciplinaryIncidents || []).map((i) => (i.id === input.id ? updated : i));
      this.notify();
      return { success: true, incident: updated };
    }

    const created: DisciplinaryIncident = {
      id: this.newHealthSafetyId('inc'),
      code: generateIncidentCode((this.db.disciplinaryIncidents || []).map((i) => i.code)),
      academicYear: input.academicYear,
      date: input.date,
      time: input.time || undefined,
      location: input.location?.trim() || undefined,
      category: input.category,
      categoryOther: input.category === 'outro' ? input.categoryOther?.trim() : undefined,
      severity: input.severity,
      description: input.description.trim(),
      reportedBy: input.reportedBy.trim(),
      participants,
      status: 'aberto',
      guardianNotification: notification,
      followUps: [],
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.disciplinaryIncidents = [created, ...(this.db.disciplinaryIncidents || [])];
    this.healthSafetyAudit(
      'Registo de Incidente Disciplinar',
      `Novo incidente "${INCIDENT_CATEGORY_LABELS[created.category]}" (${created.code}) registado, envolvendo ${participants.map((p) => p.studentName).join(', ')}.`,
      created.severity === 'muito_grave' ? '#b91c1c' : '#0b1f3a'
    );
    this.notify();
    return { success: true, incident: created };
  }

  public addIncidentFollowUp(id: string, note: string): { success: boolean; error?: string } {
    const current = (this.db.disciplinaryIncidents || []).find((i) => i.id === id);
    if (!current) return { success: false, error: 'Incidente não encontrado.' };
    if (!note.trim()) return { success: false, error: 'Escreva uma nota de seguimento.' };
    const entry: IncidentFollowUp = {
      id: this.newHealthSafetyId('fup'),
      date: new Date().toISOString(),
      note: note.trim(),
      by: this.currentActorName()
    };
    this.db.disciplinaryIncidents = (this.db.disciplinaryIncidents || []).map((i) =>
      i.id === id
        ? { ...i, followUps: [entry, ...i.followUps], status: i.status === 'aberto' ? 'em_analise' : i.status }
        : i
    );
    this.notify();
    return { success: true };
  }

  public decideIncidentMeasure(
    id: string,
    measure: Omit<DisciplinaryMeasure, 'decidedBy' | 'decidedAt'>
  ): { success: boolean; error?: string } {
    const current = (this.db.disciplinaryIncidents || []).find((i) => i.id === id);
    if (!current) return { success: false, error: 'Incidente não encontrado.' };
    const validationError = validateMeasure(measure.type, measure.details, measure.suspensionDays);
    if (validationError) return { success: false, error: validationError };

    const decided: DisciplinaryMeasure = {
      ...measure,
      details: measure.details?.trim() || undefined,
      decidedBy: this.currentActorName(),
      decidedAt: new Date().toISOString()
    };
    this.db.disciplinaryIncidents = (this.db.disciplinaryIncidents || []).map((i) =>
      i.id === id ? { ...i, measure: decided, status: 'decidido' as IncidentStatus } : i
    );
    this.healthSafetyAudit(
      'Decisão de Incidente Disciplinar',
      `Incidente "${current.code}" decidido — medida: ${measure.type}.`
    );
    this.notify();
    return { success: true };
  }

  public archiveDisciplinaryIncident(id: string, reason?: string): { success: boolean; error?: string } {
    const current = (this.db.disciplinaryIncidents || []).find((i) => i.id === id);
    if (!current) return { success: false, error: 'Incidente não encontrado.' };
    this.db.disciplinaryIncidents = (this.db.disciplinaryIncidents || []).map((i) =>
      i.id === id ? { ...i, status: 'arquivado' as IncidentStatus, archiveReason: reason?.trim() || i.archiveReason } : i
    );
    this.notify();
    return { success: true };
  }

  public deleteDisciplinaryIncident(id: string): { success: boolean; error?: string } {
    const target = (this.db.disciplinaryIncidents || []).find((i) => i.id === id);
    if (!target) return { success: false, error: 'Incidente não encontrado.' };
    this.db.disciplinaryIncidents = (this.db.disciplinaryIncidents || []).filter((i) => i.id !== id);
    this.healthSafetyAudit('Eliminação de Incidente Disciplinar', `Incidente "${target.code}" eliminado.`, '#b91c1c');
    this.notify();
    return { success: true };
  }

  // ---------- 3. Autorizações de Recolha ----------

  public getPickupAuthorizations(): PickupAuthorization[] {
    return this.db.pickupAuthorizations || [];
  }

  public getPickupRecords(): PickupRecord[] {
    return this.db.pickupRecords || [];
  }

  public savePickupAuthorization(
    input: { id?: string } & PickupAuthorizationFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; authorization?: PickupAuthorization } {
    const errors = validatePickupAuthorization(input);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };
    const student = (this.db.students || []).find((s) => s.id === input.studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.pickupAuthorizations || []).find((a) => a.id === input.id);
      if (!current) return { success: false, error: 'Autorização não encontrada.' };
      const updated: PickupAuthorization = {
        ...current,
        kind: input.kind,
        personName: input.personName.trim(),
        relation: input.relation,
        relationOther: input.relation === 'outro' ? input.relationOther?.trim() : undefined,
        phone: input.phone.trim(),
        documentNumber: input.documentNumber.trim().toUpperCase(),
        grantedBy: input.grantedBy.trim(),
        grantedVia: input.grantedVia as PickupAuthorization['grantedVia'],
        validFrom: input.validFrom,
        validUntil: input.validUntil || undefined,
        notes: input.notes?.trim() || undefined,
        updatedAt: now,
        updatedBy: this.currentActorName()
      };
      this.db.pickupAuthorizations = (this.db.pickupAuthorizations || []).map((a) => (a.id === input.id ? updated : a));
      this.notify();
      return { success: true, authorization: updated };
    }

    const created: PickupAuthorization = {
      id: this.newHealthSafetyId('rec'),
      code: generatePickupAuthorizationCode((this.db.pickupAuthorizations || []).map((a) => a.code)),
      studentId: input.studentId,
      studentName: student.name,
      studentProcNumber: student.procNumber,
      className: student.className,
      kind: input.kind,
      personName: input.personName.trim(),
      relation: input.relation,
      relationOther: input.relation === 'outro' ? input.relationOther?.trim() : undefined,
      phone: input.phone.trim(),
      documentNumber: input.documentNumber.trim().toUpperCase(),
      grantedBy: input.grantedBy.trim(),
      grantedVia: input.grantedVia as PickupAuthorization['grantedVia'],
      validFrom: input.validFrom,
      validUntil: input.validUntil || undefined,
      status: 'ativa',
      notes: input.notes?.trim() || undefined,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.pickupAuthorizations = [created, ...(this.db.pickupAuthorizations || [])];
    this.healthSafetyAudit(
      created.kind === 'proibida' ? 'Registo de Restrição de Recolha' : 'Registo de Autorização de Recolha',
      `${created.kind === 'proibida' ? 'Restrição' : 'Autorização'} para ${created.personName} recolher ${created.studentName} (${created.code}) registada.`,
      created.kind === 'proibida' ? '#b91c1c' : '#0b1f3a'
    );
    this.notify();
    return { success: true, authorization: created };
  }

  public changePickupAuthorizationStatus(
    id: string,
    status: PickupAuthorization['status'],
    reason?: string
  ): { success: boolean; error?: string } {
    const current = (this.db.pickupAuthorizations || []).find((a) => a.id === id);
    if (!current) return { success: false, error: 'Autorização não encontrada.' };
    this.db.pickupAuthorizations = (this.db.pickupAuthorizations || []).map((a) =>
      a.id === id
        ? { ...a, status, statusReason: reason?.trim() || undefined, updatedAt: new Date().toISOString(), updatedBy: this.currentActorName() }
        : a
    );
    this.notify();
    return { success: true };
  }

  public deletePickupAuthorization(id: string): { success: boolean; error?: string } {
    const target = (this.db.pickupAuthorizations || []).find((a) => a.id === id);
    if (!target) return { success: false, error: 'Autorização não encontrada.' };
    this.db.pickupAuthorizations = (this.db.pickupAuthorizations || []).filter((a) => a.id !== id);
    this.notify();
    return { success: true };
  }

  /** Regista, à porta, uma saída/recolha efetuada ou uma tentativa recusada. */
  public registerPickup(input: {
    studentId: string;
    date: string;
    time: string;
    authorizationId?: string;
    personName: string;
    personRelation: string;
    personDocument: string;
    reason: PickupReason;
    reasonOther?: string;
    guardianConfirmedBy?: string;
    documentVerified: boolean;
    notes?: string;
  }): { success: boolean; error?: string; record?: PickupRecord } {
    const student = (this.db.students || []).find((s) => s.id === input.studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };
    if (!input.personName.trim()) return { success: false, error: 'Indique o nome de quem recolheu o aluno.' };
    if (input.reason === 'outro' && !(input.reasonOther || '').trim()) {
      return { success: false, error: 'Descreva o motivo quando escolher "Outro".' };
    }

    const forbidden = isPersonForbiddenForStudent(
      this.db.pickupAuthorizations || [],
      input.studentId,
      input.personDocument,
      input.date
    );
    const now = new Date().toISOString();

    if (forbidden) {
      const record: PickupRecord = {
        id: this.newHealthSafetyId('pkp'),
        date: input.date,
        time: input.time,
        studentId: student.id,
        studentName: student.name,
        studentProcNumber: student.procNumber,
        className: student.className,
        personName: input.personName.trim(),
        personRelation: input.personRelation,
        personDocument: input.personDocument.trim().toUpperCase(),
        reason: input.reason,
        reasonOther: input.reason === 'outro' ? input.reasonOther?.trim() : undefined,
        outcome: 'recusada',
        refusalReason: `Pessoa com restrição ativa de recolha para este aluno (autorização ${forbidden.code}).`,
        documentVerified: input.documentVerified,
        notes: input.notes?.trim() || undefined,
        registeredBy: this.currentActorName(),
        createdAt: now
      };
      this.db.pickupRecords = [record, ...(this.db.pickupRecords || [])];
      this.healthSafetyAudit(
        'Recolha Recusada',
        `Recolha de ${student.name} por ${record.personName} recusada — pessoa com restrição ativa (${forbidden.code}).`,
        '#b91c1c'
      );
      this.notify();
      return { success: true, record };
    }

    const record: PickupRecord = {
      id: this.newHealthSafetyId('pkp'),
      date: input.date,
      time: input.time,
      studentId: student.id,
      studentName: student.name,
      studentProcNumber: student.procNumber,
      className: student.className,
      authorizationId: input.authorizationId,
      personName: input.personName.trim(),
      personRelation: input.personRelation,
      personDocument: input.personDocument.trim().toUpperCase(),
      reason: input.reason,
      reasonOther: input.reason === 'outro' ? input.reasonOther?.trim() : undefined,
      outcome: 'entregue',
      guardianConfirmedBy: input.guardianConfirmedBy?.trim() || undefined,
      documentVerified: input.documentVerified,
      notes: input.notes?.trim() || undefined,
      registeredBy: this.currentActorName(),
      createdAt: now
    };
    this.db.pickupRecords = [record, ...(this.db.pickupRecords || [])];
    this.notify();
    return { success: true, record };
  }

  // ------------------------------------------------------------------
  // Serviços 4 — Vínculo / Desvínculo de Filhos
  //
  // O que cada Encarregado vê no Portal Online é decidido por
  // `resolveGuardianChildren` (utils/guardianLinks.ts): vínculos ativos +
  // acesso herdado da ficha do aluno, exceto os pares desvinculados.
  // ------------------------------------------------------------------
  private currentActorName(): string {
    return this.db.currentUser?.name?.trim() || 'Sistema';
  }

  public getGuardianLinks(): GuardianStudentLink[] {
    return this.db.guardianLinks || [];
  }

  public linkGuardianToStudent(input: {
    guardianUserId: string;
    studentId: string;
    relation: GuardianRelation;
    relationOther?: string;
    financialResponsible?: boolean;
    notes?: string;
  }): { success: boolean; error?: string; link?: GuardianStudentLink } {
    const guardian = (this.db.users || []).find((u) => u.id === input.guardianUserId && u.role === 'encarregado');
    if (!guardian) return { success: false, error: 'Conta de Encarregado de Educação não encontrada.' };
    const student = (this.db.students || []).find((s) => s.id === input.studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };
    if (student.status === 'transferred') {
      return { success: false, error: 'Este aluno foi transferido — não é possível vincular um novo Encarregado.' };
    }
    if (input.relation === 'outro' && !(input.relationOther || '').trim()) {
      return { success: false, error: 'Descreva o grau de parentesco / relação com o aluno.' };
    }

    const existing = resolveGuardianChildren(guardian, this.db.students || [], this.db.guardianLinks || []).find(
      (c) => c.student.id === student.id
    );
    if (existing?.source === 'vinculo') {
      return { success: false, error: `${guardian.name} já está vinculado(a) a ${student.name}.` };
    }

    const link: GuardianStudentLink = {
      id: `vin-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      guardianUserId: guardian.id,
      guardianName: guardian.name,
      guardianEmail: guardian.email || '',
      studentId: student.id,
      studentName: student.name,
      studentProcNumber: student.procNumber,
      relation: input.relation,
      relationOther: input.relation === 'outro' ? (input.relationOther || '').trim() : undefined,
      financialResponsible: !!input.financialResponsible,
      status: 'ativo',
      origin: 'manual',
      linkedAt: new Date().toISOString(),
      linkedBy: this.currentActorName(),
      notes: (input.notes || '').trim() || undefined
    };
    this.db.guardianLinks = [link, ...(this.db.guardianLinks || [])];
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: 'Secretaria',
      action: 'Vínculo de Educando',
      details: `${guardian.name} vinculado(a) ao aluno ${student.name} (nº ${student.procNumber}).`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, link };
  }

  public unlinkGuardianFromStudent(input: {
    guardianUserId: string;
    studentId: string;
    reason: GuardianUnlinkReason;
    notes?: string;
  }): { success: boolean; error?: string } {
    const guardian = (this.db.users || []).find((u) => u.id === input.guardianUserId && u.role === 'encarregado');
    if (!guardian) return { success: false, error: 'Conta de Encarregado de Educação não encontrada.' };
    const student = (this.db.students || []).find((s) => s.id === input.studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };
    const notes = (input.notes || '').trim();
    if (input.reason === 'outro' && !notes) {
      return { success: false, error: 'Descreva o motivo do desvínculo.' };
    }

    const current = resolveGuardianChildren(guardian, this.db.students || [], this.db.guardianLinks || []).find(
      (c) => c.student.id === student.id
    );
    if (!current) {
      return { success: false, error: `${guardian.name} já não tem acesso a ${student.name}.` };
    }

    const now = new Date().toISOString();
    const actor = this.currentActorName();
    if (current.link) {
      // Vínculo registado: passa a "desvinculado" (o registo fica como histórico).
      this.db.guardianLinks = (this.db.guardianLinks || []).map((l) =>
        l.id === current.link!.id
          ? { ...l, status: 'desvinculado', unlinkedAt: now, unlinkedBy: actor, unlinkReason: input.reason, unlinkNotes: notes || undefined }
          : l
      );
    } else {
      // Acesso herdado da ficha: não há vínculo a fechar, por isso regista-se um
      // desvínculo que BLOQUEIA o acesso implícito (senão a ficha continuava a abri-lo).
      const blocked: GuardianStudentLink = {
        id: `vin-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        guardianUserId: guardian.id,
        guardianName: guardian.name,
        guardianEmail: guardian.email || '',
        studentId: student.id,
        studentName: student.name,
        studentProcNumber: student.procNumber,
        relation: relationFromText(student.guardianRelation),
        financialResponsible: false,
        status: 'desvinculado',
        origin: 'ficha',
        linkedAt: now,
        linkedBy: actor,
        unlinkedAt: now,
        unlinkedBy: actor,
        unlinkReason: input.reason,
        unlinkNotes: notes || undefined
      };
      this.db.guardianLinks = [blocked, ...(this.db.guardianLinks || [])];
    }

    this.addAuditLog({
      userName: actor,
      userRole: 'Secretaria',
      action: 'Desvínculo de Educando',
      details: `${guardian.name} desvinculado(a) do aluno ${student.name} (nº ${student.procNumber}).`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#7a0c0c'
    });
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Serviços 5 — Pré-Matrícula / Admissões
  // ------------------------------------------------------------------
  public getAdmissions(): Admission[] {
    return this.db.admissions || [];
  }

  public addAdmission(
    input: Omit<Admission, 'id' | 'code' | 'status' | 'history' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy' | 'documents'> & {
      documents?: AdmissionDocument[];
    }
  ): { success: boolean; error?: string; errors?: string[]; admission?: Admission } {
    const errors = validateAdmission({
      name: input.name,
      birthDate: input.birthDate,
      desiredGrade: input.desiredGrade,
      guardianName: input.guardianName,
      guardianPhone: input.guardianPhone,
      email: input.email,
      guardianEmail: input.guardianEmail,
      assessmentScore: input.assessmentScore
    });
    if (!input.academicYear?.trim()) errors.push('Indique o ano letivo da candidatura.');
    if (errors.length > 0) return { success: false, error: errors[0], errors };

    const dupStudent = findDuplicateStudent(this.db.students || [], input);
    if (dupStudent) {
      return {
        success: false,
        error: `${dupStudent.name} já está cadastrado(a) como aluno (nº ${dupStudent.procNumber}). Para um aluno da escola, use "Matrículas".`
      };
    }
    const dupAdmission = findDuplicateAdmission(this.db.admissions || [], input);
    if (dupAdmission) {
      return {
        success: false,
        error: `Já existe a candidatura ${dupAdmission.code} (${ADMISSION_STATUS_META[dupAdmission.status].label}) para este candidato neste ano letivo.`
      };
    }

    const now = new Date().toISOString();
    const actor = this.currentActorName();
    const created: Admission = {
      ...input,
      name: input.name.trim(),
      guardianName: input.guardianName.trim(),
      guardianPhone: input.guardianPhone.trim(),
      id: `adm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateAdmissionCode(input.academicYear, (this.db.admissions || []).map((a) => a.code)),
      status: 'recebida',
      documents: input.documents && input.documents.length > 0 ? input.documents : emptyDocuments(),
      history: [{ at: now, by: actor, text: 'Candidatura registada.' }],
      createdAt: now,
      createdBy: actor
    };
    this.db.admissions = [created, ...(this.db.admissions || [])];
    this.addAuditLog({
      userName: actor,
      userRole: 'Secretaria',
      action: 'Nova Candidatura (Pré-Matrícula)',
      details: `Candidatura ${created.code} registada para ${created.name} — ${created.desiredGrade}.`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, admission: created };
  }

  public updateAdmission(
    id: string,
    updates: Partial<Omit<Admission, 'id' | 'code' | 'status' | 'history' | 'createdAt' | 'createdBy' | 'updatedAt' | 'updatedBy'>>
  ): { success: boolean; error?: string; errors?: string[] } {
    const current = (this.db.admissions || []).find((a) => a.id === id);
    if (!current) return { success: false, error: 'Candidatura não encontrada.' };
    if (current.status === 'convertida') {
      return { success: false, error: 'Esta candidatura já foi convertida em aluno — edite a ficha em "Alunos".' };
    }
    const merged: Admission = { ...current, ...updates };
    const errors = validateAdmission({
      name: merged.name,
      birthDate: merged.birthDate,
      desiredGrade: merged.desiredGrade,
      guardianName: merged.guardianName,
      guardianPhone: merged.guardianPhone,
      email: merged.email,
      guardianEmail: merged.guardianEmail,
      assessmentScore: merged.assessmentScore
    });
    if (errors.length > 0) return { success: false, error: errors[0], errors };

    const dupAdmission = findDuplicateAdmission(this.db.admissions || [], merged, id);
    if (dupAdmission) {
      return { success: false, error: `Já existe outra candidatura (${dupAdmission.code}) para este candidato neste ano letivo.` };
    }
    const dupStudent = findDuplicateStudent(this.db.students || [], merged);
    if (dupStudent) {
      return { success: false, error: `${dupStudent.name} já está cadastrado(a) como aluno (nº ${dupStudent.procNumber}).` };
    }

    this.db.admissions = (this.db.admissions || []).map((a) =>
      a.id === id
        ? { ...merged, name: merged.name.trim(), updatedAt: new Date().toISOString(), updatedBy: this.currentActorName() }
        : a
    );
    this.notify();
    return { success: true };
  }

  public changeAdmissionStatus(
    id: string,
    to: AdmissionStatus,
    options: {
      reason?: string;
      /** Aprovar mesmo sem vagas livres na classe (decisão consciente da Direção). */
      allowOverCapacity?: boolean;
      /** Agendamento da avaliação, exigido ao passar para "Avaliação Agendada". */
      assessment?: { type: AdmissionAssessmentType; date: string };
    } = {}
  ): { success: boolean; error?: string; needsCapacityOverride?: boolean } {
    const current = (this.db.admissions || []).find((a) => a.id === id);
    if (!current) return { success: false, error: 'Candidatura não encontrada.' };
    if (to === 'convertida') {
      return { success: false, error: 'A conversão em aluno faz-se com o botão "Converter em Aluno".' };
    }
    if (!canTransition(current.status, to)) {
      return {
        success: false,
        error: `Não é possível passar de "${ADMISSION_STATUS_META[current.status].label}" para "${ADMISSION_STATUS_META[to].label}".`
      };
    }
    const reason = (options.reason || '').trim();
    if (to === 'rejeitada' && !reason) {
      return { success: false, error: 'Indique o motivo da rejeição — fica registado na candidatura.' };
    }

    let assessmentType = current.assessmentType;
    let assessmentDate = current.assessmentDate;
    if (to === 'avaliacao_agendada') {
      assessmentType = options.assessment?.type || assessmentType;
      assessmentDate = options.assessment?.date || assessmentDate;
      if (!assessmentType || !assessmentDate) {
        return { success: false, error: 'Indique o tipo e a data da avaliação de admissão.' };
      }
    }

    if (to === 'aprovada') {
      const vacancies = computeVacancies(
        this.db.classes || [],
        this.db.admissions || [],
        current.desiredGrade,
        current.academicYear,
        current.id
      );
      if (vacancies.classesCount > 0 && vacancies.available <= 0 && !options.allowOverCapacity) {
        return {
          success: false,
          needsCapacityOverride: true,
          error: `Não há vagas livres em ${current.desiredGrade} para ${current.academicYear} (capacidade ${vacancies.capacity}, ocupadas ${vacancies.enrolled}, já prometidas ${vacancies.reserved}).`
        };
      }
    }

    const now = new Date().toISOString();
    const actor = this.currentActorName();
    const isDecision = DECISION_STATUSES.includes(to);
    const reopening = to === 'em_analise' && ['rejeitada', 'desistiu', 'lista_espera', 'avaliacao_agendada'].includes(current.status);

    this.db.admissions = (this.db.admissions || []).map((a) => {
      if (a.id !== id) return a;
      const next: Admission = {
        ...a,
        status: to,
        assessmentType,
        assessmentDate,
        updatedAt: now,
        updatedBy: actor,
        history: [
          ...(a.history || []),
          {
            at: now,
            by: actor,
            text: `${ADMISSION_STATUS_META[a.status].label} → ${ADMISSION_STATUS_META[to].label}${reason ? ` — ${reason}` : ''}`
          }
        ]
      };
      if (isDecision) {
        next.decidedBy = actor;
        next.decidedAt = now;
        next.decisionNotes = reason || undefined;
      } else if (reopening) {
        next.decidedBy = undefined;
        next.decidedAt = undefined;
        next.decisionNotes = undefined;
      }
      return next;
    });

    this.addAuditLog({
      userName: actor,
      userRole: 'Secretaria',
      action: 'Decisão de Admissão',
      details: `Candidatura ${current.code} (${current.name}): ${ADMISSION_STATUS_META[current.status].label} → ${ADMISSION_STATUS_META[to].label}${reason ? ` — ${reason}` : ''}.`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: to === 'rejeitada' ? '#7a0c0c' : '#0b1f3a'
    });
    this.notify();
    return { success: true };
  }

  /**
   * Cria a ficha do Aluno (estado "pendente") a partir de uma candidatura
   * aprovada. Turma, curso, propina e situação financeira ficam vazios de
   * propósito: pertencem à Matrícula, que é o passo seguinte.
   */
  public convertAdmissionToStudent(id: string): { success: boolean; error?: string; student?: Student } {
    const adm = (this.db.admissions || []).find((a) => a.id === id);
    if (!adm) return { success: false, error: 'Candidatura não encontrada.' };
    if (adm.status !== 'aprovada') {
      return { success: false, error: 'Só candidaturas aprovadas podem ser convertidas em aluno.' };
    }
    const dup = findDuplicateStudent(this.db.students || [], adm);
    if (dup) {
      return { success: false, error: `${dup.name} já está cadastrado(a) como aluno (nº ${dup.procNumber}). Confirme os dados antes de converter.` };
    }

    const payload = admissionToStudentPayload(adm);
    const delivered = (key: string) => (adm.documents || []).some((d) => d.key === key && d.delivered);
    const student = this.addStudent({
      ...payload,
      email: payload.email,
      classId: '',
      className: '',
      section: '',
      cycle: '',
      grade: '',
      monthlyTuitionKz: 0,
      financialStatus: 'regular',
      docBiCopy: delivered('bi_candidato') ? 'Entregue' : 'Pendente',
      docCertificate: delivered('certificado') ? 'Entregue' : 'Pendente',
      additionalDocs: [],
      status: 'pending',
      unexcusedAbsences: 0,
      excusedAbsences: 0,
      isTuitionPaidCurrentMonth: true,
      disciplineGrades: []
    } as any);

    const now = new Date().toISOString();
    const actor = this.currentActorName();
    this.db.admissions = (this.db.admissions || []).map((a) =>
      a.id === id
        ? {
            ...a,
            status: 'convertida' as AdmissionStatus,
            studentId: student.id,
            convertedAt: now,
            convertedBy: actor,
            updatedAt: now,
            updatedBy: actor,
            history: [
              ...(a.history || []),
              { at: now, by: actor, text: `Convertida em aluno — ficha criada (nº ${student.procNumber}).` }
            ]
          }
        : a
    );
    this.addAuditLog({
      userName: actor,
      userRole: 'Secretaria',
      action: 'Admissão Convertida em Aluno',
      details: `Candidatura ${adm.code} convertida na ficha de ${student.name} (nº ${student.procNumber}); segue para Matrículas.`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, student };
  }

  public deleteAdmission(id: string): { success: boolean; error?: string } {
    const current = (this.db.admissions || []).find((a) => a.id === id);
    if (!current) return { success: false, error: 'Candidatura não encontrada.' };
    if (current.status === 'convertida') {
      return { success: false, error: 'Uma candidatura convertida em aluno não pode ser eliminada (faz parte do histórico do aluno).' };
    }
    this.db.admissions = (this.db.admissions || []).filter((a) => a.id !== id);
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: 'Secretaria',
      action: 'Candidatura Eliminada',
      details: `Candidatura ${current.code} (${current.name}) eliminada.`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#7a0c0c'
    });
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Serviços 6 — Banco de Questões / Exames
  //
  // `access` traz o que o UTILIZADOR PODE FAZER (vem da matriz de permissões,
  // lida na vista). A base de dados só garante as regras que não dependem do
  // perfil: só o autor (ou quem gere tudo) edita, aprovar exige `canApprove`,
  // provas publicadas ficam congeladas.
  // ------------------------------------------------------------------
  public getQuestions(): ExamQuestion[] {
    return this.db.questions || [];
  }

  public getExamPapers(): ExamPaper[] {
    return this.db.examPapers || [];
  }

  public addQuestion(
    input: Omit<
      ExamQuestion,
      'id' | 'code' | 'status' | 'authorId' | 'authorName' | 'createdAt' | 'updatedAt' | 'approvedBy' | 'approvedAt'
    >,
    access: { canApprove: boolean; approveNow?: boolean }
  ): { success: boolean; error?: string; errors?: string[]; question?: ExamQuestion } {
    const normalized = normalizeQuestionFields(input);
    const errors = validateQuestion(normalized);
    if (errors.length > 0) return { success: false, error: errors[0], errors };

    const now = new Date().toISOString();
    const actor = this.db.currentUser;
    const approve = !!access.approveNow && access.canApprove;
    const created: ExamQuestion = {
      ...normalized,
      id: `qst-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateQuestionCode((this.db.questions || []).map((q) => q.code)),
      status: approve ? 'aprovada' : 'rascunho',
      authorId: actor?.id || '',
      authorName: this.currentActorName(),
      createdAt: now,
      approvedBy: approve ? this.currentActorName() : undefined,
      approvedAt: approve ? now : undefined
    };
    this.db.questions = [created, ...(this.db.questions || [])];
    this.notify();
    return { success: true, question: created };
  }

  public updateQuestion(
    id: string,
    input: Omit<
      ExamQuestion,
      'id' | 'code' | 'status' | 'authorId' | 'authorName' | 'createdAt' | 'updatedAt' | 'approvedBy' | 'approvedAt'
    >,
    access: { canManageAll: boolean; canApprove: boolean }
  ): { success: boolean; error?: string; errors?: string[] } {
    const current = (this.db.questions || []).find((q) => q.id === id);
    if (!current) return { success: false, error: 'Questão não encontrada.' };
    if (current.authorId !== this.db.currentUser?.id && !access.canManageAll) {
      return { success: false, error: 'Só o autor da questão (ou a Direção) a pode editar.' };
    }
    const normalized = normalizeQuestionFields(input);
    const errors = validateQuestion(normalized);
    if (errors.length > 0) return { success: false, error: errors[0], errors };

    // Uma questão aprovada que o autor volta a editar deixa de estar aprovada:
    // a versão nova ainda ninguém a reviu.
    const loseApproval = current.status === 'aprovada' && !access.canApprove;
    this.db.questions = (this.db.questions || []).map((q) =>
      q.id === id
        ? {
            ...q,
            ...normalized,
            status: loseApproval ? 'rascunho' : q.status,
            approvedBy: loseApproval ? undefined : q.approvedBy,
            approvedAt: loseApproval ? undefined : q.approvedAt,
            updatedAt: new Date().toISOString()
          }
        : q
    );
    this.notify();
    return { success: true };
  }

  public setQuestionStatus(
    id: string,
    status: QuestionStatus,
    access: { canManageAll: boolean; canApprove: boolean }
  ): { success: boolean; error?: string } {
    const current = (this.db.questions || []).find((q) => q.id === id);
    if (!current) return { success: false, error: 'Questão não encontrada.' };
    const isAuthor = current.authorId === this.db.currentUser?.id;
    if (status === 'aprovada') {
      if (!access.canApprove) return { success: false, error: 'Não tem permissão para aprovar questões.' };
      const errors = validateQuestion(current as any);
      if (errors.length > 0) return { success: false, error: errors[0] };
    } else if (!isAuthor && !access.canManageAll) {
      return { success: false, error: 'Só o autor da questão (ou a Direção) altera o seu estado.' };
    }
    const now = new Date().toISOString();
    const approving = status === 'aprovada';
    this.db.questions = (this.db.questions || []).map((q) =>
      q.id === id
        ? {
            ...q,
            status,
            updatedAt: now,
            approvedBy: approving ? this.currentActorName() : status === 'rascunho' ? undefined : q.approvedBy,
            approvedAt: approving ? now : status === 'rascunho' ? undefined : q.approvedAt
          }
        : q
    );
    this.notify();
    return { success: true };
  }

  public duplicateQuestion(id: string): { success: boolean; error?: string; question?: ExamQuestion } {
    const current = (this.db.questions || []).find((q) => q.id === id);
    if (!current) return { success: false, error: 'Questão não encontrada.' };
    const now = new Date().toISOString();
    const copy: ExamQuestion = {
      ...current,
      options: current.options?.map((o) => ({ ...o })),
      id: `qst-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateQuestionCode((this.db.questions || []).map((q) => q.code)),
      status: 'rascunho',
      authorId: this.db.currentUser?.id || '',
      authorName: this.currentActorName(),
      createdAt: now,
      updatedAt: undefined,
      approvedBy: undefined,
      approvedAt: undefined
    };
    this.db.questions = [copy, ...(this.db.questions || [])];
    this.notify();
    return { success: true, question: copy };
  }

  public deleteQuestion(id: string, access: { canManageAll: boolean }): { success: boolean; error?: string } {
    const current = (this.db.questions || []).find((q) => q.id === id);
    if (!current) return { success: false, error: 'Questão não encontrada.' };
    if (current.authorId !== this.db.currentUser?.id && !access.canManageAll) {
      return { success: false, error: 'Só o autor da questão (ou a Direção) a pode eliminar.' };
    }
    const usage = countQuestionUsage(id, this.db.examPapers || []);
    if (usage > 0) {
      return {
        success: false,
        error: `Esta questão está em ${usage} prova(s). Arquive-a em vez de a eliminar — as provas publicadas mantêm a sua cópia.`
      };
    }
    this.db.questions = (this.db.questions || []).filter((q) => q.id !== id);
    this.notify();
    return { success: true };
  }

  public saveExamPaper(
    input: {
      id?: string;
      title: string;
      subjectName: string;
      grade: string;
      type: ExamPaperType;
      academicYear: string;
      trimester: '1' | '2' | '3';
      examDate?: string;
      durationMinutes: number;
      targetPoints: number;
      instructions?: string;
      items: ExamPaperItem[];
    },
    access: { canManageAll: boolean }
  ): { success: boolean; error?: string; paper?: ExamPaper } {
    const title = input.title.trim();
    if (!title) return { success: false, error: 'Indique o título da prova.' };
    if (!input.subjectName.trim() || !input.grade.trim()) {
      return { success: false, error: 'Indique a disciplina e a classe da prova.' };
    }
    if (!Number.isFinite(input.targetPoints) || input.targetPoints <= 0) {
      return { success: false, error: 'A cotação total da prova deve ser superior a 0.' };
    }
    const seen = new Set<string>();
    const items: ExamPaperItem[] = [];
    for (const item of input.items) {
      if (seen.has(item.questionId)) continue;
      seen.add(item.questionId);
      items.push({ questionId: item.questionId, points: Number(item.points) || 0 });
    }

    const now = new Date().toISOString();
    const fields = {
      title,
      subjectName: input.subjectName.trim(),
      grade: input.grade.trim(),
      type: input.type,
      academicYear: input.academicYear,
      trimester: input.trimester || '1',
      examDate: input.examDate || undefined,
      durationMinutes: Number(input.durationMinutes) || 0,
      targetPoints: input.targetPoints,
      instructions: (input.instructions || '').trim() || undefined,
      items
    };

    if (input.id) {
      const current = (this.db.examPapers || []).find((p) => p.id === input.id);
      if (!current) return { success: false, error: 'Prova não encontrada.' };
      if (current.status !== 'rascunho') {
        return { success: false, error: 'Uma prova publicada não se edita — duplique-a para criar uma nova versão.' };
      }
      if (current.authorId !== this.db.currentUser?.id && !access.canManageAll) {
        return { success: false, error: 'Só o autor da prova (ou a Direção) a pode editar.' };
      }
      const updated: ExamPaper = { ...current, ...fields, updatedAt: now };
      this.db.examPapers = (this.db.examPapers || []).map((p) => (p.id === input.id ? updated : p));
      this.notify();
      return { success: true, paper: updated };
    }

    const created: ExamPaper = {
      ...fields,
      id: `prv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateExamPaperCode(input.academicYear, (this.db.examPapers || []).map((p) => p.code)),
      status: 'rascunho',
      authorId: this.db.currentUser?.id || '',
      authorName: this.currentActorName(),
      createdAt: now
    };
    this.db.examPapers = [created, ...(this.db.examPapers || [])];
    this.notify();
    return { success: true, paper: created };
  }

  public publishExamPaper(
    id: string,
    access: { canManageAll: boolean; canApprove: boolean }
  ): { success: boolean; error?: string; problems?: string[] } {
    const paper = (this.db.examPapers || []).find((p) => p.id === id);
    if (!paper) return { success: false, error: 'Prova não encontrada.' };
    if (paper.status !== 'rascunho') return { success: false, error: 'Esta prova já foi publicada.' };
    if (paper.authorId !== this.db.currentUser?.id && !access.canManageAll) {
      return { success: false, error: 'Só o autor da prova (ou a Direção) a pode publicar.' };
    }
    if (paperTypeNeedsApproval(paper.type) && !access.canApprove) {
      return {
        success: false,
        error: 'Exames finais, de recurso e de acesso só podem ser publicados pela Direção / Administração.'
      };
    }
    const byId = new Map((this.db.questions || []).map((q) => [q.id, q]));
    const problems = validatePaperForPublish(paper, byId);
    if (problems.length > 0) return { success: false, error: problems[0], problems };

    const now = new Date().toISOString();
    this.db.examPapers = (this.db.examPapers || []).map((p) =>
      p.id === id
        ? {
            ...p,
            status: 'publicada' as const,
            publishedAt: now,
            publishedBy: this.currentActorName(),
            updatedAt: now,
            // Cópia congelada: editar o banco depois não altera esta prova.
            items: p.items.map((i) => ({ ...i, snapshot: JSON.parse(JSON.stringify(byId.get(i.questionId))) }))
          }
        : p
    );
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: 'Docente',
      action: 'Prova Publicada',
      details: `Prova ${paper.code} — ${paper.title} (${paper.subjectName}, ${paper.grade}) publicada com ${sumPoints(paper.items)} valores.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true };
  }

  public archiveExamPaper(id: string, access: { canManageAll: boolean }): { success: boolean; error?: string } {
    const paper = (this.db.examPapers || []).find((p) => p.id === id);
    if (!paper) return { success: false, error: 'Prova não encontrada.' };
    if (paper.authorId !== this.db.currentUser?.id && !access.canManageAll) {
      return { success: false, error: 'Só o autor da prova (ou a Direção) a pode arquivar.' };
    }
    this.db.examPapers = (this.db.examPapers || []).map((p) =>
      p.id === id ? { ...p, status: 'arquivada' as const, updatedAt: new Date().toISOString() } : p
    );
    this.notify();
    return { success: true };
  }

  /** Cria um novo rascunho com as mesmas questões (versões atuais do banco). */
  public duplicateExamPaper(id: string): { success: boolean; error?: string; paper?: ExamPaper } {
    const paper = (this.db.examPapers || []).find((p) => p.id === id);
    if (!paper) return { success: false, error: 'Prova não encontrada.' };
    const now = new Date().toISOString();
    const copy: ExamPaper = {
      ...paper,
      id: `prv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateExamPaperCode(paper.academicYear, (this.db.examPapers || []).map((p) => p.code)),
      title: `${paper.title} (cópia)`,
      status: 'rascunho',
      items: paper.items.map((i) => ({ questionId: i.questionId, points: i.points })),
      authorId: this.db.currentUser?.id || '',
      authorName: this.currentActorName(),
      createdAt: now,
      updatedAt: undefined,
      publishedAt: undefined,
      publishedBy: undefined
    };
    this.db.examPapers = [copy, ...(this.db.examPapers || [])];
    this.notify();
    return { success: true, paper: copy };
  }

  public deleteExamPaper(id: string, access: { canManageAll: boolean }): { success: boolean; error?: string } {
    const paper = (this.db.examPapers || []).find((p) => p.id === id);
    if (!paper) return { success: false, error: 'Prova não encontrada.' };
    if (paper.status === 'publicada') {
      return { success: false, error: 'Uma prova publicada não se elimina — arquive-a.' };
    }
    if (paper.authorId !== this.db.currentUser?.id && !access.canManageAll) {
      return { success: false, error: 'Só o autor da prova (ou a Direção) a pode eliminar.' };
    }
    this.db.examPapers = (this.db.examPapers || []).filter((p) => p.id !== id);
    this.notify();
    return { success: true };
  }

  // =========================================================================
  // SERVIÇOS → 7. PLANO CURRICULAR & CONTEÚDOS
  // =========================================================================

  public getCurriculumPlans(): CurriculumPlan[] {
    return this.db.curriculumPlans || [];
  }

  public saveCurriculumPlan(
    input: { id?: string } & Parameters<typeof normalizePlanFields>[0]
  ): { success: boolean; error?: string; errors?: string[]; plan?: CurriculumPlan } {
    const fields = normalizePlanFields(input);
    const errors = validatePlan(fields);
    const dup = findDuplicatePlan(this.db.curriculumPlans || [], fields, input.id);
    if (dup) errors.push(`Já existe um plano ativo (${dup.code}) para ${fields.subjectName} em ${fields.grade} nesse ano letivo.`);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.curriculumPlans || []).find((p) => p.id === input.id);
      if (!current) return { success: false, error: 'Plano não encontrado.' };
      if (current.status !== 'rascunho') {
        return { success: false, error: 'Só um plano em Rascunho pode ter a estrutura editada. Reabra-o primeiro.' };
      }
      const updated: CurriculumPlan = { ...current, ...fields, updatedAt: now, updatedBy: this.currentActorName() };
      this.db.curriculumPlans = (this.db.curriculumPlans || []).map((p) => (p.id === input.id ? updated : p));
      this.notify();
      return { success: true, plan: updated };
    }

    const created: CurriculumPlan = {
      ...fields,
      id: `plc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generatePlanCode(fields.academicYear, (this.db.curriculumPlans || []).map((p) => p.code)),
      status: 'rascunho',
      authorId: this.db.currentUser?.id || '',
      authorName: this.currentActorName(),
      createdAt: now
    };
    this.db.curriculumPlans = [created, ...(this.db.curriculumPlans || [])];
    this.notify();
    return { success: true, plan: created };
  }

  public approveCurriculumPlan(id: string): { success: boolean; error?: string; errors?: string[] } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === id);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    if (plan.status !== 'rascunho') return { success: false, error: 'Só um plano em Rascunho pode ser aprovado.' };
    const errors = validatePlanForApproval(plan);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    this.db.curriculumPlans = (this.db.curriculumPlans || []).map((p) =>
      p.id === id ? { ...p, status: 'aprovado' as const, approvedBy: this.currentActorName(), approvedAt: now, updatedAt: now } : p
    );
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: 'Direção',
      action: 'Plano Curricular Aprovado',
      details: `Plano ${plan.code} — ${plan.subjectName} (${plan.grade}, ${plan.academicYear}) aprovado.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true };
  }

  /** Devolve o plano a Rascunho: mantém o que já foi leccionado, mas exige nova aprovação. */
  public reopenCurriculumPlan(id: string): { success: boolean; error?: string } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === id);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    if (plan.status !== 'aprovado') return { success: false, error: 'Só um plano Aprovado pode ser reaberto.' };
    this.db.curriculumPlans = (this.db.curriculumPlans || []).map((p) =>
      p.id === id
        ? { ...p, status: 'rascunho' as const, approvedBy: undefined, approvedAt: undefined, updatedAt: new Date().toISOString() }
        : p
    );
    this.notify();
    return { success: true };
  }

  public archiveCurriculumPlan(id: string): { success: boolean; error?: string } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === id);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    this.db.curriculumPlans = (this.db.curriculumPlans || []).map((p) =>
      p.id === id ? { ...p, status: 'arquivado' as const, updatedAt: new Date().toISOString() } : p
    );
    this.notify();
    return { success: true };
  }

  public deleteCurriculumPlan(id: string): { success: boolean; error?: string } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === id);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    if (plan.status !== 'rascunho') return { success: false, error: 'Só um plano em Rascunho pode ser eliminado — arquive os restantes.' };
    this.db.curriculumPlans = (this.db.curriculumPlans || []).filter((p) => p.id !== id);
    this.notify();
    return { success: true };
  }

  /** Regista o progresso leccionado de uma unidade (só com o plano Aprovado). */
  public registerUnitProgress(
    planId: string,
    unitId: string,
    fields: { deliveredLessons: number; notes?: string; completedAt?: string }
  ): { success: boolean; error?: string; plan?: CurriculumPlan } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === planId);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    if (plan.status !== 'aprovado') return { success: false, error: 'Só se regista progresso num plano Aprovado.' };
    const unit = plan.units.find((u) => u.id === unitId);
    if (!unit) return { success: false, error: 'Unidade não encontrada.' };
    const delivered = Math.max(0, Math.floor(Number(fields.deliveredLessons) || 0));
    if (delivered > unit.plannedLessons) {
      return { success: false, error: `Os tempos leccionados (${delivered}) excedem os previstos (${unit.plannedLessons}).` };
    }
    const now = new Date().toISOString();
    const updatedUnit: CurriculumUnit = {
      ...unit,
      deliveredLessons: delivered,
      notes: fields.notes !== undefined ? fields.notes || undefined : unit.notes,
      completedAt: delivered >= unit.plannedLessons && unit.plannedLessons > 0 ? fields.completedAt || now : undefined
    };
    const updated: CurriculumPlan = {
      ...plan,
      units: plan.units.map((u) => (u.id === unitId ? updatedUnit : u)),
      updatedAt: now,
      updatedBy: this.currentActorName()
    };
    this.db.curriculumPlans = (this.db.curriculumPlans || []).map((p) => (p.id === planId ? updated : p));
    this.notify();
    return { success: true, plan: updated };
  }

  /** Cópia da estrutura de um plano para outra classe / ano letivo. */
  public clonePlanTo(
    id: string,
    target: { academicYear: string; grade: string }
  ): { success: boolean; error?: string; errors?: string[]; plan?: CurriculumPlan } {
    const plan = (this.db.curriculumPlans || []).find((p) => p.id === id);
    if (!plan) return { success: false, error: 'Plano não encontrado.' };
    return this.saveCurriculumPlan(clonePlanInput(plan, target) as any);
  }

  // =========================================================================
  // SERVIÇOS → 8. ATIVIDADES EXTRACURRICULARES
  // =========================================================================

  public getExtracurricularActivities(): ExtracurricularActivity[] {
    return this.db.extracurricularActivities || [];
  }

  public saveExtracurricularActivity(
    input: { id?: string } & Parameters<typeof normalizeActivityFields>[0]
  ): { success: boolean; error?: string; errors?: string[]; activity?: ExtracurricularActivity } {
    const fields = normalizeActivityFields(input);
    const errors = validateActivity(fields);
    const others = this.db.extracurricularActivities || [];
    const conflicts = findResourceConflicts(fields, others, input.id);
    if (conflicts.length > 0) {
      errors.push(`O local ou o coordenador já estão ocupados nesse horário por outra atividade (${conflicts[0].other.code}).`);
    }
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = others.find((a) => a.id === input.id);
      if (!current) return { success: false, error: 'Atividade não encontrada.' };
      if (fields.capacity < activeEnrollments(current).length) {
        return { success: false, error: `Já há ${activeEnrollments(current).length} inscritos ativos — a capacidade não pode ser menor.` };
      }
      const updated: ExtracurricularActivity = { ...current, ...fields, updatedAt: now, updatedBy: this.currentActorName() };
      this.db.extracurricularActivities = others.map((a) => (a.id === input.id ? updated : a));
      this.notify();
      return { success: true, activity: updated };
    }

    const created: ExtracurricularActivity = {
      ...fields,
      id: `atv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateActivityCode(fields.academicYear, others.map((a) => a.code)),
      status: 'planeada',
      enrollments: [],
      sessions: [],
      createdAt: now,
      createdBy: this.currentActorName()
    };
    this.db.extracurricularActivities = [created, ...others];
    this.notify();
    return { success: true, activity: created };
  }

  public changeActivityStatus(id: string, to: ActivityStatus): { success: boolean; error?: string } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === id);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    if (!canTransitionActivity(activity.status, to)) {
      return { success: false, error: `Não é possível passar de «${activity.status}» para «${to}».` };
    }
    const now = new Date().toISOString();
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
      a.id === id ? { ...a, status: to, updatedAt: now, updatedBy: this.currentActorName() } : a
    );
    this.notify();
    return { success: true };
  }

  public deleteExtracurricularActivity(id: string): { success: boolean; error?: string } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === id);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    if ((activity.enrollments || []).length > 0) {
      return { success: false, error: 'Esta atividade já tem inscrições — cancele-a em vez de a eliminar.' };
    }
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).filter((a) => a.id !== id);
    this.notify();
    return { success: true };
  }

  public enrollStudentInActivity(
    activityId: string,
    studentId: string,
    opts: { guardianAuthorized: boolean }
  ): { success: boolean; error?: string; errors?: string[]; warnings?: string[]; waitlisted?: boolean } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === activityId);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    const student = (this.db.students || []).find((s) => s.id === studentId);
    const check = checkEnrollment(activity, student, { activities: this.db.extracurricularActivities || [], timetable: this.db.timetable });
    if (check.errors.length > 0) return { success: false, errors: check.errors, error: check.errors[0], warnings: check.warnings };
    if (!opts.guardianAuthorized) {
      return { success: false, error: 'É obrigatória a autorização do encarregado de educação.' };
    }

    const now = new Date().toISOString();
    const enrollment: ActivityEnrollment = {
      id: `enr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      studentId: student!.id,
      studentName: student!.name,
      studentProcNumber: student!.procNumber,
      className: student!.className,
      grade: student!.grade,
      status: check.waitlisted ? 'lista_espera' : 'ativa',
      enrolledAt: now,
      guardianAuthorized: true
    };
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
      a.id === activityId ? { ...a, enrollments: [...(a.enrollments || []), enrollment] } : a
    );
    this.notify();
    return { success: true, waitlisted: check.waitlisted, warnings: check.warnings };
  }

  /** Cancela a inscrição; se estava ativa e havia lista de espera, promove o primeiro da fila. */
  public cancelActivityEnrollment(
    activityId: string,
    enrollmentId: string,
    reason?: string
  ): { success: boolean; error?: string; promoted?: string } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === activityId);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    const enrollment = (activity.enrollments || []).find((e) => e.id === enrollmentId);
    if (!enrollment) return { success: false, error: 'Inscrição não encontrada.' };
    if (enrollment.status === 'cancelada') return { success: false, error: 'Esta inscrição já está cancelada.' };

    const wasActive = enrollment.status === 'ativa';
    const now = new Date().toISOString();
    let enrollments = (activity.enrollments || []).map((e) =>
      e.id === enrollmentId ? { ...e, status: 'cancelada' as const, cancelledAt: now, cancelledReason: reason || undefined } : e
    );
    let promoted = '';
    if (wasActive) {
      const nextInLine = waitlist({ ...activity, enrollments }).find((e) => e.id !== enrollmentId);
      if (nextInLine) {
        enrollments = enrollments.map((e) => (e.id === nextInLine.id ? { ...e, status: 'ativa' as const } : e));
        promoted = nextInLine.studentName;
      }
    }
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
      a.id === activityId ? { ...a, enrollments } : a
    );
    this.notify();
    return { success: true, promoted: promoted || undefined };
  }

  public saveActivitySession(
    activityId: string,
    input: { id?: string; date: string; notes?: string; entries: ActivityAttendanceEntry[] }
  ): { success: boolean; error?: string; errors?: string[]; session?: ActivitySession } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === activityId);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    const todayIso = new Date().toISOString().slice(0, 10);
    const errors = validateSessionDate(activity, input.date, todayIso, input.id);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (activity.sessions || []).find((s) => s.id === input.id);
      if (!current) return { success: false, error: 'Sessão não encontrada.' };
      const updated: ActivitySession = {
        ...current,
        date: input.date,
        notes: input.notes || undefined,
        entries: input.entries,
        updatedAt: now,
        updatedBy: this.currentActorName()
      };
      this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
        a.id === activityId ? { ...a, sessions: (a.sessions || []).map((s) => (s.id === input.id ? updated : s)) } : a
      );
      this.notify();
      return { success: true, session: updated };
    }

    const created: ActivitySession = {
      id: `ses-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      date: input.date,
      notes: input.notes || undefined,
      entries: input.entries,
      createdAt: now,
      createdBy: this.currentActorName()
    };
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
      a.id === activityId ? { ...a, sessions: [created, ...(a.sessions || [])] } : a
    );
    this.notify();
    return { success: true, session: created };
  }

  public deleteActivitySession(activityId: string, sessionId: string): { success: boolean; error?: string } {
    const activity = (this.db.extracurricularActivities || []).find((a) => a.id === activityId);
    if (!activity) return { success: false, error: 'Atividade não encontrada.' };
    this.db.extracurricularActivities = (this.db.extracurricularActivities || []).map((a) =>
      a.id === activityId ? { ...a, sessions: (a.sessions || []).filter((s) => s.id !== sessionId) } : a
    );
    this.notify();
    return { success: true };
  }

  // =========================================================================
  // SERVIÇOS → 9. REFEITÓRIO
  // =========================================================================

  public getCanteenMenus(): CanteenMenu[] {
    return this.db.canteenMenus || [];
  }

  public getCanteenSubscriptions(): CanteenSubscription[] {
    return this.db.canteenSubscriptions || [];
  }

  public getCanteenServiceRecords(): CanteenServiceRecord[] {
    return this.db.canteenServices || [];
  }

  public saveCanteenMenu(
    input: { id?: string } & Parameters<typeof normalizeMenuFields>[0]
  ): { success: boolean; error?: string; errors?: string[]; menu?: CanteenMenu } {
    const fields = normalizeMenuFields(input);
    const errors = validateMenu(fields, this.db.canteenMenus || [], input.id);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.canteenMenus || []).find((m) => m.id === input.id);
      if (!current) return { success: false, error: 'Ementa não encontrada.' };
      const updated: CanteenMenu = { ...current, ...fields, updatedAt: now, updatedBy: this.currentActorName() };
      this.db.canteenMenus = (this.db.canteenMenus || []).map((m) => (m.id === input.id ? updated : m));
      this.notify();
      return { success: true, menu: updated };
    }

    const created: CanteenMenu = {
      ...fields,
      id: `mnu-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.canteenMenus = [created, ...(this.db.canteenMenus || [])];
    this.notify();
    return { success: true, menu: created };
  }

  public deleteCanteenMenu(id: string): { success: boolean; error?: string } {
    const menu = (this.db.canteenMenus || []).find((m) => m.id === id);
    if (!menu) return { success: false, error: 'Ementa não encontrada.' };
    this.db.canteenMenus = (this.db.canteenMenus || []).filter((m) => m.id !== id);
    this.notify();
    return { success: true };
  }

  public saveCanteenSubscription(
    input: { id?: string } & Parameters<typeof normalizeSubscriptionFields>[0]
  ): { success: boolean; error?: string; errors?: string[]; subscription?: CanteenSubscription } {
    const fields = normalizeSubscriptionFields(input);
    const student = (this.db.students || []).find((s) => s.id === fields.studentId);
    const errors = validateSubscription(fields, student, this.db.canteenSubscriptions || [], input.id);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    if (input.id) {
      const current = (this.db.canteenSubscriptions || []).find((s) => s.id === input.id);
      if (!current) return { success: false, error: 'Inscrição não encontrada.' };
      const updated: CanteenSubscription = { ...current, ...fields, updatedAt: now, updatedBy: this.currentActorName() };
      this.db.canteenSubscriptions = (this.db.canteenSubscriptions || []).map((s) => (s.id === input.id ? updated : s));
      this.notify();
      return { success: true, subscription: updated };
    }

    const created: CanteenSubscription = {
      ...fields,
      id: `csb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: generateSubscriptionCode((this.db.canteenSubscriptions || []).map((s) => s.code)),
      studentName: student!.name,
      studentProcNumber: student!.procNumber,
      className: student!.className,
      status: 'ativa',
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.canteenSubscriptions = [created, ...(this.db.canteenSubscriptions || [])];
    this.notify();
    return { success: true, subscription: created };
  }

  public changeCanteenSubscriptionStatus(
    id: string,
    status: CanteenSubscription['status'],
    reason?: string
  ): { success: boolean; error?: string } {
    const sub = (this.db.canteenSubscriptions || []).find((s) => s.id === id);
    if (!sub) return { success: false, error: 'Inscrição não encontrada.' };
    this.db.canteenSubscriptions = (this.db.canteenSubscriptions || []).map((s) =>
      s.id === id
        ? { ...s, status, statusReason: reason || undefined, updatedAt: new Date().toISOString(), updatedBy: this.currentActorName() }
        : s
    );
    this.notify();
    return { success: true };
  }

  public deleteCanteenSubscription(id: string): { success: boolean; error?: string } {
    const sub = (this.db.canteenSubscriptions || []).find((s) => s.id === id);
    if (!sub) return { success: false, error: 'Inscrição não encontrada.' };
    this.db.canteenSubscriptions = (this.db.canteenSubscriptions || []).filter((s) => s.id !== id);
    this.notify();
    return { success: true };
  }

  /** Cria ou atualiza (nunca duplica) o registo de serviço de uma data/refeição. */
  public saveCanteenServiceRecord(
    date: string,
    mealType: MealType,
    entries: CanteenServiceEntry[]
  ): { success: boolean; error?: string; errors?: string[]; record?: CanteenServiceRecord } {
    const todayIso = new Date().toISOString().slice(0, 10);
    const errors = validateServiceRecord(date, mealType, entries, todayIso);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const now = new Date().toISOString();
    const existing = findServiceRecord(this.db.canteenServices || [], date, mealType);
    if (existing) {
      const updated: CanteenServiceRecord = { ...existing, entries, updatedAt: now, updatedBy: this.currentActorName() };
      this.db.canteenServices = (this.db.canteenServices || []).map((r) => (r.id === existing.id ? updated : r));
      this.notify();
      return { success: true, record: updated };
    }
    const created: CanteenServiceRecord = {
      id: `svc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      date,
      mealType,
      entries,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.canteenServices = [created, ...(this.db.canteenServices || [])];
    this.notify();
    return { success: true, record: created };
  }

  public clearStudents() {
    this.db.students = [];
    this.syncClassStudentCounts();
    this.notify();
  }

  public clearTeachers() {
    this.db.teachers = [];
    this.notify();
  }

  public clearClasses() {
    this.db.classes = [];
    this.notify();
  }

  public clearSubjects() {
    this.db.subjects = [];
    this.notify();
  }

  public clearCourses() {
    this.db.courses = [];
    this.notify();
  }

  // Classes CRUD
  public addClass(classItem: Omit<ClassRoom, 'id'>): ClassRoom {
    const newClass: ClassRoom = {
      ...classItem,
      id: `turma-${Date.now()}`
    };
    this.db.classes = [...this.db.classes, newClass];
    this.syncClassStudentCounts();
    this.notify();
    return newClass;
  }

  public updateClass(id: string, updates: Partial<ClassRoom>) {
    this.db.classes = this.db.classes.map((c) => (c.id === id ? { ...c, ...updates } : c));
    this.syncClassStudentCounts();
    this.notify();
  }

  public deleteClass(id: string): { success: boolean; error?: string } {
    const enrolledStudents = (this.db.students || []).filter(
      (s) => String(s.classId) === String(id)
    );
    if (enrolledStudents.length > 0) {
      return {
        success: false,
        error: `A turma possui ${enrolledStudents.length} aluno(s) matriculado(s) ativo(s) no sistema. Transfira os alunos para outra turma antes de eliminar.`
      };
    }
    this.db.classes = this.db.classes.filter((c) => c.id !== id);
    this.notify();
    return { success: true };
  }

  // Subjects CRUD
  public addSubject(subject: Omit<Subject, 'id'>): Subject {
    const newSubject: Subject = {
      ...subject,
      id: `sub-${Date.now()}`
    };
    this.db.subjects = [...(this.db.subjects || defaultSubjects), newSubject];
    this.notify();
    return newSubject;
  }

  public updateSubject(id: string, updates: Partial<Subject>) {
    this.db.subjects = (this.db.subjects || defaultSubjects).map((s) => (s.id === id ? { ...s, ...updates } : s));
    this.notify();
  }

  public deleteSubject(id: string) {
    this.db.subjects = (this.db.subjects || defaultSubjects).filter((s) => s.id !== id);
    this.notify();
  }

  // Courses CRUD
  public addCourse(course: Omit<Course, 'id'>): Course {
    const newCourse: Course = {
      ...course,
      id: `crs-${Date.now()}`
    };
    this.db.courses = [...(this.db.courses || defaultCourses), newCourse];
    this.notify();
    return newCourse;
  }

  public updateCourse(id: string, updates: Partial<Course>) {
    this.db.courses = (this.db.courses || defaultCourses).map((c) =>
      c.id === id ? { ...c, ...updates } : c
    );
    this.notify();
  }

  public deleteCourse(id: string) {
    this.db.courses = (this.db.courses || defaultCourses).filter((c) => c.id !== id);
    this.notify();
  }

  // Timetable CRUD
  public getTimetableForClass(classId: string): TimetableEntry[] {
    return (this.db.timetable || []).filter((t) => String(t.classId) === String(classId));
  }

  public setTimetableForClass(classId: string, entries: Omit<TimetableEntry, 'id' | 'classId'>[]) {
    const others = (this.db.timetable || []).filter((t) => String(t.classId) !== String(classId));
    const newEntries: TimetableEntry[] = entries.map((e, idx) => ({
      ...e,
      id: `tt-${classId}-${Date.now()}-${idx}`,
      classId
    }));
    this.db.timetable = [...others, ...newEntries];
    this.notify();
  }

  /**
   * Verifica se já existe uma disciplina alocada no mesmo dia/tempo lectivo
   * para a mesma turma. Devolve a entrada conflituante (se existir), para que
   * a UI possa informar exactamente qual disciplina já ocupa aquele horário.
   * `excludeId` permite ignorar a própria entrada quando se está a editar.
   */
  public findTimetableConflict(
    classId: string,
    dayOfWeek: TimetableEntry['dayOfWeek'],
    timeStart: string,
    excludeId?: string
  ): TimetableEntry | undefined {
    const list = this.db.timetable || [];
    return list.find(
      (t) =>
        String(t.classId) === String(classId) &&
        t.dayOfWeek === dayOfWeek &&
        t.timeStart === timeStart &&
        t.id !== excludeId
    );
  }

  public saveTimetableEntry(entry: Omit<TimetableEntry, 'id'> & { id?: string }): TimetableEntry {
    const id = entry.id || `tt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    // Regra: não permitir alocar uma disciplina num horário (dia + tempo
    // lectivo) que já tem uma disciplina alocada para a mesma turma.
    const conflict = this.findTimetableConflict(entry.classId, entry.dayOfWeek, entry.timeStart, id);
    if (conflict) {
      throw new Error(
        `Já existe a disciplina "${conflict.subject}" alocada em ${conflict.dayOfWeek} às ${conflict.timeStart}. ` +
          `Remova ou altere essa alocação antes de definir uma nova disciplina neste horário.`
      );
    }

    const fullEntry: TimetableEntry = {
      id,
      classId: entry.classId,
      dayOfWeek: entry.dayOfWeek,
      timeStart: entry.timeStart,
      timeEnd: entry.timeEnd,
      subject: entry.subject,
      teacherName: entry.teacherName,
      room: entry.room
    };
    const list = this.db.timetable || [];
    const existsIndex = list.findIndex((t) => t.id === id);
    if (existsIndex >= 0) {
      const updated = [...list];
      updated[existsIndex] = fullEntry;
      this.db.timetable = updated;
    } else {
      this.db.timetable = [...list, fullEntry];
    }
    this.notify();
    return fullEntry;
  }

  public deleteTimetableEntry(id: string) {
    this.db.timetable = (this.db.timetable || []).filter((t) => t.id !== id);
    this.notify();
  }

  // Attendance
  public getAttendanceSheets(): AttendanceSheet[] {
    return this.db.attendanceSheets || [];
  }

  public getAttendanceSheet(classId: string, subjectId: string, date: string): AttendanceSheet | undefined {
    return (this.db.attendanceSheets || []).find(
      (s) => s.classId === classId && s.subjectId === subjectId && s.date === date
    );
  }

  public saveAttendanceSheet(sheet: AttendanceSheet): AttendanceSheet {
    const sheets = [...(this.db.attendanceSheets || [])];
    const existingIndex = sheets.findIndex(
      (s) => s.id === sheet.id || (s.classId === sheet.classId && s.subjectId === sheet.subjectId && s.date === sheet.date)
    );

    const updatedSheet: AttendanceSheet = {
      ...sheet,
      id: sheet.id || `att-${sheet.classId}-${sheet.subjectId}-${sheet.date}`
    };

    if (existingIndex >= 0) {
      sheets[existingIndex] = updatedSheet;
    } else {
      sheets.unshift(updatedSheet);
    }

    this.db.attendanceSheets = sheets;
    this.db.attendance = updatedSheet;
    this.recalculateStudentsAttendanceStats();
    this.notify();
    return updatedSheet;
  }

  public deleteAttendanceSheet(sheetId: string) {
    this.db.attendanceSheets = (this.db.attendanceSheets || []).filter((s) => s.id !== sheetId);
    if (this.db.attendance.id === sheetId && this.db.attendanceSheets.length > 0) {
      this.db.attendance = this.db.attendanceSheets[0];
    }
    this.recalculateStudentsAttendanceStats();
    this.notify();
  }

  public recalculateStudentsAttendanceStats() {
    const sheets = this.db.attendanceSheets || [];
    if (!sheets.length) return;

    this.db.students = (this.db.students || []).map((student) => {
      let totalSessions = 0;
      let unexcused = 0; // FI
      let excused = 0; // FJ
      let present = 0; // P
      let delay = 0; // A

      sheets.forEach((sheet) => {
        const item = sheet.students?.find((s) => String(s.studentId) === String(student.id));
        if (item) {
          totalSessions++;
          if (item.status === 'FI') unexcused++;
          else if (item.status === 'FJ') excused++;
          else if (item.status === 'P') present++;
          else if (item.status === 'A') delay++;
        }
      });

      if (totalSessions > 0) {
        const presenceCount = present + delay;
        const rate = Math.round((presenceCount / totalSessions) * 1000) / 10;
        return {
          ...student,
          unexcusedAbsences: unexcused,
          excusedAbsences: excused,
          attendanceRate: rate
        };
      }
      return student;
    });
  }

  public updateAttendanceItem(studentId: string, status: 'P' | 'FJ' | 'FI' | 'A', note?: string) {
    const student = this.db.attendance.students.find((s) => s.studentId === studentId);
    if (student) {
      student.status = status;
      if (note !== undefined) student.note = note;
      if (status === 'P') {
        student.entryTime = '08:30';
      } else if (status === 'A') {
        student.entryTime = '08:45';
      } else if (status === 'FI') {
        student.entryTime = 'FALTOU';
      } else {
        student.entryTime = '—';
      }
      // Also update in attendanceSheets if present
      if (this.db.attendanceSheets) {
        const currentSheetId = this.db.attendance.id;
        const sheet = this.db.attendanceSheets.find((s) => s.id === currentSheetId);
        if (sheet) {
          const sheetStudent = sheet.students?.find((s) => s.studentId === studentId);
          if (sheetStudent) {
            sheetStudent.status = status;
            if (note !== undefined) sheetStudent.note = note;
            sheetStudent.entryTime = student.entryTime;
          }
        }
      }
      this.recalculateStudentsAttendanceStats();
      this.notify();
    }
  }

  public markAllAttendance(status: 'P' | 'FJ' | 'FI' | 'A') {
    this.db.attendance.students = this.db.attendance.students.map((s) => ({
      ...s,
      status,
      entryTime: status === 'P' ? '08:30' : status === 'FI' ? 'FALTOU' : '—'
    }));

    if (this.db.attendanceSheets) {
      const currentSheetId = this.db.attendance.id;
      const sheet = this.db.attendanceSheets.find((s) => s.id === currentSheetId);
      if (sheet) {
        sheet.students = sheet.students.map((s) => ({
          ...s,
          status,
          entryTime: status === 'P' ? '08:30' : status === 'FI' ? 'FALTOU' : '—'
        }));
      }
    }
    this.recalculateStudentsAttendanceStats();
    this.notify();
  }

  public saveAttendanceLessonSummary(summary: string, isSigned: boolean) {
    this.db.attendance.lessonSummary = summary;
    this.db.attendance.isDigitallySigned = isSigned;
    if (isSigned) {
      this.db.attendance.signedBy = this.db.currentUser.name;
      this.db.attendance.signedAt = `${new Date().toLocaleDateString('pt-PT')} ${new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })} (IP 192.168.10.42)`;
      this.db.attendance.status = 'sincronizado';
    }
    if (this.db.attendanceSheets) {
      const currentSheetId = this.db.attendance.id;
      const sheet = this.db.attendanceSheets.find((s) => s.id === currentSheetId);
      if (sheet) {
        sheet.lessonSummary = summary;
        sheet.isDigitallySigned = isSigned;
        sheet.signedBy = this.db.attendance.signedBy;
        sheet.signedAt = this.db.attendance.signedAt;
        sheet.status = this.db.attendance.status;
      }
    }
    this.notify();
  }

  // Pauta & Grades
  public updateStudentGrade(gradeId: string, mac: number, npp: number, npt: number, note?: string) {
    const grade = this.db.pauta.grades.find((g) => g.id === gradeId);
    if (grade) {
      grade.mac = mac;
      grade.npp = npp;
      grade.npt = npt;
      // Formula: MT = (MAC * 0.3) + (NPP * 0.3) + (NPT * 0.4)
      const calculated = Math.round(((mac * 0.3) + (npp * 0.3) + (npt * 0.4)) * 10) / 10;
      grade.finalScore = calculated;

      if (calculated >= 18) grade.qualitative = 'Excelente';
      else if (calculated >= 16) grade.qualitative = 'Muito Bom';
      else if (calculated >= 14) grade.qualitative = 'Bom';
      else if (calculated >= 10) grade.qualitative = 'Suficiente';
      else grade.qualitative = 'Insuficiente';

      if (calculated >= 14) grade.situation = 'Transita (Dispensa)';
      else if (calculated >= 10) grade.situation = 'Transita';
      else if (calculated >= 7) grade.situation = 'Exame de Recurso';
      else grade.situation = 'Não Aprovado';

      if (note !== undefined) grade.teacherNote = note;

      // Recalculate pauta stats
      const totalScores = this.db.pauta.grades.map((g) => g.finalScore);
      const avg = totalScores.reduce((a, b) => a + b, 0) / totalScores.length;
      this.db.pauta.classAverage = Math.round(avg * 10) / 10;
      this.db.pauta.highestGrade = Math.max(...totalScores);
      this.db.pauta.lowestGrade = Math.min(...totalScores);
      const approved = this.db.pauta.grades.filter((g) => g.finalScore >= 9.5).length;
      this.db.pauta.approvedCount = approved;
      this.db.pauta.failedCount = this.db.pauta.grades.length - approved;
      this.db.pauta.approvalRatePercent = Math.round((approved / this.db.pauta.grades.length) * 1000) / 10;
      this.db.pauta.lastUpdated = `${new Date().toLocaleDateString('pt-PT')} ${new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}`;

      this.notify();
    }
  }

  /**
   * Marca a pauta geral (ecrã de Pautas) como assinada. Não guarda nenhum PIN:
   * o campo `directorPin` guardava um segredo em texto simples dentro da base de
   * dados, o que não acrescentava segurança nenhuma. A verificação real de
   * identidade é feita com `reauthenticate()` antes de chamar este método.
   */
  public markPautaAsSigned(directorName: string) {
    this.db.pauta.status = 'homologada';
    this.db.pauta.isDirectorSigned = true;
    this.db.pauta.directorName = directorName;
    this.db.pauta.directorSignedAt = `${new Date().toLocaleDateString('pt-PT')} ${new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}`;
    this.notify();
  }

  // Tuition Invoices
  public addPayment(invoiceId: string, method: 'mcx' | 'multicaixa' | 'debito' | 'numerario' | 'tpa', amountKz?: number) {
    const idStr = String(invoiceId);
    const inv = this.db.invoices.find((i) => i.id === idStr || String((i as any).id) === idStr);
    if (inv) {
      inv.status = 'pago';
      inv.method = method;
      inv.methodLabel =
        method === 'mcx'
          ? 'Multicaixa Express (MCX)'
          : method === 'multicaixa'
          ? 'Referência Multicaixa'
          : method === 'numerario'
          ? 'Numerário / Balcão'
          : method === 'debito'
          ? 'Débito Direto'
          : 'TPA Terminal Físico';
      const now = new Date();
      const dateStr = `${now.toLocaleDateString('pt-PT')} ${now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}`;
      inv.paymentDate = dateStr;
      inv.receiptNumber = inv.receiptNumber || `RC ${now.getFullYear()}/${Math.floor(1000 + Math.random() * 9000)}`;
      inv.receiptGeneratedAt = dateStr;
      if (amountKz && amountKz > 0) {
        inv.totalAmountKz = amountKz;
      }

      // Automatically update the student's tuition status in the database
      const student = this.db.students.find((s) => String(s.id) === String(inv.studentId));
      if (student) {
        student.isTuitionPaidCurrentMonth = true;
        const hasOtherDebts = this.db.invoices.some(
          (other) =>
            String(other.studentId) === String(student.id) &&
            other.id !== inv.id &&
            other.status === 'atraso'
        );
        if (!hasOtherDebts) {
          student.financialStatus = 'regular';
        }
      }

      this.notify();
    }
  }

  public getNextInvoiceNumber(): string {
    const currentYear = new Date().getFullYear();
    const prefix = `FT ${currentYear}/`;
    const all = [...(this.db.invoices || []), ...(this.db.tuitionFees || [])];
    let maxSeq = 1849;
    for (const inv of all) {
      if (inv.invoiceNumber) {
        // match FT YYYY/SEQ or FT SEQ
        const match = inv.invoiceNumber.match(/(?:FT\s*(?:BM)?\s*(?:\d{4})?\/?)(\d+)/i);
        if (match) {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num > maxSeq) {
            maxSeq = num;
          }
        }
      }
    }
    return `${prefix}${maxSeq + 1}`;
  }

  public createInvoice(invoice: Omit<TuitionInvoice, 'id' | 'invoiceNumber' | 'daysLate'>): TuitionInvoice {
    const newInv: TuitionInvoice = {
      ...invoice,
      id: `inv-${Date.now()}`,
      invoiceNumber: this.getNextInvoiceNumber(),
      daysLate: 0
    };
    this.db.invoices = [newInv, ...this.db.invoices];
    this.notify();
    return newInv;
  }

  public recordFullPaymentInvoice(invoiceData: Partial<TuitionInvoice> & { studentId: string; totalAmountKz: number }): TuitionInvoice {
    const year = new Date().getFullYear();
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const dateStr = `${day}/${month}/${year}`;

    const newInv: TuitionInvoice = {
      id: invoiceData.id || `inv-${Date.now()}`,
      invoiceNumber: invoiceData.invoiceNumber || this.getNextInvoiceNumber(),
      studentId: invoiceData.studentId,
      studentName: invoiceData.studentName || 'Aluno',
      procNumber: invoiceData.procNumber || '0000',
      avatar: invoiceData.avatar || 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150',
      className: invoiceData.className || 'Turma A',
      guardianName: invoiceData.guardianName || 'Encarregado',
      // Sem NIF/BI real fornecido: nunca inventa um número fiscal/documento de identidade.
      guardianNif: invoiceData.guardianNif || '',
      guardianPhone: invoiceData.guardianPhone || '+244 923 000 000',
      guardianAddress: invoiceData.guardianAddress || 'Luanda, Angola',
      studentBiNumber: invoiceData.studentBiNumber || '',
      operatorName: invoiceData.operatorName || `${this.getCurrentUser().name} (${this.getCurrentUser().roleTitle || 'Secretaria Geral'})`,
      description: invoiceData.description || 'Pagamento de Propinas e Emolumentos',
      period: invoiceData.period || 'Março / 2026',
      dueDate: invoiceData.dueDate || now.toISOString().split('T')[0],
      totalAmountKz: invoiceData.totalAmountKz,
      baseAmountKz: invoiceData.baseAmountKz || invoiceData.totalAmountKz,
      lateFeeKz: invoiceData.lateFeeKz || 0,
      status: 'pago',
      daysLate: 0,
      method: invoiceData.method || 'tpa',
      methodLabel: invoiceData.methodLabel || 'TPA Multicaixa / Caixa Geral',
      bankName: invoiceData.bankName || 'Caixa Central / Tesouraria',
      transactionNumber: invoiceData.transactionNumber || this.getNextTransactionNumber(),
      paymentDate: dateStr,
      receiptNumber: invoiceData.receiptNumber || `RC ${year}/${Math.floor(1000 + Math.random() * 9000)}`,
      receiptGeneratedAt: dateStr,
      saftHash: invoiceData.saftHash || undefined,
      items: invoiceData.items || [
        {
          code: 'PROP-ESC',
          description: `Propinas Escolares (${invoiceData.period || 'Mês'})`,
          periodOrRef: invoiceData.period || '2026',
          unitPriceKz: invoiceData.totalAmountKz,
          quantity: 1,
          discountKz: 0,
          taxRegime: 'Isento (Art. 12 CIVA)',
          liquidTotalKz: invoiceData.totalAmountKz
        }
      ],
      subtotalKz: invoiceData.subtotalKz || invoiceData.totalAmountKz,
      discountName: invoiceData.discountName || 'Sem Desconto',
      discountAmountKz: invoiceData.discountAmountKz || 0,
      stampDutyKz: invoiceData.stampDutyKz || Math.round(invoiceData.totalAmountKz * 0.001),
      totalPaidKz: invoiceData.totalPaidKz ?? invoiceData.totalAmountKz,
      selectedMonths: invoiceData.selectedMonths || [invoiceData.period || 'Março']
    };
    // Respeita o estado calculado pelo chamador (ex.: 'pendente' quando um
    // pagamento parcial foi registado ao abrigo da política de Amortização) em
    // vez de assumir sempre pagamento total.
    newInv.status = invoiceData.status || 'pago';

    this.db.invoices = [newInv, ...(this.db.invoices || [])];

    // Update student tuition status
    const student = this.db.students.find((s) => String(s.id) === String(invoiceData.studentId));
    if (student) {
      if (newInv.status === 'pago') {
        student.isTuitionPaidCurrentMonth = true;
        student.financialStatus = 'regular';
      } else {
        student.isTuitionPaidCurrentMonth = false;
        student.financialStatus = 'debito';
      }
    }

    this.addNotification({
      title: `Recibo Emitido: ${newInv.receiptNumber || newInv.invoiceNumber}`,
      message: `${newInv.studentName} — ${Number(newInv.totalAmountKz).toLocaleString()} Kz (${newInv.period})`,
      type: 'finance',
      priority: 'normal',
      linkView: 'propinas'
    });

    this.notify();
    return newInv;
  }

  public getNextTransactionNumber(): string {
    const invoices = this.db.invoices || [];
    let maxSeq = 0;
    for (const inv of invoices) {
      if (inv.transactionNumber) {
        const match = inv.transactionNumber.match(/TRANS(\d+)/i);
        if (match) {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num > maxSeq) {
            maxSeq = num;
          }
        }
      }
    }
    const next = maxSeq + 1;
    return `TRANS${String(next).padStart(3, '0')}`;
  }

  // School Services & Emoluments Catalog
  public getServices(): SchoolServiceItem[] {
    return this.db.services || defaultServices;
  }

  public addService(service: Omit<SchoolServiceItem, 'id'>): SchoolServiceItem {
    const newService: SchoolServiceItem = {
      ...service,
      id: `srv-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    this.db.services = [...(this.db.services || defaultServices), newService];
    this.notify();
    return newService;
  }

  public updateService(id: string, updates: Partial<SchoolServiceItem>) {
    const currentServices = this.db.services || defaultServices;
    this.db.services = currentServices.map((s) => (s.id === id ? { ...s, ...updates } : s));
    this.notify();
  }

  public deleteService(id: string) {
    const currentServices = this.db.services || defaultServices;
    this.db.services = currentServices.filter((s) => s.id !== id);
    this.notify();
  }

  // Notices
  public addNotice(notice: Omit<Notice, 'id' | 'date' | 'readsCount'>): Notice {
    const newNotice: Notice = {
      ...notice,
      id: `not-${Date.now()}`,
      date: 'Hoje, ' + new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' }),
      readsCount: 1
    };
    this.db.notices = [newNotice, ...this.db.notices];

    // Trigger real-time school notification
    this.addNotification({
      title: `Aviso Escolar: ${newNotice.title}`,
      message: newNotice.excerpt || newNotice.content.substring(0, 90),
      type: 'notice',
      priority: newNotice.priority === 'urgente' ? 'urgente' : newNotice.priority === 'alta' ? 'alta' : 'normal',
      targetRoles: newNotice.targetRoles,
      linkView: 'mural_biblioteca'
    });

    this.notify();
    return newNotice;
  }

  // School Notifications CRUD & Real-Time Handling
  public getNotifications(role?: UserRole): SchoolNotification[] {
    const list = this.db.notifications || defaultNotifications;
    if (!role) return list;
    return list.filter((n) => !n.targetRoles || n.targetRoles.includes(role));
  }

  public addNotification(
    notif: Omit<SchoolNotification, 'id' | 'timestamp' | 'read' | 'createdAt'> & {
      id?: string;
      timestamp?: string;
      read?: boolean;
      createdAt?: number;
    }
  ): SchoolNotification {
    const now = Date.now();
    const newNotif: SchoolNotification = {
      id: notif.id || `notif-${now}-${Math.random().toString(36).substring(2, 6)}`,
      title: notif.title,
      message: notif.message,
      type: notif.type || 'notice',
      priority: notif.priority || 'normal',
      timestamp: notif.timestamp || 'Agora',
      read: notif.read ?? false,
      targetRoles: notif.targetRoles,
      linkView: notif.linkView,
      linkId: notif.linkId,
      createdAt: notif.createdAt || now
    };

    const current = this.db.notifications || defaultNotifications;
    this.db.notifications = [newNotif, ...current.filter((n) => n.id !== newNotif.id)].slice(0, 50);

    // Dispatch window custom event for real-time reactive listening
    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(
          new CustomEvent('bandmed:school_notification', { detail: newNotif })
        );
      } catch {
        // ignore
      }
    }

    this.notify();
    return newNotif;
  }

  public markNotificationAsRead(id: string) {
    if (!this.db.notifications) {
      this.db.notifications = [...defaultNotifications];
    }
    this.db.notifications = this.db.notifications.map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    this.notify();
  }

  public markAllNotificationsAsRead() {
    if (!this.db.notifications) {
      this.db.notifications = [...defaultNotifications];
    }
    this.db.notifications = this.db.notifications.map((n) => ({ ...n, read: true }));
    this.notify();
  }

  public deleteNotification(id: string) {
    if (!this.db.notifications) {
      this.db.notifications = [...defaultNotifications];
    }
    this.db.notifications = this.db.notifications.filter((n) => n.id !== id);
    this.notify();
  }

  public clearAllNotifications() {
    this.db.notifications = [];
    this.notify();
  }

  // Library
  public issueBookLoan(bookId: string, borrowerName: string, borrowerRole: string) {
    const book = this.db.books.find((b) => b.id === bookId);
    if (book && book.availableCopies > 0) {
      book.availableCopies -= 1;
      const loan: BookLoan = {
        id: `loan-${Date.now()}`,
        bookId,
        bookTitle: book.title,
        borrowerName,
        borrowerRole,
        borrowDate: new Date().toLocaleDateString('pt-PT'),
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-PT'),
        status: 'ativo'
      };
      this.db.loans = [loan, ...this.db.loans];
      this.notify();
    }
  }

  public returnBookLoan(loanId: string) {
    const loan = this.db.loans.find((l) => l.id === loanId);
    if (loan) {
      loan.status = 'devolvido';
      loan.returnDate = new Date().toLocaleDateString('pt-PT');
      const book = this.db.books.find((b) => b.id === loan.bookId);
      if (book) {
        book.availableCopies = Math.min(book.totalCopies, book.availableCopies + 1);
      }
      this.notify();
    }
  }

  // Settings
  public updateSettings(updates: Partial<InstitutionSettings>) {
    this.db.settings = { ...this.db.settings, ...updates };
    this.notify();
  }

  public setAcademicTrimester(trimester: '1' | '2' | '3') {
    this.db.settings = { ...this.db.settings, currentTrimester: trimester };
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Diretor Pedagógico',
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Alteração de Trimestre Ativo',
      details: `O sistema passou a operar no ${trimester}.º Trimestre oficial.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
  }

  public restoreDatabase(importedDb: Partial<SchoolDatabase>) {
    if (!importedDb || typeof importedDb !== 'object') {
      throw new Error('Formato de base de dados inválido.');
    }
    const currentSettings = this.db.settings;
    this.db = {
      ...this.db,
      ...importedDb,
      settings: { ...currentSettings, ...(importedDb.settings || {}) }
    };
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador Geral',
      userRole: 'Administrador',
      action: 'Restauração de Base de Dados',
      details: 'Base de dados restaurada com sucesso a partir de ficheiro de cópia de segurança.',
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#ac332b'
    });
    this.notify();
  }

  // Factory reset
  public resetToFactoryDemo() {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.removeItem(STORAGE_KEY);
      }
      idbService.clear();
    } catch (e) {
      console.warn(e);
    }
    this.db = getInitialDb();
    this.notify();
  }

  public resetToDefaults() {
    this.resetToFactoryDemo();
  }

  public addTuitionFee(fee: any) {
    const studentIdStr = String(fee.studentId);
    const student = this.db.students.find((s) => String(s.id) === studentIdStr);
    // Nunca inventa a propina: usa a Tabela Financeira real configurada para a classe
    // do aluno quando não há valor explícito na própria fee/aluno.
    const studentClass = student ? this.db.classes.find((c) => String(c.id) === String(student.classId)) : undefined;
    const tuitionRow = studentClass ? findTuitionRowForGrade(this.db.settings?.tuitionRows, studentClass.grade) : undefined;
    const amount = Number(fee.totalAmountKz || fee.baseAmountKz || student?.monthlyTuitionKz || tuitionRow?.monthlyTuitionKz || 0);
    const lateFee = Number(fee.lateFeeKz || 0);
    const year = new Date().getFullYear();
    const resolvedInvoiceNumber = fee.invoiceNumber || this.getNextInvoiceNumber();

    const newInv: TuitionInvoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: resolvedInvoiceNumber,
      receiptNumber: fee.receiptNumber,
      studentId: studentIdStr,
      studentName: fee.studentName || student?.name || 'Aluno',
      procNumber: fee.procNumber || student?.procNumber || '',
      avatar: student?.avatar || fee.avatar || '',
      className: student?.className || fee.className || '',
      guardianName: student?.guardianName || fee.guardianName || 'Encarregado de Educação',
      guardianNif: student?.guardianNif || fee.guardianNif || '',
      period: fee.period || 'Mês Corrente',
      description: fee.description || `Propina Mensal — ${fee.period || 'Mês Corrente'}`,
      baseAmountKz: Number(fee.baseAmountKz || amount),
      lateFeeKz: lateFee,
      totalAmountKz: amount + lateFee,
      dueDate: fee.dueDate || `${year}-12-08`,
      daysLate: 0,
      paymentDate: fee.paymentDate,
      status: fee.status || 'pendente',
      method: fee.method,
      methodLabel: fee.methodLabel,
      // Entidade e referência vêm da integração EMIS configurada pela
      // instituição (Configurações → Integrações & AGT). Sem entidade
      // registada, a fatura fica sem referência e é paga ao balcão.
      ...(fee.multicaixaEntity && fee.multicaixaRef
        ? { multicaixaEntity: fee.multicaixaEntity, multicaixaRef: fee.multicaixaRef }
        : buildMulticaixaFields(
            resolvedInvoiceNumber,
            amount + lateFee,
            this.db.settings?.integrations?.emisEntity
          ))
    };

    this.db.invoices = [newInv, ...this.db.invoices];
    if (student && newInv.status === 'atraso') {
      student.financialStatus = 'debito';
    }
    this.notify();
    return newInv;
  }

  public updateTuitionFee(feeId: any, updates: Partial<TuitionInvoice>) {
    const idStr = String(feeId);
    this.db.invoices = this.db.invoices.map((inv) => {
      if (inv.id === idStr || String((inv as any).id) === idStr) {
        const merged = { ...inv, ...updates };
        if (updates.status === 'pago') {
          const student = this.db.students.find((s) => String(s.id) === String(merged.studentId));
          if (student) {
            student.isTuitionPaidCurrentMonth = true;
            const hasOtherDebts = this.db.invoices.some(
              (other) =>
                String(other.studentId) === String(student.id) &&
                String(other.id) !== idStr &&
                other.status === 'atraso'
            );
            if (!hasOtherDebts) {
              student.financialStatus = 'regular';
            }
          }
        }
        return merged;
      }
      return inv;
    });
    this.notify();
  }

  public deleteTuitionFee(feeId: any) {
    const idStr = String(feeId);
    if (this.db.invoices) {
      this.db.invoices = this.db.invoices.filter(
        (inv) => inv.id !== idStr && String((inv as any).id) !== idStr
      );
    }
    if (this.db.tuitionFees) {
      this.db.tuitionFees = this.db.tuitionFees.filter(
        (inv) => inv.id !== idStr && String((inv as any).id) !== idStr
      );
    }
    this.notify();
  }

  /**
   * Sincroniza automaticamente o calendário académico com a data do sistema.
   * Não existe qualquer passagem manual de trimestre ou de ano letivo:
   *
   *  1. TRIMESTRE — o trimestre em curso é sempre o que contém a data de hoje.
   *     Quando um trimestre termina, o dia seguinte já pertence ao trimestre
   *     seguinte (ver resolveActiveTrimester em utils/academicCalendar.ts).
   *  2. ANO LETIVO — quando a data de hoje ultrapassa o Término do Período de
   *     Atividade, o ano letivo é arquivado (fica registado em
   *     settings.academicYearHistory com o calendário com que funcionou) e o ano
   *     seguinte é aberto automaticamente: 2026/2027 dá lugar a 2027/2028, com o
   *     período proposto de 1 de Setembro a 31 de Julho e os três trimestres
   *     pré-distribuídos, prontos a ajustar.
   *
   * Toda a informação já gravada permanece associada ao ano em que foi
   * produzida — o ano letivo anterior passa apenas a constar como ano passado.
   * Deve ser chamado no arranque da aplicação e periodicamente enquanto esta
   * estiver aberta.
   */
  public syncAcademicCalendar(reference: Date = new Date()): {
    changed: boolean;
    rolledOverTo?: string;
    trimester?: '1' | '2' | '3';
  } {
    if (!this.db.settings) {
      this.db.settings = { ...defaultSettings };
    }
    const settings = this.db.settings;
    let changed = false;
    let rolledOverTo: string | undefined;

    const today = new Date(reference.getFullYear(), reference.getMonth(), reference.getDate());

    // --- 1. Período de Atividade: normaliza para ISO (registos anteriores a esta
    // versão guardavam apenas o texto "02 Set 2026 — 31 Jul 2027").
    let startIso = anyDateToIso(settings.academicPeriodStartIso);
    let endIso = anyDateToIso(settings.academicPeriodEndIso);

    if ((!startIso || !endIso) && settings.academicPeriod) {
      const parsed = parsePeriodRange(settings.academicPeriod);
      startIso = startIso || parsed.startIso;
      endIso = endIso || parsed.endIso;
      if (startIso || endIso) changed = true;
    }
    if ((!startIso || !endIso) && settings.currentAcademicYear) {
      const proposed = defaultPeriodForAcademicYear(settings.currentAcademicYear);
      startIso = startIso || proposed.startIso;
      endIso = endIso || proposed.endIso;
      if (startIso || endIso) changed = true;
    }

    // --- 2. Transição automática de Ano Letivo.
    const endDate = isoToDate(endIso);
    if (endDate && today.getTime() > endDate.getTime()) {
      const closingYear = settings.currentAcademicYear || '';
      const history = [...(settings.academicYearHistory || [])];
      if (!history.some((h) => h.academicYear === closingYear) && closingYear) {
        history.push({
          academicYear: closingYear,
          period: settings.academicPeriod,
          periodStartIso: startIso,
          periodEndIso: endIso,
          weeks: settings.academicWeeks,
          trimesterSchedules: settings.trimesterSchedules,
          archivedAt: new Date().toISOString()
        });
      }

      const nextYear = nextAcademicYearLabel(closingYear);
      const nextPeriod = defaultPeriodForAcademicYear(nextYear);
      const nextTrimesters = proposeTrimesterDates(nextPeriod.startIso, nextPeriod.endIso);

      const buildSchedule = (range: { startIso: string; endIso: string }) => {
        const weeks = countSchoolWeeks(range.startIso, range.endIso);
        return {
          startDate: isoToPtDate(range.startIso),
          endDate: isoToPtDate(range.endIso),
          startDateIso: range.startIso,
          endDateIso: range.endIso,
          examPeriod: '',
          examStartDateIso: '',
          examEndDateIso: '',
          gradesCouncilDate: '',
          gradesCouncilDateIso: '',
          weeksCount: formatWeeksLabel(weeks),
          weeksCountNumber: weeks,
          closed: false
        };
      };

      const availableYears = settings.availableAcademicYears || [];
      settings.academicYearHistory = history;
      settings.currentAcademicYear = nextYear;
      settings.availableAcademicYears = availableYears.includes(nextYear)
        ? availableYears
        : [...availableYears, nextYear];
      settings.academicPeriodStartIso = nextPeriod.startIso;
      settings.academicPeriodEndIso = nextPeriod.endIso;
      settings.academicPeriod = formatPeriodRange(nextPeriod.startIso, nextPeriod.endIso);
      settings.trimesterSchedules = {
        t1: buildSchedule(nextTrimesters[0]),
        t2: buildSchedule(nextTrimesters[1]),
        t3: buildSchedule(nextTrimesters[2])
      };
      settings.currentTrimester = '1';
      settings.academicHolidays = getDefaultAngolaHolidays(nextYear).map((h, i) => ({
        id: `holiday-${nextYear.replace('/', '-')}-${i}`,
        date: h.date,
        name: h.name,
        trimestre: h.trimestre
      }));

      startIso = nextPeriod.startIso;
      endIso = nextPeriod.endIso;
      rolledOverTo = nextYear;
      changed = true;

      this.addAuditLog({
        userName: 'Sistema',
        userRole: 'Automático',
        action: 'Abertura Automática de Ano Letivo',
        details: `O Ano Letivo ${closingYear} terminou a ${isoToPtDate(
          history[history.length - 1]?.periodEndIso
        ) || 'data configurada'} e ficou arquivado como ano passado. O Ano Letivo ${nextYear} foi aberto automaticamente (${settings.academicPeriod}).`,
        module: 'sistema',
        timestamp: 'Agora mesmo',
        badgeColor: '#0b1f3a'
      });
    }

    // --- 3. Semanas Letivas do ano, sempre recalculadas a partir do período.
    const academicWeeks = countSchoolWeeks(startIso, endIso);
    if (academicWeeks && settings.academicWeeksNumber !== academicWeeks) {
      settings.academicWeeksNumber = academicWeeks;
      settings.academicWeeks = formatWeeksLabel(academicWeeks, 'Semanas Letivas');
      changed = true;
    }
    if (startIso && endIso) {
      const periodLabel = formatPeriodRange(startIso, endIso);
      if (
        settings.academicPeriodStartIso !== startIso ||
        settings.academicPeriodEndIso !== endIso ||
        settings.academicPeriod !== periodLabel
      ) {
        settings.academicPeriodStartIso = startIso;
        settings.academicPeriodEndIso = endIso;
        settings.academicPeriod = periodLabel;
        changed = true;
      }
    }

    // --- 4. Trimestre em curso, determinado só pelas datas.
    const activeTrimester = resolveActiveTrimester(settings.trimesterSchedules, today);
    if (activeTrimester && settings.currentTrimester !== activeTrimester) {
      const previous = settings.currentTrimester;
      settings.currentTrimester = activeTrimester;
      changed = true;
      this.addAuditLog({
        userName: 'Sistema',
        userRole: 'Automático',
        action: 'Passagem Automática de Trimestre',
        details: `O ${previous}.º Trimestre chegou ao fim e o sistema passou a operar no ${activeTrimester}.º Trimestre, segundo as datas definidas em Configurações > Ano Letivo.`,
        module: 'sistema',
        timestamp: 'Agora mesmo',
        badgeColor: '#0b1f3a'
      });
    }

    if (changed) {
      this.db.settings = { ...settings };
      this.notify();
    }

    return { changed, rolledOverTo, trimester: settings.currentTrimester };
  }

  /**
   * Define as turmas vinculadas a um curso (escolhidas no formulário do curso).
   * A área curricular das turmas selecionadas passa a ser o nome do curso; as
   * turmas que deixaram de estar vinculadas e ainda apontavam para este curso
   * ficam sem área atribuída, para não continuarem a aparecer como sendo dele.
   */
  public setCourseLinkedClasses(courseId: string, classIds: string[]) {
    const courses = this.db.courses || defaultCourses;
    const course = courses.find((c) => c.id === courseId);
    if (!course) return;

    const previous = course.linkedClassIds || [];
    const next = Array.from(new Set(classIds.filter(Boolean)));

    this.db.courses = courses.map((c) => (c.id === courseId ? { ...c, linkedClassIds: next } : c));

    this.db.classes = (this.db.classes || []).map((cls) => {
      if (next.includes(cls.id)) {
        return { ...cls, area: course.name };
      }
      if (previous.includes(cls.id) && cls.area === course.name) {
        return { ...cls, area: '' };
      }
      return cls;
    });

    this.notify();
  }

  public setAcademicYear(year: string) {
    if (!this.db.settings) {
      this.db.settings = { ...defaultSettings };
    }
    const previousYear = this.db.settings.currentAcademicYear;
    this.db.settings.currentAcademicYear = year;
    if (!this.db.settings.availableAcademicYears || this.db.settings.availableAcademicYears.length === 0) {
      this.db.settings.availableAcademicYears = [year];
    }
    if (!this.db.settings.availableAcademicYears.includes(year)) {
      this.db.settings.availableAcademicYears.push(year);
    }

    // Ao mudar de ano letivo, o calendário acompanha: se o ano já tem histórico
    // arquivado, recupera-se o período e os trimestres com que funcionou; caso
    // contrário aplica-se o período proposto (1 Set — 31 Jul) desse ano.
    if (previousYear !== year) {
      const archived = (this.db.settings.academicYearHistory || []).find((h) => h.academicYear === year);
      if (archived) {
        this.db.settings.academicPeriod = archived.period || '';
        this.db.settings.academicPeriodStartIso = archived.periodStartIso || '';
        this.db.settings.academicPeriodEndIso = archived.periodEndIso || '';
        this.db.settings.academicWeeks = archived.weeks || '';
        if (archived.trimesterSchedules) {
          this.db.settings.trimesterSchedules = archived.trimesterSchedules;
        }
      } else {
        const proposed = defaultPeriodForAcademicYear(year);
        if (proposed.startIso && proposed.endIso) {
          this.db.settings.academicPeriodStartIso = proposed.startIso;
          this.db.settings.academicPeriodEndIso = proposed.endIso;
          this.db.settings.academicPeriod = formatPeriodRange(proposed.startIso, proposed.endIso);
          const weeks = countSchoolWeeks(proposed.startIso, proposed.endIso);
          this.db.settings.academicWeeks = formatWeeksLabel(weeks, 'Semanas Letivas');
          this.db.settings.academicWeeksNumber = weeks;
        }
      }
    }

    this.notify();
  }

  /**
   * Encerra e tranca oficialmente um Trimestre (Configurações > Ano Letivo > "Encerrar"):
   * marca trimesterSchedules[tN].closed = true, com data e autor do encerramento. A partir
   * daqui, a Assiduidade deixa de aceitar novos sumários/edições com data dentro deste
   * trimestre, e as Pautas deixam de aceitar lançamento de notas para ele — ver
   * getSummaryLockInfo/getGradeLaunchLockInfo em utils/academicYear.ts.
   */
  public closeTrimester(trimester: '1' | '2' | '3') {
    if (!this.db.settings) {
      this.db.settings = { ...defaultSettings };
    }
    const key = ('t' + trimester) as 't1' | 't2' | 't3';
    const existing = this.db.settings.trimesterSchedules?.[key] || ({} as any);
    const closedAt = new Date().toISOString();
    const closedBy = this.db.currentUser?.name || 'Direção Pedagógica';
    this.db.settings.trimesterSchedules = {
      ...(this.db.settings.trimesterSchedules as any),
      [key]: { ...existing, closed: true, closedAt, closedBy }
    };
    this.addAuditLog({
      userName: closedBy,
      userRole: this.db.currentUser?.roleTitle || 'Direção Pedagógica',
      action: 'Encerramento de Trimestre',
      details: `O ${trimester}.º Trimestre foi oficialmente homologado e trancado para edição de sumários e lançamento de notas.`,
      module: 'pautas',
      timestamp: 'Agora mesmo',
      badgeColor: '#ac332b'
    });
    this.notify();
  }

  /**
   * Reabre um Trimestre previamente encerrado (ação reservada à Direção/Administração —
   * regra 'pautas.unlock'), permitindo novamente a edição de sumários e o lançamento de
   * notas dentro desse período.
   */
  public reopenTrimester(trimester: '1' | '2' | '3') {
    if (!this.db.settings?.trimesterSchedules) return;
    const key = ('t' + trimester) as 't1' | 't2' | 't3';
    const existing = this.db.settings.trimesterSchedules[key];
    if (!existing) return;
    this.db.settings.trimesterSchedules = {
      ...this.db.settings.trimesterSchedules,
      [key]: { ...existing, closed: false }
    };
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Direção Pedagógica',
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Reabertura de Trimestre',
      details: `O ${trimester}.º Trimestre foi reaberto para edição de sumários e lançamento de notas.`,
      module: 'pautas',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
  }

  /**
   * Sincroniza os Feriados Oficiais da República de Angola (Configurações > Ano Letivo >
   * "Sincronizar") com o Ano Letivo Vigente, acrescentando ao calendário os que ainda não
   * estejam registados na base de dados (sem duplicar os já existentes, identificados por
   * data). Devolve a lista final de feriados gravada.
   */
  public syncOfficialHolidays() {
    if (!this.db.settings) {
      this.db.settings = { ...defaultSettings };
    }
    const academicYear = this.db.settings.currentAcademicYear || '';
    const defaults = getDefaultAngolaHolidays(academicYear);
    const existing = Array.isArray(this.db.settings.academicHolidays) ? this.db.settings.academicHolidays : [];
    const existingDates = new Set(existing.map((h) => h.date));
    const additions = defaults
      .filter((h) => !existingDates.has(h.date))
      .map((h) => ({ id: `holiday-${h.date}`, date: h.date, name: h.name, trimestre: h.trimestre }));
    const merged = [...existing, ...additions].sort((a, b) => a.date.localeCompare(b.date));
    this.db.settings.academicHolidays = merged;
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Sincronização de Feriados Oficiais',
      details: `Calendário de Feriados Oficiais sincronizado para o Ano Letivo ${academicYear || 'vigente'} (${additions.length} novo(s) feriado(s) adicionado(s)).`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return merged;
  }

  public generateMonthlyBatchInvoices(period: string, dueDate: string, classId?: string): number {
    const targetStudents = (this.db.students || []).filter((s) => {
      if (classId && classId !== 'all') {
        return s.classId === classId;
      }
      return true;
    });

    let count = 0;
    const newInvoices: TuitionInvoice[] = [];

    targetStudents.forEach((student) => {
      const exists = this.db.invoices.some(
        (inv) =>
          String(inv.studentId) === String(student.id) &&
          inv.period.toLowerCase() === period.toLowerCase()
      );
      if (!exists) {
        // Nunca inventa a propina: usa o valor real do aluno ou, na falta dele,
        // a Tabela Financeira real configurada para a classe.
        const studentClass = this.db.classes.find((c) => String(c.id) === String(student.classId));
        const tuitionRow = studentClass ? findTuitionRowForGrade(this.db.settings?.tuitionRows, studentClass.grade) : undefined;
        const tuition = student.monthlyTuitionKz || tuitionRow?.monthlyTuitionKz || 0;
        newInvoices.push({
          id: `inv-${Date.now()}-${student.id}`,
          invoiceNumber: this.getNextInvoiceNumber(),
          studentId: String(student.id),
          studentName: student.name,
          procNumber: student.procNumber,
          avatar: student.avatar || '',
          className: student.className,
          guardianName: student.guardianName,
          guardianNif: student.guardianNif || '',
          period,
          description: `Propina Mensal Escolar — ${period}`,
          baseAmountKz: tuition,
          lateFeeKz: 0,
          totalAmountKz: tuition,
          dueDate,
          daysLate: 0,
          status: 'pendente',
          ...buildMulticaixaFields(
            this.getNextInvoiceNumber(),
            tuition,
            this.db.settings?.integrations?.emisEntity
          )
        });
        count++;
      }
    });

    if (newInvoices.length > 0) {
      this.db.invoices = [...newInvoices, ...this.db.invoices];
      this.notify();
    }
    return count;
  }

  // Institutional Audit Logs
  public getAuditLogs(): SchoolAuditLog[] {
    return this.db.auditLogs || defaultAuditLogs;
  }

  public addAuditLog(entry: Omit<SchoolAuditLog, 'id' | 'createdAt'>) {
    if (!this.db.auditLogs) {
      this.db.auditLogs = [...defaultAuditLogs];
    }

    // O Registo de Auditoria tem de identificar SEMPRE a pessoa que estava autenticada
    // quando a operação foi feita. Vários pontos da aplicação passavam rótulos fixos
    // ("Direção Financeira", "Administrador Geral", "Diretor Pedagógico"), o que tornava
    // a trilha de conformidade inútil. O utilizador autenticado tem prioridade sobre
    // qualquer nome enviado pelo chamador; o valor recebido fica apenas como recurso
    // para operações automáticas do sistema (sem sessão iniciada).
    const actor = this.db.currentUser;
    const resolvedUserName = actor?.name?.trim() || entry.userName || 'Sistema';
    const resolvedUserRole =
      actor?.roleTitle?.trim() || actor?.role || entry.userRole || 'Sistema';
    const resolvedAvatar = entry.avatar || actor?.avatar;

    // Praticamente todos os chamadores passavam a string literal "Agora mesmo", pelo que
    // a coluna Data / Hora nunca envelhecia. Guarda-se a data e hora reais da operação.
    const now = new Date();
    const placeholderTimestamp =
      !entry.timestamp || /^agora\s*mesmo$/i.test(entry.timestamp.trim());
    const resolvedTimestamp = placeholderTimestamp
      ? `${now.toLocaleDateString('pt-PT')} ${now.toLocaleTimeString('pt-PT', {
          hour: '2-digit',
          minute: '2-digit'
        })}`
      : entry.timestamp;

    const newLog: SchoolAuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: Date.now(),
      ...entry,
      userName: resolvedUserName,
      userRole: resolvedUserRole,
      timestamp: resolvedTimestamp,
      ...(resolvedAvatar ? { avatar: resolvedAvatar } : {})
    };
    this.db.auditLogs = [newLog, ...this.db.auditLogs].slice(0, 100);
    this.notify();
    return newLog;
  }

  // Institutional Calendar Events
  public getEvents(): SchoolCalendarEvent[] {
    return this.db.events || defaultEvents;
  }

  public addEvent(event: Omit<SchoolCalendarEvent, 'id'>) {
    if (!this.db.events) {
      this.db.events = [...defaultEvents];
    }
    const newEvt: SchoolCalendarEvent = {
      id: `evt-${Date.now()}`,
      ...event
    };
    this.db.events = [...this.db.events, newEvt];
    this.addAuditLog({
      userName: this.db.currentUser?.name || 'Administrador',
      userRole: this.db.currentUser?.roleTitle || 'Secretaria',
      action: 'Agendamento de Evento',
      details: `Novo evento marcado na agenda: "${newEvt.title}" (${newEvt.date}).`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return newEvt;
  }

  public deleteEvent(id: string) {
    if (!this.db.events) return;
    this.db.events = this.db.events.filter((e) => e.id !== id);
    this.notify();
  }

  // --- Homologação de pautas -------------------------------------------------

  public getHomologations(): PautaHomologation[] {
    return this.db.homologations || [];
  }

  public findHomologation(
    classId: string,
    subjectId: string,
    trimester: PautaHomologation['trimester']
  ): PautaHomologation | null {
    return (
      (this.db.homologations || []).find(
        (h) =>
          String(h.classId) === String(classId) &&
          String(h.subjectId) === String(subjectId) &&
          h.trimester === trimester
      ) || null
    );
  }

  /**
   * Regista a homologação de uma pauta. Guarda também uma impressão digital das
   * notas assinadas: se alguém alterar notas depois da assinatura, a pauta deixa
   * de coincidir com o que foi homologado e o sistema consegue avisar.
   */
  public homologatePauta(
    record: Omit<PautaHomologation, 'id' | 'signedAt'>
  ): PautaHomologation {
    if (!this.db.homologations) this.db.homologations = [];

    const entry: PautaHomologation = {
      ...record,
      id: `hom-${Date.now()}`,
      signedAt: new Date().toISOString()
    };

    // Uma pauta só pode ter uma homologação ativa por turma/disciplina/trimestre.
    this.db.homologations = [
      entry,
      ...this.db.homologations.filter(
        (h) =>
          !(
            String(h.classId) === String(record.classId) &&
            String(h.subjectId) === String(record.subjectId) &&
            h.trimester === record.trimester
          )
      )
    ];

    this.addAuditLog({
      userName: record.signedByName,
      userRole: record.signedByRole,
      action: 'Homologação de Pauta',
      details:
        `Pauta de ${record.subjectName} — ${record.className} (${record.trimester === 'final' ? 'Final' : record.trimester + '.º trimestre'}) ` +
        `homologada com ${record.studentCount} alunos: ${record.approvedCount} aprovados, ${record.failedCount} não aprovados.`,
      module: 'pedagogico',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });

    this.notify();
    return entry;
  }

  /** Impressão digital estável de um conjunto de notas. */
  public static fingerprintGrades(rows: Array<Record<string, unknown>>): string {
    const canonical = rows
      .map((r) => `${r.studentId}:${r.mt1 ?? ''}|${r.mt2 ?? ''}|${r.mt3 ?? ''}|${r.mfd ?? ''}`)
      .sort()
      .join(';');
    let hash = 5381;
    for (let i = 0; i < canonical.length; i++) {
      hash = ((hash << 5) + hash + canonical.charCodeAt(i)) >>> 0;
    }
    return hash.toString(16).padStart(8, '0');
  }

  // Mini Pauta & Grades Persistence
  public getMiniPautaRows(classId: string, subjectId: string): any[] | null {
    if (this.db.miniPautasStore && this.db.miniPautasStore[classId] && this.db.miniPautasStore[classId][subjectId]) {
      return this.db.miniPautasStore[classId][subjectId];
    }
    return null;
  }

  public saveMiniPautaRows(classId: string, subjectId: string, rows: any[], userName?: string) {
    if (!this.db.miniPautasStore) {
      this.db.miniPautasStore = {};
    }
    if (!this.db.miniPautasStore[classId]) {
      this.db.miniPautasStore[classId] = {};
    }
    this.db.miniPautasStore[classId][subjectId] = rows;

    const classObj = this.db.classes.find((c) => String(c.id) === String(classId));
    const subjectObj = this.db.subjects.find((s) => String(s.id) === String(subjectId));
    const subjectName = subjectObj?.name || 'Disciplina Curricular';

    // Synchronize grades into student records in db.students
    rows.forEach((row) => {
      const student = this.db.students.find(
        (s) => String(s.id) === String(row.studentId) || String(s.procNumber) === String(row.num)
      );
      if (student) {
        if (!student.trimesterGrades) {
          student.trimesterGrades = [];
        }
        const existingIdx = student.trimesterGrades.findIndex(
          (g) => String(g.subjectId) === String(subjectId) || g.subjectName.toLowerCase() === subjectName.toLowerCase()
        );

        // Recalcula MT1/MT2/MT3/MFD a partir do MAC/NPP/NPT em vez de confiar
        // ciegamente em row.mt1/row.mfd: se estas linhas vierem de uma sessão
        // antiga do browser ou de uma importação que não recalculou, gravar o
        // valor tal como está perpetuaria médias em 0 na base de dados.
        const rulesForSave = normalizeGradeRules(this.db.settings?.gradeRules as any);
        const mac1 = typeof row.mac1 === 'number' ? row.mac1 : 0;
        const npp1 = typeof row.npp1 === 'number' ? row.npp1 : 0;
        const npt1 = typeof row.npt1 === 'number' ? row.npt1 : 0;
        const mac2 = typeof row.mac2 === 'number' ? row.mac2 : 0;
        const npp2 = typeof row.npp2 === 'number' ? row.npp2 : 0;
        const npt2 = typeof row.npt2 === 'number' ? row.npt2 : 0;
        const mac3 = typeof row.mac3 === 'number' ? row.mac3 : 0;
        const npp3 = typeof row.npp3 === 'number' ? row.npp3 : 0;
        const npt3 = typeof row.npt3 === 'number' ? row.npt3 : 0;
        const mt1Calc = calculateMT(mac1, npp1, npt1, rulesForSave);
        const mt2Calc = calculateMT(mac2, npp2, npt2, rulesForSave);
        const mt3Calc = calculateMT(mac3, npp3, npt3, rulesForSave);
        const mfdCalc = calculateMFD(mt1Calc, mt2Calc, mt3Calc, row.pg, rulesForSave);
        const mfdVal = typeof mfdCalc === 'number' ? mfdCalc : 10;
        const caVal = calculateCA(mfdVal) as number;
        const rec: StudentTrimesterRecord = {
          subjectId,
          subjectName,
          mac1, npp1, npt1, mt1: typeof mt1Calc === 'number' ? mt1Calc : 0,
          mac2, npp2, npt2, mt2: typeof mt2Calc === 'number' ? mt2Calc : 0,
          mac3, npp3, npt3, mt3: typeof mt3Calc === 'number' ? mt3Calc : 0,
          mfd: mfdVal,
          pg: typeof row.pg === 'number' ? row.pg : undefined,
          ca: caVal,
          situation: row.isDesistente ? 'Desistente' : (mfdVal >= 10 ? 'Aprovado' : 'Exame de Recurso')
        };

        if (existingIdx >= 0) {
          student.trimesterGrades[existingIdx] = rec;
        } else {
          student.trimesterGrades.push(rec);
        }

        // Also update disciplineGrades
        if (!student.disciplineGrades) student.disciplineGrades = [];
        const dIdx = student.disciplineGrades.findIndex(
          (d) => d.subject.toLowerCase() === subjectName.toLowerCase()
        );
        if (dIdx >= 0) {
          student.disciplineGrades[dIdx].score = mfdVal;
        } else {
          student.disciplineGrades.push({ subject: subjectName, score: mfdVal, maxScore: 20 });
        }

        // Recalculate average
        if (student.trimesterGrades.length > 0) {
          const sum = student.trimesterGrades.reduce((acc, curr) => acc + curr.mfd, 0);
          student.currentAverage = Math.round((sum / student.trimesterGrades.length) * 10) / 10;
        }
      }
    });

    // Add Institutional Audit Log
    this.addAuditLog({
      userName: userName || this.db.currentUser?.name || 'Prof. Titular',
      userRole: this.db.currentUser?.roleTitle || 'Professor',
      action: 'Lançamento de Notas',
      details: `Notas atualizadas na disciplina de ${subjectName} (${classObj?.name || classId}) para ${rows.length} alunos.`,
      module: 'pautas',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });

    this.notify();
  }

  // 3-Trimester Academic Records for Report Card
  public getStudentThreeTrimesterGrades(studentId: string): StudentTrimesterRecord[] {
    const student = (this.db?.students || []).find((s) => String(s.id) === String(studentId));
    if (!student) return [];

    // 1. Return stored trimesterGrades if already available (real notes already homologadas/lançadas).
    //    Recalcula MT1/MT2/MT3/MFD a partir do MAC/NPP/NPT gravados em vez de confiar
    //    no mt1/mfd tal como está persistido — registos antigos/importados podiam ter
    //    ficado com mt1/mt2/mt3/mfd fixados em 0 apesar do MAC/NPP/NPT estarem lançados,
    //    fazendo o boletim mostrar médias erradas para sempre.
    if (student.trimesterGrades && student.trimesterGrades.length > 0) {
      const rules = normalizeGradeRules(this.db.settings?.gradeRules as any);
      return student.trimesterGrades.map((rec) => {
        const mt1 = calculateMT(rec.mac1, rec.npp1, rec.npt1, rules);
        const mt2 = calculateMT(rec.mac2, rec.npp2, rec.npt2, rules);
        const mt3 = calculateMT(rec.mac3, rec.npp3, rec.npt3, rules);
        const mfdCalc = calculateMFD(mt1, mt2, mt3, rec.pg ?? '', rules);
        const mfd = typeof mfdCalc === 'number' ? mfdCalc : 0;
        return {
          ...rec,
          mt1: typeof mt1 === 'number' ? mt1 : 0,
          mt2: typeof mt2 === 'number' ? mt2 : 0,
          mt3: typeof mt3 === 'number' ? mt3 : 0,
          mfd,
          ca: calculateCA(mfd) as number
        };
      });
    }

    // 2. Sem notas trimestrais guardadas ainda: procurar notas REALMENTE lançadas nas
    //    mini-pautas da turma do aluno, disciplina a disciplina. Nunca se inventam notas —
    //    um boletim de um aluno sem avaliações reais deve mostrar as disciplinas vazias,
    //    prontas a preencher, e não uma média "realista" fabricada.
    const classObj = (this.db?.classes || []).find(
      (c) => String(c.id) === String(student.classId) || c.name === student.className
    );
    const cycle = student.cycle || classObj?.cycle || '';

    const subjectsForCycle = (this.db.subjects || []).filter(
      (s) => !cycle || !s.cycle || s.cycle === cycle || s.cycle.includes('Secundário') || s.cycle.includes('Médio')
    );

    const records: StudentTrimesterRecord[] = [];

    subjectsForCycle.forEach((subj) => {
      const row = student.classId
        ? this.db.miniPautasStore?.[student.classId]?.[subj.id]?.find(
            (r: any) => String(r.studentId) === String(student.id) || String(r.num) === String(student.procNumber)
          )
        : null;

      // Só inclui a disciplina no boletim se existir pelo menos uma nota real lançada.
      const hasRealData =
        row &&
        (typeof row.mt1 === 'number' ||
          typeof row.mt2 === 'number' ||
          typeof row.mt3 === 'number' ||
          typeof row.mfd === 'number');
      if (!hasRealData) return;

      // Recalcula MT1/MT2/MT3/MFD a partir do MAC/NPP/NPT lançados na mini-pauta em
      // vez de confiar no mt1/mfd tal como está guardado (mesma correção do caso 1
      // acima) — evita médias "presas" em 0 no boletim do aluno.
      const rules = normalizeGradeRules(this.db.settings?.gradeRules as any);
      const mac1 = typeof row.mac1 === 'number' ? row.mac1 : 0;
      const npp1 = typeof row.npp1 === 'number' ? row.npp1 : 0;
      const npt1 = typeof row.npt1 === 'number' ? row.npt1 : 0;
      const mac2 = typeof row.mac2 === 'number' ? row.mac2 : 0;
      const npp2 = typeof row.npp2 === 'number' ? row.npp2 : 0;
      const npt2 = typeof row.npt2 === 'number' ? row.npt2 : 0;
      const mac3 = typeof row.mac3 === 'number' ? row.mac3 : 0;
      const npp3 = typeof row.npp3 === 'number' ? row.npp3 : 0;
      const npt3 = typeof row.npt3 === 'number' ? row.npt3 : 0;
      const mt1Calc = calculateMT(mac1, npp1, npt1, rules);
      const mt2Calc = calculateMT(mac2, npp2, npt2, rules);
      const mt3Calc = calculateMT(mac3, npp3, npt3, rules);
      const mfdCalc = calculateMFD(mt1Calc, mt2Calc, mt3Calc, row.pg, rules);
      const mfd = typeof mfdCalc === 'number' ? mfdCalc : 0;
      records.push({
        subjectId: subj.id,
        subjectName: subj.name,
        mac1, npp1, npt1, mt1: typeof mt1Calc === 'number' ? mt1Calc : 0,
        mac2, npp2, npt2, mt2: typeof mt2Calc === 'number' ? mt2Calc : 0,
        mac3, npp3, npt3, mt3: typeof mt3Calc === 'number' ? mt3Calc : 0,
        mfd,
        pg: typeof row.pg === 'number' ? row.pg : undefined,
        ca: calculateCA(mfd) as number,
        situation: row.isDesistente ? 'Desistente' : (mfd >= 10 ? 'Aprovado' : 'Exame de Recurso')
      });
    });

    // Nunca persistir notas fabricadas na base de dados: apenas devolve o que existe
    // realmente lançado. Se `records` ficar vazio, o boletim deve indicar "Sem notas lançadas".
    return records;
  }

  // 4. Assiduidade REAL do Ano Letivo para o Boletim (nunca fabricada).
  // Carga horária prevista = nº de Tempos Lectivos semanais da turma (Horário/TimetableEntry)
  // x nº de semanas letivas configuradas em Configurações > Ano Letivo (trimesterSchedules / academicWeeks).
  // Presenças/Faltas = contagem real de status por aluno em todas as AttendanceSheet gravadas para a turma.
  public getStudentAttendanceSummary(studentId: string): {
    scheduledLessonsPerWeek: number;
    totalAcademicWeeks: number;
    totalScheduledLessons: number;
    presences: number;
    excusedAbsences: number;
    unexcusedAbsences: number;
    totalRecordedLessons: number;
    attendanceRatePercent: number;
  } {
    const student = (this.db?.students || []).find((s) => String(s.id) === String(studentId));

    const empty = {
      scheduledLessonsPerWeek: 0,
      totalAcademicWeeks: 0,
      totalScheduledLessons: 0,
      presences: 0,
      excusedAbsences: 0,
      unexcusedAbsences: 0,
      totalRecordedLessons: 0,
      attendanceRatePercent: 0
    };
    if (!student) return empty;

    // Carga horária prevista: nº real de Tempos Lectivos/semana alocados à turma no Horário.
    const classId = student.classId;
    const scheduledLessonsPerWeek = (this.db.timetable || []).filter(
      (t) => String(t.classId) === String(classId)
    ).length;

    // Nº real de semanas letivas configuradas (soma das 3 semanas dos trimestres; recorre a
    // "academicWeeks" apenas se as semanas por trimestre não estiverem configuradas).
    const schedules = this.db.settings?.trimesterSchedules;
    let totalAcademicWeeks = 0;
    if (schedules) {
      totalAcademicWeeks = ([schedules.t1, schedules.t2, schedules.t3] as any[]).reduce(
        (sum, t) => sum + (Number(t?.weeksCountNumber) || parseWeeksLabel(t?.weeksCount)),
        0
      );
    }
    if (!totalAcademicWeeks) {
      totalAcademicWeeks =
        Number(this.db.settings?.academicWeeksNumber) || parseWeeksLabel(this.db.settings?.academicWeeks);
    }

    const totalScheduledLessons = scheduledLessonsPerWeek * totalAcademicWeeks;

    // Contagem real de presenças/faltas nas cadernetas (AttendanceSheet) já gravadas para a turma.
    let presences = 0;
    let excusedAbsences = 0;
    let unexcusedAbsences = 0;

    (this.db.attendanceSheets || []).forEach((sheet) => {
      if (String(sheet.classId) !== String(classId)) return;
      const rec = (sheet.students || []).find(
        (st) => String(st.studentId) === String(studentId)
      );
      if (!rec) return;
      if (rec.status === 'P' || rec.status === 'A') presences += 1;
      else if (rec.status === 'FJ') excusedAbsences += 1;
      else if (rec.status === 'FI') unexcusedAbsences += 1;
    });

    const totalRecordedLessons = presences + excusedAbsences + unexcusedAbsences;

    // Se ainda não há cadernetas suficientes gravadas, não fabricamos uma percentagem: usamos
    // o que existe realmente lançado; só como último recurso aproveitamos o valor histórico
    // já guardado no cadastro do aluno (nunca um valor fixo tipo "95").
    const attendanceRatePercent =
      totalRecordedLessons > 0
        ? Math.round((presences / totalRecordedLessons) * 1000) / 10
        : Number(student.attendanceRate) || 0;

    return {
      scheduledLessonsPerWeek,
      totalAcademicWeeks,
      totalScheduledLessons,
      presences,
      excusedAbsences,
      unexcusedAbsences,
      totalRecordedLessons,
      attendanceRatePercent
    };
  }

  // 5. Apreciação real do Conselho de Turma — preenchida manualmente pelo Diretor de Turma,
  // nunca gerada automaticamente a partir da média do aluno.
  public updateStudentCouncilAppreciation(studentId: string, text: string, updatedByName?: string) {
    this.db.students = this.db.students.map((s) => {
      if (String(s.id) !== String(studentId)) return s;
      return {
        ...s,
        councilAppreciation: text,
        councilAppreciationUpdatedBy: updatedByName || this.db.currentUser?.name || 'Diretor de Turma',
        councilAppreciationUpdatedAt: new Date().toISOString()
      };
    });

    this.addAuditLog({
      userName: updatedByName || this.db.currentUser?.name || 'Diretor de Turma',
      userRole: this.db.currentUser?.roleTitle || 'Diretor de Turma',
      action: 'Apreciação do Conselho de Turma',
      details: `Apreciação do Conselho de Turma atualizada para o aluno ${
        (this.db.students || []).find((s) => String(s.id) === String(studentId))?.name || studentId
      }.`,
      module: 'alunos',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });

    this.notify();
  }

  // =========================================================================
  // RECURSOS HUMANOS → 1. FOLHA DE PAGAMENTO
  // =========================================================================

  public getPayrollRecords(): PayrollRecord[] {
    return this.db.payrollRecords || [];
  }

  public getPayrollEligiblePeople() {
    return listEligiblePeople(this.db);
  }

  /** Gera (ou regenera, se ainda pendente) o recibo de um mês/ano para uma pessoa. */
  public generatePayrollRecord(input: {
    personId: string;
    referenceMonth: number;
    referenceYear: number;
    allowancesOverrideKz?: number;
    bonusKz?: number;
    bonusDescription?: string;
    otherDeductionsKz?: number;
    otherDeductionsDescription?: string;
    notes?: string;
  }): { success: boolean; error?: string; record?: PayrollRecord } {
    const person = listEligiblePeople(this.db).find((p) => p.id === input.personId);
    if (!person) return { success: false, error: 'Docente ou funcionário não encontrado.' };
    if (!input.referenceMonth || input.referenceMonth < 1 || input.referenceMonth > 12) {
      return { success: false, error: 'Mês de referência inválido.' };
    }
    if (!input.referenceYear) return { success: false, error: 'Ano de referência inválido.' };

    const existing = (this.db.payrollRecords || []).find(
      (r) => r.personId === input.personId && r.referenceMonth === input.referenceMonth && r.referenceYear === input.referenceYear
    );
    if (existing && existing.status === 'pago') {
      return { success: false, error: 'Este recibo já foi pago — cancele o pagamento antes de o regenerar.' };
    }

    const tax = getEffectivePayrollTaxSettings(this.db);
    const baseSalaryKz = person.baseSalaryKz || 0;
    const allowancesKz = input.allowancesOverrideKz != null ? input.allowancesOverrideKz : person.allowancesKz || 0;
    const bonusKz = input.bonusKz || 0;
    const otherDeductionsKz = input.otherDeductionsKz || 0;

    const computed = computePayroll({ baseSalaryKz, allowancesKz, bonusKz, otherDeductionsKz }, tax);
    const now = new Date().toISOString();

    const record: PayrollRecord = {
      id: existing?.id || `pay-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      personId: person.id,
      personType: person.type,
      personName: person.name,
      personRole: person.role,
      department: person.department,
      academicYear: this.db.settings?.currentAcademicYear || '',
      referenceMonth: input.referenceMonth,
      referenceYear: input.referenceYear,
      baseSalaryKz,
      allowancesKz,
      allowanceDescription: person.allowanceDescription,
      bonusKz,
      bonusDescription: input.bonusDescription,
      otherDeductionsKz,
      otherDeductionsDescription: input.otherDeductionsDescription,
      grossSalaryKz: computed.grossSalaryKz,
      inssEmployeeKz: computed.inssEmployeeKz,
      irtKz: computed.irtKz,
      netSalaryKz: computed.netSalaryKz,
      status: 'pendente',
      bankName: person.bankName,
      iban: person.iban,
      generatedAt: now,
      generatedByName: this.currentActorName(),
      notes: input.notes
    };

    this.db.payrollRecords = existing
      ? (this.db.payrollRecords || []).map((r) => (r.id === existing.id ? record : r))
      : [record, ...(this.db.payrollRecords || [])];

    this.addAuditLog({
      userName: this.currentActorName(),
      action: existing ? 'Recibo de Vencimento Recalculado' : 'Recibo de Vencimento Gerado',
      details: `Recibo de ${person.name} referente a ${record.referenceMonth}/${record.referenceYear} — líquido ${record.netSalaryKz.toLocaleString('pt-PT')} Kz.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    } as any);

    this.notify();
    return { success: true, record };
  }

  /** Gera recibos em lote para todas as pessoas elegíveis que ainda não têm recibo nesse mês. */
  public bulkGeneratePayroll(referenceMonth: number, referenceYear: number): { generated: number; skipped: number } {
    const people = listEligiblePeople(this.db);
    let generated = 0;
    let skipped = 0;
    people.forEach((person) => {
      const existing = (this.db.payrollRecords || []).find(
        (r) => r.personId === person.id && r.referenceMonth === referenceMonth && r.referenceYear === referenceYear
      );
      if (existing) {
        skipped += 1;
        return;
      }
      const result = this.generatePayrollRecord({ personId: person.id, referenceMonth, referenceYear });
      if (result.success) generated += 1;
      else skipped += 1;
    });
    return { generated, skipped };
  }

  public markPayrollPaid(
    id: string,
    paymentMethod: PayrollRecord['paymentMethod'],
    paymentDate?: string
  ): { success: boolean; error?: string } {
    const record = (this.db.payrollRecords || []).find((r) => r.id === id);
    if (!record) return { success: false, error: 'Recibo não encontrado.' };
    if (record.status === 'pago') return { success: false, error: 'Este recibo já está marcado como pago.' };

    this.db.payrollRecords = (this.db.payrollRecords || []).map((r) =>
      r.id === id
        ? { ...r, status: 'pago', paymentMethod, paymentDate: paymentDate || new Date().toISOString().slice(0, 10), paidByName: this.currentActorName() }
        : r
    );

    this.addAuditLog({
      userName: this.currentActorName(),
      action: 'Pagamento de Salário Confirmado',
      details: `Pagamento confirmado para ${record.personName} — ${record.referenceMonth}/${record.referenceYear}.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#166534'
    } as any);

    this.notify();
    return { success: true };
  }

  public cancelPayrollRecord(id: string, reason?: string): { success: boolean; error?: string } {
    const record = (this.db.payrollRecords || []).find((r) => r.id === id);
    if (!record) return { success: false, error: 'Recibo não encontrado.' };

    this.db.payrollRecords = (this.db.payrollRecords || []).map((r) =>
      r.id === id
        ? { ...r, status: 'cancelado', cancelledByName: this.currentActorName(), cancelledAt: new Date().toISOString(), notes: reason || r.notes }
        : r
    );

    this.addAuditLog({
      userName: this.currentActorName(),
      action: 'Recibo de Vencimento Cancelado',
      details: `Recibo de ${record.personName} (${record.referenceMonth}/${record.referenceYear}) cancelado.${reason ? ` Motivo: ${reason}` : ''}`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#b91c1c'
    } as any);

    this.notify();
    return { success: true };
  }

  public deletePayrollRecord(id: string): { success: boolean; error?: string } {
    const record = (this.db.payrollRecords || []).find((r) => r.id === id);
    if (!record) return { success: false, error: 'Recibo não encontrado.' };
    if (record.status === 'pago') return { success: false, error: 'Não é possível eliminar um recibo já pago — cancele-o primeiro.' };
    this.db.payrollRecords = (this.db.payrollRecords || []).filter((r) => r.id !== id);
    this.notify();
    return { success: true };
  }

  public getPayrollTaxSettings() {
    return getEffectivePayrollTaxSettings(this.db);
  }

  public savePayrollTaxSettings(settings: InstitutionSettings['payrollTaxSettings']): { success: boolean } {
    this.db.settings = { ...this.db.settings, payrollTaxSettings: settings };
    this.notify();
    return { success: true };
  }

  // =========================================================================
  // RECURSOS HUMANOS → 2. AVALIAÇÃO DE DESEMPENHO DOCENTE
  // =========================================================================

  public getTeacherEvaluations(): TeacherEvaluation[] {
    return this.db.teacherEvaluations || [];
  }

  public getDefaultEvaluationCriteria(teacherId: string): { success: boolean; error?: string; criteria?: TeacherEvaluationCriterionScore[] } {
    const teacher = (this.db.teachers || []).find((t) => t.id === teacherId);
    if (!teacher) return { success: false, error: 'Professor não encontrado.' };
    return { success: true, criteria: buildDefaultCriteria(teacher, this.db) };
  }

  public saveTeacherEvaluation(input: {
    id?: string;
    teacherId: string;
    period: string;
    criteria: TeacherEvaluationCriterionScore[];
    strengths?: string;
    areasToImprove?: string;
    developmentPlan?: string;
    status: TeacherEvaluation['status'];
  }): { success: boolean; error?: string; evaluation?: TeacherEvaluation } {
    const teacher = (this.db.teachers || []).find((t) => t.id === input.teacherId);
    if (!teacher) return { success: false, error: 'Professor não encontrado.' };
    if (!input.period?.trim()) return { success: false, error: 'Indique o período da avaliação.' };
    if (!input.criteria || input.criteria.length === 0) return { success: false, error: 'A avaliação precisa de pelo menos um critério.' };

    const finalScore = computeFinalScore(input.criteria);
    const classification = classifyScore(finalScore);
    const now = new Date().toISOString();
    const academicYear = this.db.settings?.currentAcademicYear || '';

    if (input.id) {
      const current = (this.db.teacherEvaluations || []).find((e) => e.id === input.id);
      if (!current) return { success: false, error: 'Avaliação não encontrada.' };
      if (current.status === 'homologada') return { success: false, error: 'Uma avaliação homologada não pode ser editada.' };
      const updated: TeacherEvaluation = {
        ...current,
        period: input.period,
        criteria: input.criteria,
        finalScore,
        classification,
        strengths: input.strengths,
        areasToImprove: input.areasToImprove,
        developmentPlan: input.developmentPlan,
        status: input.status,
        updatedAt: now
      };
      this.db.teacherEvaluations = (this.db.teacherEvaluations || []).map((e) => (e.id === input.id ? updated : e));
      this.notify();
      return { success: true, evaluation: updated };
    }

    const created: TeacherEvaluation = {
      id: `eval-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      teacherId: teacher.id,
      teacherName: teacher.name,
      department: teacher.department,
      academicYear,
      period: input.period,
      evaluatorName: this.currentActorName(),
      evaluationDate: now.slice(0, 10),
      criteria: input.criteria,
      finalScore,
      classification,
      strengths: input.strengths,
      areasToImprove: input.areasToImprove,
      developmentPlan: input.developmentPlan,
      status: input.status,
      createdAt: now
    };

    this.db.teacherEvaluations = [created, ...(this.db.teacherEvaluations || [])];

    this.addAuditLog({
      userName: this.currentActorName(),
      action: 'Avaliação de Desempenho Docente Registada',
      details: `Avaliação de ${teacher.name} (${input.period}) — nota final ${finalScore.toFixed(2)} (${classification}).`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    } as any);

    this.notify();
    return { success: true, evaluation: created };
  }

  public homologateTeacherEvaluation(id: string): { success: boolean; error?: string } {
    const evaluation = (this.db.teacherEvaluations || []).find((e) => e.id === id);
    if (!evaluation) return { success: false, error: 'Avaliação não encontrada.' };
    if (evaluation.status === 'homologada') return { success: false, error: 'Esta avaliação já está homologada.' };

    this.db.teacherEvaluations = (this.db.teacherEvaluations || []).map((e) =>
      e.id === id ? { ...e, status: 'homologada', updatedAt: new Date().toISOString() } : e
    );

    this.addAuditLog({
      userName: this.currentActorName(),
      action: 'Avaliação de Desempenho Docente Homologada',
      details: `Avaliação de ${evaluation.teacherName} (${evaluation.period}) homologada.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#166534'
    } as any);

    this.notify();
    return { success: true };
  }

  public deleteTeacherEvaluation(id: string): { success: boolean; error?: string } {
    const evaluation = (this.db.teacherEvaluations || []).find((e) => e.id === id);
    if (!evaluation) return { success: false, error: 'Avaliação não encontrada.' };
    if (evaluation.status === 'homologada') return { success: false, error: 'Uma avaliação homologada não pode ser eliminada.' };
    this.db.teacherEvaluations = (this.db.teacherEvaluations || []).filter((e) => e.id !== id);
    this.notify();
    return { success: true };
  }

  // =========================================================================
  // RECURSOS HUMANOS → 3. FÉRIAS & LICENÇAS
  // =========================================================================

  public getLeaveRequests(): LeaveRequest[] {
    return this.db.leaveRequests || [];
  }

  public getLeaveEligiblePeople() {
    return listLeaveEligiblePeople(this.db);
  }

  public createLeaveRequest(input: {
    personId: string;
    type: LeaveRequest['type'];
    typeDescription?: string;
    startDate: string;
    endDate: string;
    reason?: string;
  }): { success: boolean; error?: string; request?: LeaveRequest } {
    const person = listLeaveEligiblePeople(this.db).find((p) => p.id === input.personId);
    if (!person) return { success: false, error: 'Docente ou funcionário não encontrado.' };
    if (!input.startDate || !input.endDate) return { success: false, error: 'Indique a data de início e de fim.' };
    if (input.endDate < input.startDate) return { success: false, error: 'A data de fim não pode ser anterior à data de início.' };
    if (input.type === 'outro' && !input.typeDescription?.trim()) {
      return { success: false, error: 'Descreva o tipo de licença quando escolher "Outro".' };
    }
    if (hasOverlappingLeave(input.personId, input.startDate, input.endDate, this.db.leaveRequests || [])) {
      return { success: false, error: 'Já existe um pedido pendente ou aprovado para esta pessoa que se sobrepõe a estas datas.' };
    }

    const now = new Date().toISOString();
    const created: LeaveRequest = {
      id: `leave-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      personId: person.id,
      personType: person.type,
      personName: person.name,
      personRole: person.role,
      department: person.department,
      type: input.type,
      typeDescription: input.typeDescription,
      startDate: input.startDate,
      endDate: input.endDate,
      workingDaysCount: countWorkingDays(input.startDate, input.endDate),
      reason: input.reason,
      status: 'pendente',
      academicYear: this.db.settings?.currentAcademicYear || '',
      requestedAt: now,
      requestedByName: this.currentActorName()
    };

    this.db.leaveRequests = [created, ...(this.db.leaveRequests || [])];

    this.addAuditLog({
      userName: this.currentActorName(),
      action: 'Pedido de Férias/Licença Registado',
      details: `${person.name} — ${created.type} de ${created.startDate} a ${created.endDate} (${created.workingDaysCount} dia(s) úteis).`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    } as any);

    this.notify();
    return { success: true, request: created };
  }

  public decideLeaveRequest(
    id: string,
    decision: 'aprovado' | 'rejeitado',
    decisionNotes?: string
  ): { success: boolean; error?: string } {
    const request = (this.db.leaveRequests || []).find((r) => r.id === id);
    if (!request) return { success: false, error: 'Pedido não encontrado.' };
    if (request.status !== 'pendente') return { success: false, error: 'Este pedido já foi decidido.' };

    this.db.leaveRequests = (this.db.leaveRequests || []).map((r) =>
      r.id === id
        ? { ...r, status: decision, decidedByName: this.currentActorName(), decidedAt: new Date().toISOString(), decisionNotes }
        : r
    );

    this.addAuditLog({
      userName: this.currentActorName(),
      action: decision === 'aprovado' ? 'Pedido de Férias/Licença Aprovado' : 'Pedido de Férias/Licença Rejeitado',
      details: `${request.personName} — ${request.startDate} a ${request.endDate}.${decisionNotes ? ` Nota: ${decisionNotes}` : ''}`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: decision === 'aprovado' ? '#166534' : '#b91c1c'
    } as any);

    this.notify();
    return { success: true };
  }

  public completeLeaveRequest(id: string): { success: boolean; error?: string } {
    const request = (this.db.leaveRequests || []).find((r) => r.id === id);
    if (!request) return { success: false, error: 'Pedido não encontrado.' };
    if (request.status !== 'aprovado') return { success: false, error: 'Só um pedido aprovado pode ser marcado como concluído.' };
    this.db.leaveRequests = (this.db.leaveRequests || []).map((r) => (r.id === id ? { ...r, status: 'concluido' } : r));
    this.notify();
    return { success: true };
  }

  public cancelLeaveRequest(id: string, reason?: string): { success: boolean; error?: string } {
    const request = (this.db.leaveRequests || []).find((r) => r.id === id);
    if (!request) return { success: false, error: 'Pedido não encontrado.' };
    if (request.status === 'concluido') return { success: false, error: 'Um pedido já concluído não pode ser cancelado.' };
    this.db.leaveRequests = (this.db.leaveRequests || []).map((r) =>
      r.id === id ? { ...r, status: 'cancelado', decisionNotes: reason || r.decisionNotes, decidedByName: this.currentActorName(), decidedAt: new Date().toISOString() } : r
    );
    this.notify();
    return { success: true };
  }

  public deleteLeaveRequest(id: string): { success: boolean; error?: string } {
    const request = (this.db.leaveRequests || []).find((r) => r.id === id);
    if (!request) return { success: false, error: 'Pedido não encontrado.' };
    this.db.leaveRequests = (this.db.leaveRequests || []).filter((r) => r.id !== id);
    this.notify();
    return { success: true };
  }

  // ------------------------------------------------------------------
  // Comunicação — 2. Notificações SMS/WhatsApp, 3. Reuniões Pais-
  // Professores, 4. Chat Encarregado ↔ Escola
  // ------------------------------------------------------------------
  private comunicacaoAudit(action: string, details: string, badgeColor = '#0b1f3a') {
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action,
      details,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor
    });
  }

  private newComunicacaoId(prefix: string): string {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  }

  // ---------- 2. Notificações SMS/WhatsApp ----------

  public getSmsWhatsappNotifications(): SmsWhatsappNotification[] {
    return this.db.smsWhatsappNotifications || [];
  }

  public saveNotificationDraft(
    input: { id?: string } & NotificationFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; notification?: SmsWhatsappNotification } {
    const errors = validateNotification(input);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const students = this.db.students || [];
    const className = input.classId ? (this.db.classes || []).find((c) => String(c.id) === String(input.classId))?.name : undefined;
    const now = new Date().toISOString();

    if (input.id) {
      const current = (this.db.smsWhatsappNotifications || []).find((n) => n.id === input.id);
      if (!current) return { success: false, error: 'Notificação não encontrada.' };
      if (current.status !== 'rascunho' && current.status !== 'agendada') {
        return { success: false, error: 'Só é possível editar notificações em rascunho ou agendadas.' };
      }
      const updated: SmsWhatsappNotification = {
        ...current,
        channel: input.channel,
        audienceType: input.audienceType,
        classId: input.classId,
        className,
        studentIds: input.studentIds,
        title: input.title.trim(),
        message: input.message.trim(),
        scheduledFor: input.scheduledFor || undefined,
        status: input.scheduledFor ? 'agendada' : 'rascunho'
      };
      this.db.smsWhatsappNotifications = (this.db.smsWhatsappNotifications || []).map((n) => (n.id === input.id ? updated : n));
      this.notify();
      return { success: true, notification: updated };
    }

    const created: SmsWhatsappNotification = {
      id: this.newComunicacaoId('notif'),
      code: generateNotificationCode((this.db.smsWhatsappNotifications || []).map((n) => n.code)),
      channel: input.channel,
      audienceType: input.audienceType,
      classId: input.classId,
      className,
      studentIds: input.studentIds,
      title: input.title.trim(),
      message: input.message.trim(),
      status: input.scheduledFor ? 'agendada' : 'rascunho',
      scheduledFor: input.scheduledFor || undefined,
      recipients: [],
      sentCount: 0,
      failedCount: 0,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.smsWhatsappNotifications = [created, ...(this.db.smsWhatsappNotifications || [])];
    this.notify();
    return { success: true, notification: created };
  }

  /**
   * "Envia" a notificação: constrói a lista de destinatários a partir do
   * público-alvo e regista o resultado (não há integração real com uma
   * operadora/gateway — a entrega é registada como bem-sucedida para todos os
   * destinatários com telefone válido, o que é suficiente para efeitos de
   * auditoria e histórico de comunicação com a comunidade escolar).
   */
  public sendNotification(id: string): { success: boolean; error?: string; notification?: SmsWhatsappNotification } {
    const current = (this.db.smsWhatsappNotifications || []).find((n) => n.id === id);
    if (!current) return { success: false, error: 'Notificação não encontrada.' };
    if (current.status === 'enviada') return { success: false, error: 'Esta notificação já foi enviada.' };

    const recipients = buildRecipientsForAudience(
      current.audienceType,
      this.db.students || [],
      this.db.teachers || [],
      this.db.funcionarios || [],
      current.classId,
      current.studentIds
    );

    if (recipients.length === 0) {
      const failed: SmsWhatsappNotification = { ...current, status: 'falhada', recipients: [], sentCount: 0, failedCount: 0 };
      this.db.smsWhatsappNotifications = (this.db.smsWhatsappNotifications || []).map((n) => (n.id === id ? failed : n));
      this.notify();
      return { success: false, error: 'Não foram encontrados destinatários com telefone válido para o público-alvo escolhido.' };
    }

    const delivered = recipients.map((r) => ({ ...r, deliveryStatus: 'entregue' as const }));
    const updated: SmsWhatsappNotification = {
      ...current,
      status: 'enviada',
      recipients: delivered,
      sentCount: delivered.length,
      failedCount: 0,
      sentAt: new Date().toISOString()
    };
    this.db.smsWhatsappNotifications = (this.db.smsWhatsappNotifications || []).map((n) => (n.id === id ? updated : n));
    this.comunicacaoAudit(
      'Envio de Notificação em Massa',
      `Notificação "${updated.title}" (${updated.code}) enviada por ${CHANNEL_LABELS[updated.channel]} a ${delivered.length} destinatário(s) — ${AUDIENCE_TYPE_LABELS[updated.audienceType]}.`
    );
    this.notify();
    return { success: true, notification: updated };
  }

  public deleteSmsWhatsappNotification(id: string): { success: boolean; error?: string } {
    const target = (this.db.smsWhatsappNotifications || []).find((n) => n.id === id);
    if (!target) return { success: false, error: 'Notificação não encontrada.' };
    this.db.smsWhatsappNotifications = (this.db.smsWhatsappNotifications || []).filter((n) => n.id !== id);
    this.notify();
    return { success: true };
  }

  // ---------- 3. Reuniões Pais-Professores ----------

  public getMeetings(): ParentTeacherMeeting[] {
    return this.db.parentTeacherMeetings || [];
  }

  public saveMeeting(
    input: { id?: string } & MeetingFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; meeting?: ParentTeacherMeeting } {
    const errors = validateMeeting(input);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    const teacher = (this.db.teachers || []).find((t) => t.id === input.teacherId);
    if (!teacher) return { success: false, error: 'Professor não encontrado.' };
    const className = input.classId ? (this.db.classes || []).find((c) => String(c.id) === String(input.classId))?.name : undefined;
    const participants = buildMeetingParticipants(input.type, this.db.students || [], input.classId, input.studentIds);
    const now = new Date().toISOString();

    if (input.id) {
      const current = (this.db.parentTeacherMeetings || []).find((m) => m.id === input.id);
      if (!current) return { success: false, error: 'Reunião não encontrada.' };
      if (current.status !== 'agendada') return { success: false, error: 'Só uma reunião agendada pode ser editada.' };
      const updated: ParentTeacherMeeting = {
        ...current,
        type: input.type,
        title: input.title.trim(),
        teacherId: teacher.id,
        teacherName: teacher.name,
        classId: input.classId,
        className,
        date: input.date,
        startTime: input.startTime,
        endTime: input.endTime,
        location: input.location?.trim() || undefined,
        agenda: input.agenda?.trim() || undefined,
        participants,
        updatedAt: now,
        updatedBy: this.currentActorName()
      };
      this.db.parentTeacherMeetings = (this.db.parentTeacherMeetings || []).map((m) => (m.id === input.id ? updated : m));
      this.notify();
      return { success: true, meeting: updated };
    }

    const created: ParentTeacherMeeting = {
      id: this.newComunicacaoId('reu'),
      code: generateMeetingCode((this.db.parentTeacherMeetings || []).map((m) => m.code)),
      type: input.type,
      title: input.title.trim(),
      teacherId: teacher.id,
      teacherName: teacher.name,
      classId: input.classId,
      className,
      date: input.date,
      startTime: input.startTime,
      endTime: input.endTime,
      location: input.location?.trim() || undefined,
      agenda: input.agenda?.trim() || undefined,
      status: 'agendada',
      participants,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.parentTeacherMeetings = [created, ...(this.db.parentTeacherMeetings || [])];
    this.comunicacaoAudit(
      'Agendamento de Reunião Pais-Professores',
      `Reunião "${created.title}" (${created.code}) agendada com ${created.teacherName} para ${created.date} — ${MEETING_STATUS_META[created.status].label}.`
    );
    this.notify();
    return { success: true, meeting: created };
  }

  public updateMeetingParticipantStatus(
    meetingId: string,
    studentId: string,
    status: MeetingParticipantStatus
  ): { success: boolean; error?: string } {
    const current = (this.db.parentTeacherMeetings || []).find((m) => m.id === meetingId);
    if (!current) return { success: false, error: 'Reunião não encontrada.' };
    this.db.parentTeacherMeetings = (this.db.parentTeacherMeetings || []).map((m) =>
      m.id === meetingId
        ? { ...m, participants: m.participants.map((p) => (p.studentId === studentId ? { ...p, status } : p)) }
        : m
    );
    this.notify();
    return { success: true };
  }

  public completeMeeting(id: string, summary: string): { success: boolean; error?: string } {
    const current = (this.db.parentTeacherMeetings || []).find((m) => m.id === id);
    if (!current) return { success: false, error: 'Reunião não encontrada.' };
    if (!summary.trim()) return { success: false, error: 'Escreva um resumo da reunião antes de a marcar como realizada.' };
    this.db.parentTeacherMeetings = (this.db.parentTeacherMeetings || []).map((m) =>
      m.id === id ? { ...m, status: 'realizada' as const, summary: summary.trim(), updatedAt: new Date().toISOString(), updatedBy: this.currentActorName() } : m
    );
    this.notify();
    return { success: true };
  }

  public cancelMeeting(id: string, reason?: string): { success: boolean; error?: string } {
    const current = (this.db.parentTeacherMeetings || []).find((m) => m.id === id);
    if (!current) return { success: false, error: 'Reunião não encontrada.' };
    this.db.parentTeacherMeetings = (this.db.parentTeacherMeetings || []).map((m) =>
      m.id === id ? { ...m, status: 'cancelada' as const, cancelReason: reason?.trim() || undefined, updatedAt: new Date().toISOString(), updatedBy: this.currentActorName() } : m
    );
    this.notify();
    return { success: true };
  }

  public deleteMeeting(id: string): { success: boolean; error?: string } {
    const target = (this.db.parentTeacherMeetings || []).find((m) => m.id === id);
    if (!target) return { success: false, error: 'Reunião não encontrada.' };
    this.db.parentTeacherMeetings = (this.db.parentTeacherMeetings || []).filter((m) => m.id !== id);
    this.notify();
    return { success: true };
  }

  // ---------- 4. Chat Encarregado ↔ Escola ----------

  public getChatThreads(): GuardianChatThread[] {
    return this.db.guardianChatThreads || [];
  }

  public createChatThread(
    studentId: string,
    subject: string,
    message: string
  ): { success: boolean; error?: string; errors?: string[]; thread?: GuardianChatThread } {
    const errors = validateChatThreadFields(subject, message);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };
    const student = (this.db.students || []).find((s) => s.id === studentId);
    if (!student) return { success: false, error: 'Aluno não encontrado.' };

    const now = new Date().toISOString();
    const firstMessage: ChatMessage = {
      id: this.newComunicacaoId('msg'),
      sender: 'escola',
      senderName: this.currentActorName(),
      content: message.trim(),
      timestamp: now
    };
    const created: GuardianChatThread = {
      id: this.newComunicacaoId('chat'),
      code: generateChatThreadCode((this.db.guardianChatThreads || []).map((t) => t.code)),
      studentId: student.id,
      studentName: student.name,
      studentProcNumber: student.procNumber,
      className: student.className,
      guardianName: student.guardianName,
      guardianPhone: student.guardianPhone,
      subject: subject.trim(),
      status: 'aguarda_resposta',
      messages: [firstMessage],
      lastMessageAt: now,
      createdBy: this.currentActorName(),
      createdAt: now
    };
    this.db.guardianChatThreads = [created, ...(this.db.guardianChatThreads || [])];
    this.comunicacaoAudit('Abertura de Conversa com Encarregado', `Conversa "${created.subject}" (${created.code}) aberta com o encarregado de ${created.studentName}.`);
    this.notify();
    return { success: true, thread: created };
  }

  /** Regista uma nova mensagem na conversa. `sender: 'encarregado'` simula a resposta recebida do encarregado. */
  public addChatMessage(
    threadId: string,
    content: string,
    sender: 'escola' | 'encarregado' = 'escola'
  ): { success: boolean; error?: string; thread?: GuardianChatThread } {
    const current = (this.db.guardianChatThreads || []).find((t) => t.id === threadId);
    if (!current) return { success: false, error: 'Conversa não encontrada.' };
    if (!content.trim()) return { success: false, error: 'Escreva uma mensagem.' };

    const now = new Date().toISOString();
    const message: ChatMessage = {
      id: this.newComunicacaoId('msg'),
      sender,
      senderName: sender === 'escola' ? this.currentActorName() : current.guardianName,
      content: content.trim(),
      timestamp: now
    };
    const updated: GuardianChatThread = {
      ...current,
      messages: [...current.messages, message],
      lastMessageAt: now,
      status: sender === 'escola' ? 'aguarda_resposta' : 'aberta'
    };
    this.db.guardianChatThreads = (this.db.guardianChatThreads || []).map((t) => (t.id === threadId ? updated : t));
    this.notify();
    return { success: true, thread: updated };
  }

  public setChatThreadStatus(id: string, status: ChatThreadStatus): { success: boolean; error?: string } {
    const current = (this.db.guardianChatThreads || []).find((t) => t.id === id);
    if (!current) return { success: false, error: 'Conversa não encontrada.' };
    this.db.guardianChatThreads = (this.db.guardianChatThreads || []).map((t) => (t.id === id ? { ...t, status } : t));
    this.notify();
    return { success: true };
  }

  public deleteChatThread(id: string): { success: boolean; error?: string } {
    const target = (this.db.guardianChatThreads || []).find((t) => t.id === id);
    if (!target) return { success: false, error: 'Conversa não encontrada.' };
    this.db.guardianChatThreads = (this.db.guardianChatThreads || []).filter((t) => t.id !== id);
    this.notify();
    return { success: true };
  }

  // =====================================================================
  // Configurações 9. Backup Automático Agendado
  //
  // Distinto do backup MANUAL da secção 7 (Segurança & Backups), onde o
  // próprio utilizador clica em "Gerar Backup Agora": aqui apenas se
  // configura QUANDO uma rotina deve correr sozinha, e essa rotina escreve
  // no mesmo `settings.backupHistory`, apenas marcada como "Automático"
  // para se distinguir das cópias manuais na mesma tabela.
  // =====================================================================

  public getAutomaticBackupSchedule(): AutomaticBackupSchedule {
    return this.db.settings.automaticBackupSchedule || defaultAutomaticBackupSchedule();
  }

  public updateAutomaticBackupSchedule(partial: Partial<AutomaticBackupSchedule>): AutomaticBackupSchedule {
    const current = this.getAutomaticBackupSchedule();
    const merged: AutomaticBackupSchedule = { ...current, ...partial };
    const updated: AutomaticBackupSchedule = {
      ...merged,
      nextRunIso: merged.enabled ? computeNextRunIso(merged, merged.lastRunIso) : undefined
    };
    this.db.settings = { ...this.db.settings, automaticBackupSchedule: updated };
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Atualização do Agendamento de Backup Automático',
      details: `Agendamento alterado para: ${describeSchedule(updated)}.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return updated;
  }

  /** Verifica se o backup automático agendado já devia ter corrido e, se sim,
   * gera-o e regista-o em `backupHistory` (chamado no arranque da app e
   * periodicamente pela UI da secção 9). */
  public runScheduledBackupIfDue(force = false): { ran: boolean } {
    const schedule = this.getAutomaticBackupSchedule();
    if (!force && !isBackupDue(schedule)) return { ran: false };

    const dbData = this.getDatabase();
    const jsonString = JSON.stringify(dbData);
    const sizeKb = (jsonString.length / 1024).toFixed(1);
    const sizeMb = (jsonString.length / (1024 * 1024)).toFixed(2);
    const sizeLabel = jsonString.length > 1024 * 1024 ? `${sizeMb} MB` : `${sizeKb} KB`;

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const timeStr = `${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
    const filename = `bandmed_backup_auto_${dateStr}_${timeStr}.json`;

    const novoBackup = {
      id: Date.now(),
      arquivo: filename,
      tamanho: sizeLabel,
      data: `Hoje, ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} WAT`,
      status: 'Concluído Automático (AES-256)'
    };

    const retention = Math.max(schedule.retentionCount || 14, 1);
    const history = [novoBackup, ...(this.db.settings.backupHistory || [])].slice(0, retention);
    const nowIso = now.toISOString();
    const updatedSchedule: AutomaticBackupSchedule = {
      ...schedule,
      lastRunIso: nowIso,
      nextRunIso: computeNextRunIso(schedule, nowIso)
    };
    this.db.settings = { ...this.db.settings, backupHistory: history, automaticBackupSchedule: updatedSchedule };

    this.addAuditLog({
      userName: 'Sistema (Agendador Automático)',
      userRole: 'Sistema',
      action: 'Backup Automático Agendado Executado',
      details: `Cópia de segurança automática "${filename}" gerada com sucesso (${sizeLabel}). Retenção: ${retention} cópias.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { ran: true };
  }

  // =====================================================================
  // Configurações 10. Política de Proteção de Dados Pessoais (Lei 22/11)
  // =====================================================================

  public getDataProtectionPolicy(): DataProtectionPolicy {
    return this.db.settings.dataProtectionPolicy || defaultDataProtectionPolicy();
  }

  public updateDataProtectionPolicy(partial: Partial<DataProtectionPolicy>): DataProtectionPolicy {
    const current = this.getDataProtectionPolicy();
    const updated: DataProtectionPolicy = { ...current, ...partial, lastReviewedIso: new Date().toISOString() };
    this.db.settings = { ...this.db.settings, dataProtectionPolicy: updated };
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Atualização da Política de Proteção de Dados',
      details: 'A política de proteção de dados pessoais da instituição foi revista e atualizada.',
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return updated;
  }

  public getDataSubjectRequests(): DataSubjectRequest[] {
    return this.db.dataSubjectRequests || [];
  }

  public createDataSubjectRequest(
    fields: DataSubjectRequestFieldsInput
  ): { success: boolean; error?: string; errors?: string[]; request?: DataSubjectRequest } {
    const errors = validateDataSubjectRequest(fields);
    if (errors.length > 0) return { success: false, errors, error: errors[0] };

    let studentName: string | undefined;
    if (fields.studentId) {
      const student = (this.db.students || []).find((s) => s.id === fields.studentId);
      studentName = student?.name;
    }

    const now = new Date().toISOString();
    const created: DataSubjectRequest = {
      id: this.newComunicacaoId('dsr'),
      code: generateDataSubjectRequestCode((this.db.dataSubjectRequests || []).map((r) => r.code)),
      requesterName: fields.requesterName.trim(),
      requesterRelation: fields.requesterRelation,
      studentId: fields.studentId,
      studentName,
      type: fields.type,
      description: fields.description?.trim() || undefined,
      status: 'pendente',
      requestedAt: now,
      createdBy: this.currentActorName()
    };
    this.db.dataSubjectRequests = [created, ...(this.db.dataSubjectRequests || [])];
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Registo de Pedido de Titular de Dados',
      details: `Pedido ${created.code} (${REQUEST_TYPE_LABELS[created.type]}) registado para ${created.requesterName}.`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true, request: created };
  }

  public updateDataSubjectRequestStatus(
    id: string,
    status: DataSubjectRequestStatus,
    resolutionNotes?: string
  ): { success: boolean; error?: string } {
    const current = (this.db.dataSubjectRequests || []).find((r) => r.id === id);
    if (!current) return { success: false, error: 'Pedido não encontrado.' };
    const isFinal = status === 'concluido' || status === 'rejeitado';
    const updated: DataSubjectRequest = {
      ...current,
      status,
      resolutionNotes: resolutionNotes?.trim() || current.resolutionNotes,
      resolvedAt: isFinal ? new Date().toISOString() : current.resolvedAt
    };
    this.db.dataSubjectRequests = (this.db.dataSubjectRequests || []).map((r) => (r.id === id ? updated : r));
    this.addAuditLog({
      userName: this.currentActorName(),
      userRole: this.db.currentUser?.roleTitle || 'Administrador',
      action: 'Atualização de Pedido de Titular de Dados',
      details: `Pedido ${current.code} passou para o estado "${REQUEST_STATUS_META[status].label}".`,
      module: 'sistema',
      timestamp: 'Agora mesmo',
      badgeColor: '#0b1f3a'
    });
    this.notify();
    return { success: true };
  }

  public deleteDataSubjectRequest(id: string): { success: boolean; error?: string } {
    const target = (this.db.dataSubjectRequests || []).find((r) => r.id === id);
    if (!target) return { success: false, error: 'Pedido não encontrado.' };
    this.db.dataSubjectRequests = (this.db.dataSubjectRequests || []).filter((r) => r.id !== id);
    this.notify();
    return { success: true };
  }
}

export const dbService = new SchoolDatabaseService();
