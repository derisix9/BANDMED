import React, { useState, useEffect, useMemo, useRef } from 'react';
import { SchoolDatabase, UserRole, User, ClassRoom, Subject } from '../types';
import { GradeTypeKey, StudentMiniPautaItem, StudentPautaGeralItem } from '../types/pauta';
import { getAvailableSubjectsForUser } from '../utils/teacherSubjects';
import { runGlobalOperation } from '../context/OperationContext';
import { dbService } from '../services/db';
import { useAccessControl } from '../hooks/useAccessControl';
import { getStudentsForClass } from '../utils/classStudentsRoster';
import {
  buildMiniPautaRows,
  buildPautaGeralRows,
  calculateMT,
  calculateMFD,
  calculateCA,
  calculateSituation,
  normalizeGradeRules
} from '../utils/pautaCalculations';
import { GradeTypeSelector } from '../components/pauta/GradeTypeSelector';
import { MiniPautaTable } from '../components/pauta/MiniPautaTable';
import { PautaGeralTable } from '../components/pauta/PautaGeralTable';
import { getFallbackAcademicYear, getGradeLaunchLockInfo } from '../utils/academicYear';

interface PautasViewProps {
  db: SchoolDatabase;
  currentUserRole: UserRole;
  currentUser?: User;
  onNavigateToImport?: () => void;
}

export const PautasView: React.FC<PautasViewProps> = ({ db, currentUserRole, currentUser, onNavigateToImport }) => {
  // Navigation Tabs: 'minipauta' (Mini Pauta por Disciplina) vs 'pauta' (Pauta Geral)
  const [activeTab, setActiveTab] = useState<'minipauta' | 'pauta'>('minipauta');

  const availableSubjects = useMemo(() => {
    return getAvailableSubjectsForUser(db, currentUser);
  }, [db, currentUser]);

  const [selectedClassId, setSelectedClassId] = useState<string>(
    db.classes[0]?.id ? String(db.classes[0].id) : ''
  );

  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(
    availableSubjects[0]?.id ? String(availableSubjects[0].id) : (db.subjects[0]?.id ? String(db.subjects[0].id) : '')
  );

  const [isDirectorSigned, setIsDirectorSigned] = useState<boolean>(
    () => !!db.pauta?.isDirectorSigned || db.pauta?.status === 'homologada'
  );

  useEffect(() => {
    if (db.pauta?.isDirectorSigned || db.pauta?.status === 'homologada') {
      setIsDirectorSigned(true);
    }
  }, [db.pauta?.isDirectorSigned, db.pauta?.status]);

  // Current academic year from institution settings
  const currentAcademicYear = db.settings?.currentAcademicYear || getFallbackAcademicYear();

  // Print guard: "sem uma pauta ou mini pauta ser homologada não pode ser impressão"
  const handlePrintDocument = async () => {
    const isHomologada = isDirectorSigned || db.pauta?.status === 'homologada';
    if (!isHomologada) {
      await runGlobalOperation(
        async () => {
          throw new Error('Sem uma pauta ou mini pauta ser homologada não pode ser impressa.');
        },
        {
          loadingMessage: 'A verificar homologação pedagógica...',
          errorMessage: 'Impressão Bloqueada',
          errorDetails: 'Sem a homologação da Direção Pedagógica, a pauta ou mini-pauta não possui validade oficial para ser emitida ou impressa.'
        }
      );
      return;
    }
    window.print();
  };

  // Filter for Grade Types (MT1, MT2, MT3, MFD, MF, MAC, NPP, NPT, PG, CA)
  const [selectedGradeTypes, setSelectedGradeTypes] = useState<Set<GradeTypeKey>>(
    new Set<GradeTypeKey>(['MAC', 'NPP', 'NPT', 'MT1', 'MT2', 'MT3', 'MFD', 'PG', 'CA', 'MF'])
  );

  // Financial Compliance: Hide debtor grades on print option
  const [hideDebtorGrades, setHideDebtorGrades] = useState<boolean>(true);
  const [previewHiddenOnScreen, setPreviewHiddenOnScreen] = useState<boolean>(false);
 
 // Structural placeholders ONLY: used so grade calculations don't crash before the
 // institution has registered any class/subject. They are never shown as if real —
 // the selectors above already render "Nenhuma turma cadastrada" in that case.
  const fallbackClass: ClassRoom = useMemo(() => ({
    id: '',
    name: '',
    grade: '',
    section: '',
    cycle: '',
    area: '',
    shift: 'Manhã',
    room: '',
    studentCount: 0,
    maxCapacity: 0,
    headTeacherId: '',
    headTeacherName: '',
    academicYear: db.settings?.currentAcademicYear || ''
  }), [db.settings?.currentAcademicYear]);

  const fallbackSubject: Subject = useMemo(() => ({
    id: '',
    name: '',
    code: '',
    cycle: '',
    weeklyHours: 0,
    area: ''
  }), []);
  // Ensure selectedClassId is valid
  useEffect(() => {
    if (db.classes && db.classes.length > 0 && !db.classes.some((c) => String(c.id) === String(selectedClassId))) {
      setSelectedClassId(String(db.classes[0].id));
    }
  }, [db.classes, selectedClassId]);

  // Ensure selectedSubjectId is valid
  useEffect(() => {
    if (availableSubjects.length > 0 && !availableSubjects.some((s) => String(s.id) === String(selectedSubjectId))) {
      setSelectedSubjectId(String(availableSubjects[0].id));
    }
  }, [availableSubjects, selectedSubjectId]);

  const activeClass = (db.classes || []).find((c) => String(c.id) === String(selectedClassId)) || db.classes?.[0] || fallbackClass;

  // Regras & Escala de Notas configuradas em Configurações (aba TabRegrasNotas).
  // Estas regras passam a ser o "contrato" usado por TODOS os cálculos da Pauta
  // e Mini-Pauta, em vez de valores fixos no código.
  const gradeRules = useMemo(() => normalizeGradeRules(db.settings?.gradeRules as any), [db.settings?.gradeRules]);
  const activeSubject = (db.subjects || []).find((s) => String(s.id) === String(selectedSubjectId)) || availableSubjects?.[0] || db.subjects?.[0] || fallbackSubject;

  const isPreviousAcademicYear = activeClass?.academicYear ? activeClass.academicYear !== currentAcademicYear : false;

  // Regras de Trancamento definidas em Configurações > Ano Letivo & Calendário: bloqueia o
  // lançamento de notas do Trimestre atualmente em curso se ele já tiver sido Encerrado, ou
  // se já tiver passado a janela de dias úteis configurada desde o Término Letivo. A Direção
  // Pedagógica e a Administração continuam a poder lançar/corrigir notas sempre.
  const currentTrimester = (db.settings?.currentTrimester || '1') as '1' | '2' | '3';
  const gradeLaunchLock = useMemo(
    () => getGradeLaunchLockInfo(db.settings, currentTrimester),
    [db.settings, currentTrimester]
  );
  const isLockedByCalendar = gradeLaunchLock.locked && currentUserRole === 'professor';
  const isTeacherReadOnly = currentUserRole === 'professor' && (isPreviousAcademicYear || isLockedByCalendar);
  const isSecretaria = currentUserRole === 'secretaria';

  // Matriz ACL: quem lança notas, importa Excel e homologa passa a ser decidido
  // em Configurações → Perfis & Permissões, e não por cargo fixo no código.
  const acl = useAccessControl(currentUserRole);
  const canEditGrades = acl.can('pautas.edit_notas');
  const canHomologate = acl.can('pautas.homologar');
  const isReadOnlyMode = isTeacherReadOnly || isSecretaria;

  // Students belonging strictly to the selected class
  const classStudents = useMemo(() => {
    return getStudentsForClass(selectedClassId, db.students || [], activeClass?.name);
  }, [selectedClassId, db.students, activeClass?.name]);

  // Subjects taught in the active class
  const classSubjects = useMemo(() => {
    return (db.subjects && db.subjects.length > 0) ? db.subjects : [activeSubject];
  }, [db.subjects, activeSubject]);

  // Persistent cache of edited grades per class, subject, and student
  const [gradesCache, setGradesCache] = useState<Record<string, Record<string, Record<string, StudentMiniPautaItem>>>>({});

  // Refs holding the latest values of things that change identity very often
  // (every Firebase Realtime Database sync replaces db.students/classStudents
  // with a brand-new array, even when nothing relevant actually changed). These
  // refs let the "reload rows" effects below read the CURRENT data without
  // being re-triggered by every background sync, which used to wipe out grades
  // the professor had just typed (and any MT1/MT2/MT3/MFD calculated from them)
  // before they had a chance to click "Salvar" — they simply kept resetting
  // back to blank/zero.
  const classStudentsRef = useRef(classStudents);
  useEffect(() => {
    classStudentsRef.current = classStudents;
  }, [classStudents]);

  const dbStudentsRef = useRef(db.students);
  useEffect(() => {
    dbStudentsRef.current = db.students;
  }, [db.students]);

  const gradesCacheRef = useRef(gradesCache);
  useEffect(() => {
    gradesCacheRef.current = gradesCache;
  }, [gradesCache]);

  // Main Grade Rows state
  const [miniPautaRows, setMiniPautaRows] = useState<StudentMiniPautaItem[]>(() => {
    const subjectCache = gradesCache[selectedClassId]?.[selectedSubjectId];
    return buildMiniPautaRows(classStudents, selectedSubjectId, db.students, subjectCache, gradeRules);
  });

  const [pautaGeralRows, setPautaGeralRows] = useState<StudentPautaGeralItem[]>(() => {
    const classCache = gradesCache[selectedClassId];
    return buildPautaGeralRows(classStudents, classSubjects, db.students, classCache, activeClass?.grade, gradeRules);
  });

  // Rebuild rows ONLY when the professor actually switches turma or disciplina.
  // IMPORTANT: this must NOT depend on `classStudents` / `db.students` directly.
  // Those get a brand-new array reference on every Firebase Realtime Database
  // sync (see services/db.ts onValue listener), including syncs triggered by
  // the professor's OWN "Salvar" click a moment earlier. Depending on them here
  // caused this effect to re-run while notes were still being typed, discarding
  // the in-progress mac1/npp1/npt1 values (and the mt1/mt2/mt3/mfd computed
  // from them) and replacing them with blank/zero rows — which is what made it
  // look like the MT1/MT2/MT3/MFD calculations "never happened".
  useEffect(() => {
    const stored = dbService.getMiniPautaRows(selectedClassId, selectedSubjectId);
    if (stored && Array.isArray(stored) && stored.length > 0) {
      // Recalcula MT1/MT2/MT3/MFD/CA a partir do MAC/NPP/NPT guardados, em vez
      // de confiar ciegamente no valor persistido. Registos gravados antes desta
      // correção (ou importados/editados numa versão anterior com bug) tinham
      // mt1/mt2/mt3/mfd fixados em 0 mesmo com MAC/NPP/NPT lançados — e como o
      // cálculo só corria ao editar uma célula, esses zeros ficavam "presos" para
      // sempre em cada carregamento da Mini-Pauta.
      const recalculated = stored.map((row: StudentMiniPautaItem) => {
        if (row.isDesistente) return row;
        const mt1 = calculateMT(row.mac1, row.npp1, row.npt1, gradeRules);
        const mt2 = calculateMT(row.mac2, row.npp2, row.npt2, gradeRules);
        const mt3 = calculateMT(row.mac3, row.npp3, row.npt3, gradeRules);
        const mfd = calculateMFD(mt1, mt2, mt3, row.pg, gradeRules);
        const ca = calculateCA(mfd);
        const obs = calculateSituation({
          finalGrade: mfd,
          hasAnyGrade: typeof mfd === 'number',
          isDesistente: false,
          classGrade: activeClass?.grade,
          rules: gradeRules
        });
        return { ...row, mt1, mt2, mt3, mfd, ca, obs };
      });
      setMiniPautaRows(recalculated);
      return;
    }
    const subjectCache = gradesCacheRef.current[selectedClassId]?.[selectedSubjectId];
    setMiniPautaRows(buildMiniPautaRows(classStudentsRef.current, selectedSubjectId, dbStudentsRef.current, subjectCache, gradeRules));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClassId, selectedSubjectId]);

  useEffect(() => {
    const classCache = gradesCacheRef.current[selectedClassId];
    setPautaGeralRows(buildPautaGeralRows(classStudentsRef.current, classSubjects, dbStudentsRef.current, classCache, activeClass?.grade, gradeRules));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedClassId, activeClass?.grade, gradeRules]);

  // Toggle single grade type
  const handleToggleGradeType = (key: GradeTypeKey) => {
    setSelectedGradeTypes((prev) => {
      const updated = new Set(prev);
      if (updated.has(key)) {
        updated.delete(key);
      } else {
        updated.add(key);
      }
      return updated;
    });
  };

  // Preset Handlers
  const handleSelectAllTypes = () => {
    setSelectedGradeTypes(new Set<GradeTypeKey>(['MAC', 'NPP', 'NPT', 'MT1', 'MT2', 'MT3', 'MFD', 'PG', 'CA', 'MF']));
  };

  const handleSelectAveragesOnly = () => {
    setSelectedGradeTypes(new Set<GradeTypeKey>(['MT1', 'MT2', 'MT3', 'MFD', 'MF']));
  };

  const handleSelectEvaluationsOnly = () => {
    setSelectedGradeTypes(new Set<GradeTypeKey>(['MAC', 'NPP', 'NPT', 'PG']));
  };

  const handleResetDefaultMiniPauta = () => {
    setSelectedGradeTypes(new Set<GradeTypeKey>(['MAC', 'NPP', 'NPT', 'MT1', 'MT2', 'MT3', 'MFD', 'PG', 'CA', 'MF']));
  };

  // Real-time calculation when editing a grade cell in Mini-Pauta
  const handleMiniPautaCellChange = (rowIndex: number, field: keyof StudentMiniPautaItem, value: any) => {
    // Sem a regra "pautas.edit_notas" na matriz ACL, a célula não aceita edição.
    if (!canEditGrades) {
      acl.guard('pautas.edit_notas', () => undefined);
      return;
    }

    let updatedRow: StudentMiniPautaItem | null = null;

    setMiniPautaRows((prev) => {
      const updated = [...prev];
      const row = { ...updated[rowIndex], [field]: value };

      if (row.isDesistente) {
        updated[rowIndex] = row;
        updatedRow = row;
        return updated;
      }

      // Recalculate MT1
      if (field === 'mac1' || field === 'npp1' || field === 'npt1') {
        row.mt1 = calculateMT(row.mac1, row.npp1, row.npt1, gradeRules);
      }

      // Recalculate MT2
      if (field === 'mac2' || field === 'npp2' || field === 'npt2') {
        row.mt2 = calculateMT(row.mac2, row.npp2, row.npt2, gradeRules);
      }

      // Recalculate MT3
      if (field === 'mac3' || field === 'npp3' || field === 'npt3') {
        row.mt3 = calculateMT(row.mac3, row.npp3, row.npt3, gradeRules);
      }

      // Recalculate MFD & CA
      row.mfd = calculateMFD(row.mt1, row.mt2, row.mt3, row.pg, gradeRules);
      row.ca = calculateCA(row.mfd);
      row.obs = calculateSituation({
        finalGrade: row.mfd,
        hasAnyGrade: typeof row.mfd === 'number',
        isDesistente: false,
        classGrade: activeClass?.grade,
        rules: gradeRules
      });

      updated[rowIndex] = row;
      updatedRow = row;
      return updated;
    });

    if (updatedRow) {
      const r = updatedRow as StudentMiniPautaItem;
      setGradesCache((prev) => {
        const classCache = prev[selectedClassId] || {};
        const subjectCache = classCache[selectedSubjectId] || {};
        return {
          ...prev,
          [selectedClassId]: {
            ...classCache,
            [selectedSubjectId]: {
              ...subjectCache,
              [r.studentId]: r
            }
          }
        };
      });
    }

    // Also synchronize corresponding student discipline grades in Pauta Geral
    setPautaGeralRows((prev) => {
      const updated = [...prev];
      if (updated[rowIndex]) {
        const studentRow = { ...updated[rowIndex] };
        const currentSubjGrades = { ...studentRow.subjectGrades };
        const miniRow = miniPautaRows[rowIndex];

        if (miniRow && !miniRow.isDesistente) {
          const mt1 = field === 'mt1' ? value : (field === 'mac1' || field === 'npp1' || field === 'npt1' ? calculateMT(field === 'mac1' ? value : miniRow.mac1, field === 'npp1' ? value : miniRow.npp1, field === 'npt1' ? value : miniRow.npt1, gradeRules) : miniRow.mt1);
          const mt2 = field === 'mt2' ? value : (field === 'mac2' || field === 'npp2' || field === 'npt2' ? calculateMT(field === 'mac2' ? value : miniRow.mac2, field === 'npp2' ? value : miniRow.npp2, field === 'npt2' ? value : miniRow.npt2, gradeRules) : miniRow.mt2);
          const mt3 = field === 'mt3' ? value : (field === 'mac3' || field === 'npp3' || field === 'npt3' ? calculateMT(field === 'mac3' ? value : miniRow.mac3, field === 'npp3' ? value : miniRow.npp3, field === 'npt3' ? value : miniRow.npt3, gradeRules) : miniRow.mt3);
          const mfd = calculateMFD(mt1, mt2, mt3, field === 'pg' ? value : miniRow.pg, gradeRules);

          currentSubjGrades[selectedSubjectId] = { mt1, mt2, mt3, mfd };
          studentRow.subjectGrades = currentSubjGrades;

          // Recalculate overall MF (Média Final Geral) a partir de TODAS as
          // disciplinas com nota lançada nesta pauta geral.
          const allMfds = Object.values(currentSubjGrades)
            .map((g) => g.mfd)
            .filter((m): m is number => typeof m === 'number');

          studentRow.mf = allMfds.length > 0
            ? Math.round(allMfds.reduce((a, b) => a + b, 0) / allMfds.length)
            : '';

          // Situação real (PENDENTE / APROVADO / EXAME DE RECURSO / REPROVADO),
          // nunca "Apto" por omissão enquanto não houver nenhuma nota lançada —
          // exatamente a mesma regra usada na Mini-Pauta (ver calculateSituation).
          studentRow.situation = calculateSituation({
            finalGrade: studentRow.mf,
            hasAnyGrade: allMfds.length > 0,
            isDesistente: false,
            classGrade: activeClass?.grade,
            rules: gradeRules
          });
          updated[rowIndex] = studentRow;
        }
      }
      return updated;
    });
  };

  // Toggle student as Desistente
  const handleToggleDesistente = (rowIndex: number) => {
    setMiniPautaRows((prev) => {
      const updated = [...prev];
      const target = { ...updated[rowIndex] };
      target.isDesistente = !target.isDesistente;
      if (target.isDesistente) {
        target.obs = 'Desistente';
      } else {
        target.mfd = calculateMFD(target.mt1, target.mt2, target.mt3, target.pg, gradeRules);
        target.ca = calculateCA(target.mfd);
        target.obs = calculateSituation({
          finalGrade: target.mfd,
          hasAnyGrade: typeof target.mfd === 'number',
          isDesistente: false,
          classGrade: activeClass?.grade,
          rules: gradeRules
        });
      }
      updated[rowIndex] = target;
      return updated;
    });

    setPautaGeralRows((prev) => {
      const updated = [...prev];
      if (updated[rowIndex]) {
        const studentRow = { ...updated[rowIndex] };
        studentRow.isDesistente = !studentRow.isDesistente;
        studentRow.situation = calculateSituation({
          finalGrade: studentRow.mf,
          hasAnyGrade: typeof studentRow.mf === 'number',
          isDesistente: studentRow.isDesistente,
          classGrade: activeClass?.grade,
          rules: gradeRules
        });
        updated[rowIndex] = studentRow;
      }
      return updated;
    });
  };

  // Stats calculation
  const totalStudents = miniPautaRows.length;
  const debtorStudentsCount = miniPautaRows.filter((r) => r.isDebtor).length;
  const desistentesCount = miniPautaRows.filter((r) => r.isDesistente).length;
  const activeStudentsCount = totalStudents - desistentesCount;

  const validMfds = miniPautaRows
    .filter((r) => !r.isDesistente && typeof r.mfd === 'number')
    .map((r) => r.mfd as number);

  const averageScore = validMfds.length > 0 ? (validMfds.reduce((a, b) => a + b, 0) / validMfds.length).toFixed(1) : '0.0';
  const approvedCount = validMfds.filter((score) => score >= 10).length;
  const approvalRate = activeStudentsCount > 0 ? Math.round((approvedCount / activeStudentsCount) * 100) : 0;
  const resourceCount = validMfds.filter((score) => score < 10).length;

  return (
    <div className="flex flex-col w-full gap-5 pb-16 printable-document printable-landscape">
      <style>{`
        @media print {
          @page {
            size: A4 landscape !important;
            margin: 4mm 5mm !important;
          }
        }
      `}</style>
      {/* Action Header & Tabs Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print print:hidden">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500">
              Gestão Acadêmica & Avaliação
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#0b1f3a]" />
            <span className="text-xs font-semibold text-[#0b1f3a]">
              {activeTab === 'minipauta' ? 'Mini-Pauta por Disciplina' : 'Pauta Geral da Turma'}
            </span>
          </div>
          <h1 className="font-headline text-2xl lg:text-3xl font-extrabold text-[#0b1f3a] tracking-tight">
            Lançamento de Notas & Pautas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
          </p>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Importar Pauta (Excel) — disponível para Admin/Direção Pedagógica/Secretaria em
              âmbito geral, e para o Professor apenas em âmbito da(s) disciplina(s) que lecciona. */}
          {onNavigateToImport && acl.can('pautas.import_excel') && (
            <button
              onClick={() => acl.guard('pautas.import_excel', () => onNavigateToImport())}
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-[#0b1f3a] border border-slate-300 font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
              title="Importar notas a partir de um ficheiro Excel/CSV"
            >
              <span className="material-symbols-outlined text-[18px]">upload_file</span>
              <span>Importar Pauta (Excel)</span>
            </button>
          )}

          {/* Print Button - Blocked if not homologated */}
          <button
            onClick={handlePrintDocument}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-xs transition-all cursor-pointer ${
              isDirectorSigned || db.pauta?.status === 'homologada'
                ? 'bg-[#0b1f3a] hover:bg-[#122c50] text-white'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-600'
            }`}
            title={
              isDirectorSigned || db.pauta?.status === 'homologada'
                ? 'Imprimir documento pedagógico oficial'
                : 'A impressão só é permitida após homologação pela Direção Pedagógica'
            }
          >
            <span className="material-symbols-outlined text-[18px] text-amber-400">
              {isDirectorSigned || db.pauta?.status === 'homologada' ? 'print' : 'lock'}
            </span>
            <span>Imprimir</span>
            {(!isDirectorSigned && db.pauta?.status !== 'homologada') && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">
                Requer Homologação
              </span>
            )}
          </button>

          {/* Gravar notas: depende da regra pautas.edit_notas na matriz ACL */}
          {canEditGrades && (
            <button
              onClick={async () => {
                if (isTeacherReadOnly) {
                  await runGlobalOperation(
                    async () => {
                      throw new Error(
                        isPreviousAcademicYear
                          ? 'Os professores não podem alterar notas de mini pautas de anos lectivos anteriores.'
                          : gradeLaunchLock.reason || 'Lançamento de notas bloqueado pelas Regras de Trancamento do Ano Letivo.'
                      );
                    },
                    {
                      loadingMessage: 'A verificar permissão lectiva...',
                      errorMessage: isPreviousAcademicYear ? 'Ano Lectivo Anterior Bloqueado' : 'Lançamento de Notas Bloqueado',
                      errorDetails: isPreviousAcademicYear
                        ? 'Apenas é permitido o lançamento e alteração de notas para o ano lectivo corrente em curso.'
                        : gradeLaunchLock.reason || 'Consulte a Direção Pedagógica para reabrir o trimestre em Configurações > Ano Letivo.'
                    }
                  );
                  return;
                }

                await runGlobalOperation(
                  async () => {
                    dbService.saveMiniPautaRows(selectedClassId, selectedSubjectId, miniPautaRows, currentUser?.name);
                    await dbService.pushToCloudStorage();
                  },
                  {
                    loadingMessage: 'A gravar notas e a sincronizar na base de dados...',
                    successMessage: 'Pauta e notas gravadas com sucesso na base de dados!',
                    requiredRule: 'pautas.edit_notas',
                    userRole: currentUserRole
                  }
                );
              }}
              disabled={isTeacherReadOnly || !canEditGrades}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors ${
                isTeacherReadOnly
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-[#0b1f3a] hover:bg-[#122c50] text-white cursor-pointer'
              }`}
              title={isTeacherReadOnly ? (isPreviousAcademicYear ? 'Bloqueado para anos lectivos anteriores' : gradeLaunchLock.reason) : 'Gravar notas na base de dados'}
            >
              <span className="material-symbols-outlined text-[18px]">
                {isTeacherReadOnly ? 'lock' : 'cloud_sync'}
              </span>
              <span>Enviar</span>
            </button>
          )}

          {/* Homologate Button for Admin and Direção Pedagógica (Secretaria cannot homologate) */}
          {canHomologate && (
            <button
              onClick={async () => {
                const directorName = db.settings?.directorPedagogico || db.settings?.directorGeral || 'Director Pedagógico';
                await runGlobalOperation(
                  async () => {
                    setIsDirectorSigned(true);
                    dbService.markPautaAsSigned(directorName);
                    await dbService.pushToCloudStorage();
                  },
                  {
                    loadingMessage: `A homologar com ${directorName}...`,
                    successMessage: `Pauta homologada pela Direção Pedagógica (${directorName})!`,
                    requiredRule: 'pautas.homologar',
                    userRole: currentUserRole
                  }
                );
              }}
              className="px-3.5 py-2 rounded-xl bg-[#7a0c0c] hover:bg-[#8f1010] text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">verified</span>
              <span>{isDirectorSigned ? 'Homologada' : 'Homologar'}</span>
            </button>
          )}

          {/* Secretaria Info Badge */}
          {isSecretaria && (
            <span className="px-3 py-1.5 rounded-xl bg-blue-50 text-blue-900 border border-blue-200 text-xs font-bold flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-blue-600">visibility</span>
              <span>Consulta & Impressão Oficial</span>
            </span>
          )}
        </div>
      </div>

      {/* TWO PRIMARY TABS (Mini Pauta & Pauta) */}
      {/* Requirement: "CRIA DUAS ABAS UMA PARA MINI PAUTA E OUTRA PARA PAUTA." */}
      <div className="bg-slate-100 p-1.5 rounded-2xl flex items-center gap-2 border border-slate-200 no-print print:hidden shadow-2xs max-w-fit">
        <button
          type="button"
          onClick={() => setActiveTab('minipauta')}
          className={`px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'minipauta'
              ? 'bg-[#0b1f3a] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">view_week</span>
          <span>Mini-Pauta</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-white/20 text-white">
            Trimestral
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('pauta')}
          className={`px-5 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'pauta'
              ? 'bg-[#0b1f3a] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">table_chart</span>
          <span>Pauta Final</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-amber-400 text-slate-900 font-black">
            Geral
          </span>
        </button>
      </div>


      {/* Class & Subject Selectors */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs no-print print:hidden">
        <div>
          <label className="block uppercase font-bold text-slate-500 mb-1">Turma Curricular</label>
          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="w-full h-9 px-3 rounded-lg bg-slate-100 font-bold text-slate-800 focus:bg-white focus:ring-1 focus:ring-[#0b1f3a]"
          >
            {(!db.classes || db.classes.length === 0) ? (
              <option value="">Nenhuma turma cadastrada</option>
            ) : (
              db.classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.room})
                </option>
              ))
            )}
          </select>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="block uppercase font-bold text-slate-500 text-[11px]">
              {activeTab === 'minipauta' ? 'Disciplina da Mini-Pauta' : 'Foco Curricular'}
            </label>
            {currentUserRole === 'professor' && (
              <span className="text-[10px] text-blue-700 font-semibold">(Suas disciplinas)</span>
            )}
          </div>
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            disabled={activeTab === 'pauta'}
            className={`w-full h-9 px-3 rounded-lg font-bold text-slate-800 focus:bg-white focus:ring-1 focus:ring-[#0b1f3a] ${
              activeTab === 'pauta' ? 'bg-slate-200 text-slate-500 cursor-not-allowed' : 'bg-slate-100'
            }`}
          >
            {availableSubjects.length === 0 ? (
              <option value="">Nenhuma disciplina disponível</option>
            ) : (
              availableSubjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))
            )}
          </select>
        </div>

        <div>
          <label className="block uppercase font-bold text-slate-500 mb-1">Ano Lectivo / Regime</label>
          <div className="relative flex items-center">
            <input
              type="text"
              readOnly
              value={`${db.settings?.currentAcademicYear || getFallbackAcademicYear()}${activeClass?.shift ? ` • Presencial (${activeClass.shift})` : ' • Presencial'}`}
              className="w-full h-9 px-3 pr-8 rounded-lg bg-slate-100 font-bold text-slate-700 text-xs border border-slate-200 cursor-default truncate select-none shadow-2xs"
              title="Ano Lectivo corrente em curso definido nas configurações da instituição"
            />
            <div className="absolute right-2.5 flex items-center gap-1.5 pointer-events-none">
              <span
                className="w-2 h-2 rounded-full bg-emerald-500"
                title="Ano letivo corrente ativo"
              />
              <span className="material-symbols-outlined text-slate-400 text-[14px]">
                lock
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Warning if teacher is viewing a previous academic year class */}
      {isTeacherReadOnly && isPreviousAcademicYear && (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2 text-amber-900 text-xs font-medium no-print print:hidden">
          <span className="material-symbols-outlined text-amber-600 text-[18px]">lock</span>
          <span>
            <strong>Modo Somente Leitura:</strong> Esta turma pertence ao ano lectivo anterior ({activeClass?.academicYear}). Os professores estão impossibilitados de alterar notas de mini pautas de anos anteriores.
          </span>
        </div>
      )}

      {/* Warning if the current trimester's grade launch window is locked (Regras de Trancamento) */}
      {isTeacherReadOnly && !isPreviousAcademicYear && isLockedByCalendar && (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2 text-amber-900 text-xs font-medium no-print print:hidden">
          <span className="material-symbols-outlined text-amber-600 text-[18px]">lock_clock</span>
          <span>
            <strong>Lançamento de Notas Bloqueado:</strong> {gradeLaunchLock.reason}
          </span>
        </div>
      )}

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center no-print print:hidden">
        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Média da Turma</span>
          <span className="font-headline text-2xl font-extrabold text-[#0b1f3a]">{averageScore}</span>
          <span className="text-[10px] text-slate-400">Escala 0 a 20 (Ensino Médio)</span>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] uppercase font-bold text-emerald-700 block">Taxa de Aproveitamento</span>
          <span className="font-headline text-2xl font-extrabold text-emerald-700">{approvalRate}%</span>
          <span className="text-[10px] text-slate-400">{approvedCount} de {activeStudentsCount} alunos aptos</span>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] uppercase font-bold text-[#7a0c0c] block">Em Recurso / Reprovados</span>
          <span className="font-headline text-2xl font-extrabold text-[#7a0c0c]">{resourceCount}</span>
          <span className="text-[10px] text-slate-400">Classificação &lt; 10 valores</span>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] uppercase font-bold text-amber-700 block">Alunos com Propinas Pendentes</span>
          <span className="font-headline text-2xl font-extrabold text-amber-800">{debtorStudentsCount}</span>
          <span className="text-[10px] text-slate-400">
            {hideDebtorGrades ? 'Notas ocultadas ao imprimir' : 'Visível'}
          </span>
        </div>
      </div>

      {/* Interactive Grade Type Selector & Debtor Controls */}
      {/* Requirements:
          1. "DEVE SER POSSIVEL SELECIONAR QUAIS TIPOS DE NOTAS (MT1,MT2,MT3,MFD,MF,MAC,NPP,NPT,PG,CA) VAI CONSTAR OU SER VISTO NA PAUTA OU MINI PAUTA."
          2. "COLOQUE OPÇÃO DE VER E OCULTAR NOTAS DOS ALUNOS DEVEDORES DA PAUTA AO IMPIRMIR."
      */}
      <GradeTypeSelector
        selectedTypes={selectedGradeTypes}
        onToggleType={handleToggleGradeType}
        onSelectAll={handleSelectAllTypes}
        onSelectAveragesOnly={handleSelectAveragesOnly}
        onSelectEvaluationsOnly={handleSelectEvaluationsOnly}
        onResetDefaultMiniPauta={handleResetDefaultMiniPauta}
        hideDebtorGrades={hideDebtorGrades}
        onToggleHideDebtorGrades={setHideDebtorGrades}
        previewHiddenOnScreen={previewHiddenOnScreen}
        onTogglePreviewHiddenOnScreen={setPreviewHiddenOnScreen}
        activeTab={activeTab}
      />

      {/* TAB CONTENT 1: MINI-PAUTA */}
      {activeTab === 'minipauta' && (
        <MiniPautaTable
          rows={miniPautaRows}
          onCellChange={handleMiniPautaCellChange}
          onToggleDesistente={handleToggleDesistente}
          selectedGradeTypes={selectedGradeTypes}
          hideDebtorGrades={hideDebtorGrades}
          previewHiddenOnScreen={previewHiddenOnScreen}
          activeClass={activeClass}
          activeSubject={activeSubject}
          settings={db.settings}
          isReadOnly={isReadOnlyMode}
        />
      )}

      {/* TAB CONTENT 2: PAUTA GERAL */}
      {activeTab === 'pauta' && (
        <PautaGeralTable
          rows={pautaGeralRows}
          subjects={classSubjects}
          selectedGradeTypes={selectedGradeTypes}
          hideDebtorGrades={hideDebtorGrades}
          previewHiddenOnScreen={previewHiddenOnScreen}
          activeClass={activeClass}
          onToggleDesistente={handleToggleDesistente}
          settings={db.settings}
        />
      )}
    </div>
  );
};
